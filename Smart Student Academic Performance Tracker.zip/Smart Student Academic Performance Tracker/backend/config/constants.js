/**
 * Centralized Application Constants & Academic Rules Configuration
 * All thresholds are centrally configured to ensure explainability and maintainability.
 */

module.exports = {
  ROLES: {
    ADMIN: 'admin',
    FACULTY: 'faculty',
    STUDENT: 'student'
  },

  RISK_LEVELS: {
    ON_TRACK: 'On Track',
    NEEDS_ATTENTION: 'Needs Attention',
    HIGH_PRIORITY: 'High Priority'
  },

  // Centralized Thresholds for Risk Radar
  THRESHOLDS: {
    // Attendance percentage below this triggers an alert
    MIN_ATTENDANCE: parseFloat(process.env.MIN_ATTENDANCE_TARGET) || 75.0,
    CRITICAL_ATTENDANCE: 65.0,

    // Marks thresholds
    PASSING_PERCENT: parseFloat(process.env.PASSING_PERCENTAGE) || 40.0,
    TARGET_BENCHMARK: 60.0,
    EXCELLENCE_BENCHMARK: 75.0,

    // Score decline threshold (e.g. 10% drop between consecutive assessments)
    DECLINE_THRESHOLD_PERCENT: parseFloat(process.env.RISK_DECLINE_THRESHOLD_PERCENT) || 10.0,

    // Number of consecutive low scores (<50%) to trigger repeated low score warning
    CONSECUTIVE_LOW_SCORES: parseInt(process.env.CONSECUTIVE_LOW_SCORES_LIMIT, 10) || 2,
    LOW_SCORE_CUTOFF: 50.0,

    // Minimum data points needed before asserting a decline trend
    MIN_ASSESSMENTS_FOR_TREND: 2
  },

  // Grading scheme
  GRADING_SCALE: [
    { grade: 'O', label: 'Outstanding', min: 90, max: 100, point: 10 },
    { grade: 'A+', label: 'Excellent', min: 80, max: 89.99, point: 9 },
    { grade: 'A', label: 'Very Good', min: 70, max: 79.99, point: 8 },
    { grade: 'B+', label: 'Good', min: 60, max: 69.99, point: 7 },
    { grade: 'B', label: 'Above Average', min: 50, max: 59.99, point: 6 },
    { grade: 'C', label: 'Average', min: 40, max: 49.99, point: 5 },
    { grade: 'RA', label: 'Re-appear', min: 0, max: 39.99, point: 0 }
  ]
};
