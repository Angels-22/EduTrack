const mongoose = require('mongoose');

let cachedConnection = null;

const connectDB = async () => {
  if (cachedConnection && mongoose.connection.readyState === 1) {
    return cachedConnection;
  }

  const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/edutrack';

  try {
    const opts = {
      bufferCommands: false,
      serverSelectionTimeoutMS: 5000,
      autoIndex: true
    };

    const conn = await mongoose.connect(mongoUri, opts);
    cachedConnection = conn;
    console.log(`[Database] MongoDB connected successfully to: ${conn.connection.host}/${conn.connection.name}`);
    return conn;
  } catch (err) {
    const sanitizedUri = mongoUri.replace(/:[^:@]+@/, ':****@');
    console.error(`[Database Error] Failed to connect to MongoDB (${sanitizedUri}):`, err.message);
    throw err;
  }
};

module.exports = connectDB;
