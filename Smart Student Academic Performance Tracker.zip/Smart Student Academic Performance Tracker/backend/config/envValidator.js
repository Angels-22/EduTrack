/**
 * Environment Validation and Secret Management
 * Ensures strict security in production and fails safely if required variables are missing or weak.
 */

const PLACEHOLDER_SECRETS = [
  'edutrack_local_development_secret_key_2026_xyz',
  'your_32_character_minimum_random_secret_string_here_2026',
  'your_super_secret_jwt_key_2026',
  'your_jwt_secret_here',
  'changeme',
  'secret',
  '12345678901234567890123456789012',
  'abcdefghijklmnopqrstuvwxyz123456'
];

const getJwtSecret = () => {
  const secret = process.env.JWT_SECRET;
  const isProd = process.env.NODE_ENV === 'production';

  if (isProd) {
    if (!secret || secret.trim().length < 32 || PLACEHOLDER_SECRETS.includes(secret.toLowerCase().trim())) {
      throw new Error(
        'FATAL SECURITY CONFIGURATION ERROR: A strong, unique JWT_SECRET (minimum 32 characters) ' +
        'must be provided in environment variables for production deployments. Hardcoded fallback and placeholder secrets are disabled.'
      );
    }
    return secret.trim();
  }

  // Development and test fallback with explicit warning
  if (!secret) {
    return 'edutrack_local_development_secret_key_2026_xyz';
  }

  return secret.trim();
};

const validateProductionEnv = () => {
  if (process.env.NODE_ENV !== 'production') {
    return;
  }

  const errors = [];

  // 1. Validate JWT Secret
  try {
    getJwtSecret();
  } catch (err) {
    errors.push(err.message);
  }

  // 2. Validate MongoDB URI
  const mongoUri = process.env.MONGODB_URI;
  if (!mongoUri || mongoUri.includes('127.0.0.1') || mongoUri.includes('localhost')) {
    errors.push('Production deployment requires a secure, non-local MONGODB_URI (e.g. MongoDB Atlas connection string).');
  }

  // 3. Validate CORS Origin
  const allowedOrigins = process.env.ALLOWED_ORIGINS || process.env.CLIENT_URL;
  if (!allowedOrigins || allowedOrigins.includes('*')) {
    errors.push('Production deployment requires an explicit ALLOWED_ORIGINS or CLIENT_URL whitelist (wildcard origins are forbidden).');
  }

  if (errors.length > 0) {
    console.error('\n========================================================');
    console.error('[FATAL PRODUCTION CONFIGURATION AUDIT FAILURE]');
    errors.forEach((err, idx) => console.error(`  ${idx + 1}. ${err}`));
    console.error('========================================================\n');
    throw new Error('Production environment validation failed. Server startup aborted for security.');
  }
};

module.exports = {
  getJwtSecret,
  validateProductionEnv
};

