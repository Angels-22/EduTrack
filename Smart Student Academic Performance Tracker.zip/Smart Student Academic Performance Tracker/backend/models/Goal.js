const mongoose = require('mongoose');

const goalSchema = new mongoose.Schema(
  {
    studentRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: [true, 'Student reference is required']
    },
    subjectRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      default: null
    },
    title: {
      type: String,
      required: [true, 'Goal title is required'],
      trim: true
    },
    category: {
      type: String,
      enum: ['Subject Marks', 'Semester Percentage', 'Attendance', 'Task Completion'],
      default: 'Semester Percentage'
    },
    targetValue: {
      type: Number,
      required: [true, 'Target value is required'],
      min: 0,
      max: 100
    },
    currentValue: {
      type: Number,
      default: 0
    },
    unit: {
      type: String,
      default: '%'
    },
    deadline: {
      type: Date,
      required: [true, 'Goal deadline is required']
    },
    status: {
      type: String,
      enum: ['In Progress', 'Achieved', 'Missed'],
      default: 'In Progress'
    },
    achievedAt: {
      type: Date,
      default: null
    },
    reflectionNotes: {
      type: String,
      trim: true,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

goalSchema.index({ studentRef: 1, status: 1 });

module.exports = mongoose.model('Goal', goalSchema);
