const mongoose = require('mongoose');

const assessmentSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Assessment title is required'],
      trim: true
    },
    type: {
      type: String,
      enum: ['Internal Test', 'Assignment', 'Practical', 'Midterm', 'Semester End Exam', 'Quiz'],
      default: 'Internal Test'
    },
    subjectRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: [true, 'Subject reference is required']
    },
    semester: {
      type: Number,
      required: [true, 'Semester is required'],
      min: 1,
      max: 8
    },
    maxMarks: {
      type: Number,
      required: [true, 'Maximum marks are required'],
      min: [1, 'Maximum marks must be at least 1']
    },
    weightagePercent: {
      type: Number,
      required: [true, 'Weightage percentage is required'],
      min: [0, 'Weightage cannot be negative'],
      max: [100, 'Weightage cannot exceed 100']
    },
    date: {
      type: Date,
      default: Date.now
    },
    description: {
      type: String,
      trim: true
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  },
  {
    timestamps: true
  }
);

assessmentSchema.index({ subjectRef: 1, semester: 1 });
assessmentSchema.index({ date: -1 });

module.exports = mongoose.model('Assessment', assessmentSchema);
