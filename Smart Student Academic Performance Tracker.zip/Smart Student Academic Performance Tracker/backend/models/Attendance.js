const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema(
  {
    studentRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: [true, 'Student reference is required']
    },
    subjectRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: [true, 'Subject reference is required']
    },
    date: {
      type: Date,
      required: [true, 'Attendance date is required']
    },
    session: {
      type: String,
      enum: ['Session 1', 'Session 2', 'Full Day'],
      default: 'Session 1'
    },
    status: {
      type: String,
      enum: ['Present', 'Absent', 'Leave'],
      required: [true, 'Attendance status is required'],
      default: 'Present'
    },
    remarks: {
      type: String,
      trim: true,
      default: ''
    },
    recordedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  },
  {
    timestamps: true
  }
);

// Prevent duplicate attendance for student + subject + normalized date string + session
attendanceSchema.index({ studentRef: 1, subjectRef: 1, date: 1, session: 1 }, { unique: true });
attendanceSchema.index({ studentRef: 1, date: -1 });

module.exports = mongoose.model('Attendance', attendanceSchema);
