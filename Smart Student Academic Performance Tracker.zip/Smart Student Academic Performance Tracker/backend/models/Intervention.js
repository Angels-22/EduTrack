const mongoose = require('mongoose');

const interventionSchema = new mongoose.Schema(
  {
    studentRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: [true, 'Student reference is required']
    },
    subjectRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      default: null
    },
    riskLevel: {
      type: String,
      enum: ['On Track', 'Needs Attention', 'High Priority'],
      required: true,
      default: 'Needs Attention'
    },
    detectedConcern: {
      type: String,
      required: true,
      trim: true
    },
    triggerRule: {
      type: String,
      required: true,
      trim: true
    },
    supportingMeasurements: {
      type: mongoose.Schema.Types.Mixed,
      default: {}
    },
    explanation: {
      whyItMatters: { type: String, default: '' },
      evidence: { type: String, default: '' },
      thresholdApplied: { type: String, default: '' }
    },
    recommendations: [
      {
        recommendationId: { type: String },
        title: { type: String, required: true },
        reason: { type: String },
        priority: { type: String, enum: ['High', 'Medium', 'Low'], default: 'Medium' },
        actionItem: { type: String, required: true },
        suggestedDeadline: { type: Date },
        isTaskCreated: { type: Boolean, default: false },
        isCompleted: { type: Boolean, default: false }
      }
    ],
    status: {
      type: String,
      enum: ['Active', 'In Progress', 'Resolved', 'Reassessed'],
      default: 'Active'
    },
    outcomeStatus: {
      type: String,
      enum: ['Concern Active', 'Observed Improvement', 'Performance Stabilized', 'Pending Next Assessment'],
      default: 'Concern Active'
    },
    reassessmentHistory: [
      {
        reassessedAt: { type: Date, default: Date.now },
        previousScore: Number,
        newScore: Number,
        observedChange: String,
        notes: String
      }
    ],
    facultyNotes: {
      type: String,
      default: '',
      trim: true
    }
  },
  {
    timestamps: true
  }
);

interventionSchema.index({ studentRef: 1, status: 1 });
interventionSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Intervention', interventionSchema);
