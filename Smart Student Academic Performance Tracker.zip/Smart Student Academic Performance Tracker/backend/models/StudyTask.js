const mongoose = require('mongoose');

const studyTaskSchema = new mongoose.Schema(
  {
    studentRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: [true, 'Student reference is required']
    },
    subjectRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      default: null
    },
    title: {
      type: String,
      required: [true, 'Task title is required'],
      trim: true
    },
    description: {
      type: String,
      trim: true,
      default: ''
    },
    priority: {
      type: String,
      enum: ['High', 'Medium', 'Low'],
      default: 'Medium'
    },
    status: {
      type: String,
      enum: ['Pending', 'In Progress', 'Completed'],
      default: 'Pending'
    },
    dueDate: {
      type: Date,
      required: [true, 'Due date is required']
    },
    estimatedHours: {
      type: Number,
      default: 2,
      min: 0.5,
      max: 100
    },
    source: {
      type: String,
      enum: ['Intervention Recommendation', 'Self Created', 'Faculty Suggested', 'Goal Action'],
      default: 'Self Created'
    },
    recommendationId: {
      type: String,
      default: null
    },
    completedAt: {
      type: Date,
      default: null
    }
  },
  {
    timestamps: true
  }
);

studyTaskSchema.index({ studentRef: 1, status: 1 });
studyTaskSchema.index({ dueDate: 1 });

module.exports = mongoose.model('StudyTask', studyTaskSchema);
