const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema(
  {
    studentId: {
      type: String,
      required: [true, 'Student ID is required'],
      unique: true,
      trim: true,
      uppercase: true
    },
    userRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null
    },
    fullName: {
      type: String,
      required: [true, 'Full name is required'],
      trim: true
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true
    },
    department: {
      type: String,
      required: [true, 'Department is required'],
      default: 'Computer Science and Engineering',
      trim: true
    },
    course: {
      type: String,
      default: 'B.Tech Information Technology',
      trim: true
    },
    semester: {
      type: Number,
      required: [true, 'Semester is required'],
      min: 1,
      max: 8
    },
    batchYear: {
      type: String,
      default: '2023-2027'
    },
    rollNo: {
      type: String,
      trim: true
    },
    contactNo: {
      type: String,
      trim: true
    },
    targetPercentage: {
      type: Number,
      default: 75,
      min: 0,
      max: 100
    },
    targetAttendance: {
      type: Number,
      default: 80,
      min: 0,
      max: 100
    },
    academicStatus: {
      type: String,
      enum: ['Active', 'Probation', 'Graduated', 'Withdrawn'],
      default: 'Active'
    }
  },
  {
    timestamps: true
  }
);

studentSchema.index({ semester: 1, department: 1 });

module.exports = mongoose.model('Student', studentSchema);
