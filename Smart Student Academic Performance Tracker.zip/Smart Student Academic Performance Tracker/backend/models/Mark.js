const mongoose = require('mongoose');
const { GRADING_SCALE } = require('../config/constants');

const markSchema = new mongoose.Schema(
  {
    studentRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: [true, 'Student reference is required']
    },
    assessmentRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Assessment',
      required: [true, 'Assessment reference is required']
    },
    subjectRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject',
      required: [true, 'Subject reference is required']
    },
    marksObtained: {
      type: Number,
      required: [true, 'Marks obtained is required'],
      min: [0, 'Marks cannot be negative']
    },
    maxMarks: {
      type: Number,
      required: [true, 'Maximum marks are required'],
      min: [1, 'Maximum marks must be at least 1']
    },
    percentage: {
      type: Number,
      min: 0,
      max: 100
    },
    grade: {
      type: String,
      default: 'RA'
    },
    feedback: {
      type: String,
      trim: true,
      default: ''
    },
    enteredBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  },
  {
    timestamps: true
  }
);

// Prevent duplicate mark entry for same student & assessment
markSchema.index({ studentRef: 1, assessmentRef: 1 }, { unique: true });
markSchema.index({ studentRef: 1, subjectRef: 1 });

// Calculate percentage & grade before save
markSchema.pre('validate', function (next) {
  if (this.marksObtained > this.maxMarks) {
    this.invalidate('marksObtained', `Marks obtained (${this.marksObtained}) cannot exceed maximum marks (${this.maxMarks})`);
  }
  if (this.maxMarks > 0 && typeof this.marksObtained === 'number') {
    this.percentage = parseFloat(((this.marksObtained / this.maxMarks) * 100).toFixed(2));
    
    // Assign grade
    const matchedGrade = GRADING_SCALE.find(
      (g) => this.percentage >= g.min && this.percentage <= g.max
    );
    this.grade = matchedGrade ? matchedGrade.grade : 'RA';
  }
  next();
});

module.exports = mongoose.model('Mark', markSchema);
