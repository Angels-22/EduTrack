const Goal = require('../models/Goal');
const StudyTask = require('../models/StudyTask');
const Mark = require('../models/Mark');
const Attendance = require('../models/Attendance');
const Student = require('../models/Student');

// @desc    Get goals for student
// @route   GET /api/goals
const getGoals = async (req, res, next) => {
  try {
    const { studentId } = req.query;
    const query = {};

    // Enforce student ownership: Students can ONLY query their own goals
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (studentId && studentId.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You are strictly authorized to view only your own academic records.'
        });
      }
      query.studentRef = req.user.studentRef;
    } else if (studentId) {
      query.studentRef = studentId;
    }

    const goals = await Goal.find(query).populate('subjectRef').sort({ deadline: 1 });
    res.status(200).json({ success: true, count: goals.length, goals });
  } catch (err) {
    next(err);
  }
};

// @desc    Create new academic goal
// @route   POST /api/goals
const createGoal = async (req, res, next) => {
  try {
    let { studentRef, subjectRef, title, category, targetValue, deadline, unit } = req.body;

    // Enforce student ownership: Students can ONLY create goals for themselves
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (studentRef && studentRef.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You cannot create goals for another student.'
        });
      }
      studentRef = req.user.studentRef;
    }

    if (!studentRef || !title || targetValue === undefined || !deadline) {
      return res.status(400).json({
        success: false,
        message: 'Please provide studentRef, title, targetValue, and deadline.'
      });
    }

    const goal = await Goal.create({
      studentRef,
      subjectRef: subjectRef || null,
      title: title.trim(),
      category: category || 'Semester Percentage',
      targetValue: parseFloat(targetValue),
      deadline: new Date(deadline),
      unit: unit || '%'
    });

    res.status(201).json({ success: true, message: 'Academic goal established.', goal });
  } catch (err) {
    next(err);
  }
};

// @desc    Update goal or progress
// @route   PUT /api/goals/:id
const updateGoal = async (req, res, next) => {
  try {
    const goal = await Goal.findById(req.params.id);
    if (!goal) {
      return res.status(404).json({ success: false, message: 'Goal not found.' });
    }

    // Enforce student ownership: Students can ONLY update their own goals
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (goal.studentRef.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You cannot modify another student\'s goal.'
        });
      }
    }

    const fields = ['title', 'category', 'targetValue', 'currentValue', 'status', 'deadline', 'reflectionNotes'];
    fields.forEach((f) => {
      if (req.body[f] !== undefined) goal[f] = req.body[f];
    });

    if (req.body.status === 'Achieved' && !goal.achievedAt) {
      goal.achievedAt = new Date();
    }

    await goal.save();
    res.status(200).json({ success: true, message: 'Goal updated.', goal });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete goal
// @route   DELETE /api/goals/:id
const deleteGoal = async (req, res, next) => {
  try {
    const goal = await Goal.findById(req.params.id);
    if (!goal) {
      return res.status(404).json({ success: false, message: 'Goal not found.' });
    }

    // Enforce student ownership: Students can ONLY delete their own goals
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (goal.studentRef.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You cannot delete another student\'s goal.'
        });
      }
    }

    await goal.deleteOne();
    res.status(200).json({ success: true, message: 'Goal deleted.' });
  } catch (err) {
    next(err);
  }
};

// @desc    Calculate verified achievements & consistency milestones
// @route   GET /api/goals/achievements/:studentId
const getAchievements = async (req, res, next) => {
  try {
    const { studentId } = req.params;

    const [goals, tasks, marks, attendanceRecords] = await Promise.all([
      Goal.find({ studentRef: studentId }),
      StudyTask.find({ studentRef: studentId }),
      Mark.find({ studentRef: studentId }).sort({ createdAt: 1 }),
      Attendance.find({ studentRef: studentId })
    ]);

    const completedTasks = tasks.filter((t) => t.status === 'Completed');
    const totalHeld = attendanceRecords.length;
    const totalAttended = attendanceRecords.filter((a) => a.status === 'Present').length;
    const attendancePercent = totalHeld > 0 ? (totalAttended / totalHeld) * 100 : 0;

    const achievements = [
      {
        id: 'ach-first-goal',
        title: 'Vision Setter',
        description: 'Established first clear academic improvement target.',
        icon: 'bi-flag-fill',
        badgeColor: 'primary',
        isUnlocked: goals.length > 0,
        progress: goals.length > 0 ? '1/1 Goal Set' : '0/1 Set an academic goal'
      },
      {
        id: 'ach-task-crusher',
        title: 'Task Crusher',
        description: 'Completed 3 or more focused study tasks.',
        icon: 'bi-check2-circle',
        badgeColor: 'success',
        isUnlocked: completedTasks.length >= 3,
        progress: `${completedTasks.length}/3 Tasks Completed`
      },
      {
        id: 'ach-attendance-guardian',
        title: 'Attendance Guardian',
        description: 'Maintained strong attendance at or above 85%.',
        icon: 'bi-shield-check',
        badgeColor: 'info',
        isUnlocked: attendancePercent >= 85 && totalHeld >= 5,
        progress: `${attendancePercent.toFixed(1)}% (Threshold: 85%)`
      },
      {
        id: 'ach-excellence-pursuit',
        title: 'Honor Ambition',
        description: 'Configured a high academic target of 80% or higher.',
        icon: 'bi-trophy-fill',
        badgeColor: 'warning',
        isUnlocked: goals.some((g) => g.targetValue >= 80),
        progress: goals.some((g) => g.targetValue >= 80) ? 'Target Verified' : 'Set a target ≥ 80%'
      },
      {
        id: 'ach-consistency-master',
        title: 'Consistent Learner',
        description: 'Completed 5 or more study planner activities.',
        icon: 'bi-stars',
        badgeColor: 'secondary',
        isUnlocked: completedTasks.length >= 5,
        progress: `${completedTasks.length}/5 Tasks Completed`
      }
    ];

    const unlockedCount = achievements.filter((a) => a.isUnlocked).length;

    res.status(200).json({
      success: true,
      unlockedCount,
      totalCount: achievements.length,
      achievements
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getGoals,
  createGoal,
  updateGoal,
  deleteGoal,
  getAchievements
};
