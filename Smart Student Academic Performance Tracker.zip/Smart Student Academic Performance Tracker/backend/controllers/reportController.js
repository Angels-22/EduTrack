const { getStudentAnalytics } = require('../services/analyticsService');
const { generateRecommendations } = require('../services/recommendationService');
const Student = require('../models/Student');
const Mark = require('../models/Mark');
const Attendance = require('../models/Attendance');
const Goal = require('../models/Goal');
const StudyTask = require('../models/StudyTask');

// @desc    Get complete structured student academic transcript/report
// @route   GET /api/reports/student/:studentId
const getStudentReportData = async (req, res, next) => {
  try {
    const { studentId } = req.params;

    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ success: false, message: 'Student not found.' });

    const [analytics, recommendationData, goals, tasks] = await Promise.all([
      getStudentAnalytics(studentId),
      generateRecommendations(studentId),
      Goal.find({ studentRef: studentId }),
      StudyTask.find({ studentRef: studentId }).sort({ dueDate: 1 })
    ]);

    const report = {
      generatedAt: new Date(),
      institution: 'EduTrack Academic Intelligence System',
      studentProfile: {
        studentId: student.studentId,
        fullName: student.fullName,
        email: student.email,
        department: student.department,
        course: student.course,
        semester: student.semester,
        batchYear: student.batchYear,
        academicStatus: student.academicStatus
      },
      academicSummary: {
        overallPercentage: analytics.overallPercentage,
        gpa: analytics.gpa,
        totalCredits: analytics.totalCredits,
        overallAttendancePercent: analytics.overallAttendancePercent,
        totalAssessmentsRecorded: analytics.totalAssessmentsRecorded
      },
      subjectPerformance: analytics.subjectPerformance,
      subjectAttendance: analytics.subjectAttendance,
      interventionStatus: {
        overallRiskLevel: recommendationData.overallRiskLevel,
        activeConcerns: recommendationData.analysis.indicators.map((i) => ({
          title: i.title,
          level: i.level,
          evidence: i.supportingMeasurements,
          nextAction: i.recommendedAction
        })),
        recommendations: recommendationData.recommendations.map((r) => ({
          title: r.title,
          priority: r.priority,
          reason: r.reason,
          actionItem: r.actionItem
        }))
      },
      goals: goals.map((g) => ({
        title: g.title,
        category: g.category,
        targetValue: g.targetValue,
        currentValue: g.currentValue,
        status: g.status,
        deadline: g.deadline
      })),
      studyTasks: {
        total: tasks.length,
        completed: tasks.filter((t) => t.status === 'Completed').length,
        pending: tasks.filter((t) => t.status !== 'Completed').length
      }
    };

    res.status(200).json({ success: true, report });
  } catch (err) {
    next(err);
  }
};

// @desc    Export student marks to CSV format
// @route   GET /api/reports/export/marks-csv/:studentId
const exportMarksCsv = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ success: false, message: 'Student not found.' });

    const marks = await Mark.find({ studentRef: studentId })
      .populate('subjectRef')
      .populate('assessmentRef')
      .sort({ createdAt: 1 });

    let csv = 'Student ID,Student Name,Subject Code,Subject Name,Assessment,Marks Obtained,Max Marks,Percentage,Grade,Date\n';

    marks.forEach((m) => {
      const subCode = m.subjectRef ? m.subjectRef.code : 'N/A';
      const subName = m.subjectRef ? `"${m.subjectRef.name.replace(/"/g, '""')}"` : 'N/A';
      const assTitle = m.assessmentRef ? `"${m.assessmentRef.title.replace(/"/g, '""')}"` : 'N/A';
      const dateStr = m.assessmentRef && m.assessmentRef.date ? new Date(m.assessmentRef.date).toISOString().split('T')[0] : '';

      csv += `${student.studentId},"${student.fullName}",${subCode},${subName},${assTitle},${m.marksObtained},${m.maxMarks},${m.percentage}%,${m.grade},${dateStr}\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=marks_${student.studentId}.csv`);
    res.status(200).send(csv);
  } catch (err) {
    next(err);
  }
};

// @desc    Export student attendance to CSV format
// @route   GET /api/reports/export/attendance-csv/:studentId
const exportAttendanceCsv = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ success: false, message: 'Student not found.' });

    const records = await Attendance.find({ studentRef: studentId })
      .populate('subjectRef')
      .sort({ date: 1 });

    let csv = 'Student ID,Student Name,Subject Code,Subject Name,Date,Session,Status,Remarks\n';

    records.forEach((r) => {
      const subCode = r.subjectRef ? r.subjectRef.code : 'N/A';
      const subName = r.subjectRef ? `"${r.subjectRef.name.replace(/"/g, '""')}"` : 'N/A';
      const dateStr = r.date ? new Date(r.date).toISOString().split('T')[0] : '';
      const remarks = r.remarks ? `"${r.remarks.replace(/"/g, '""')}"` : '';

      csv += `${student.studentId},"${student.fullName}",${subCode},${subName},${dateStr},${r.session},${r.status},${remarks}\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=attendance_${student.studentId}.csv`);
    res.status(200).send(csv);
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getStudentReportData,
  exportMarksCsv,
  exportAttendanceCsv
};
