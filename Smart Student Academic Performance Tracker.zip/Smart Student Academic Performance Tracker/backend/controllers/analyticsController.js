const { getStudentAnalytics } = require('../services/analyticsService');
const Student = require('../models/Student');
const Mark = require('../models/Mark');
const Attendance = require('../models/Attendance');
const Subject = require('../models/Subject');

// @desc    Get detailed analytics for a student
// @route   GET /api/analytics/student/:studentId
const getStudentAnalyticsData = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const analytics = await getStudentAnalytics(studentId);
    res.status(200).json({ success: true, analytics });
  } catch (err) {
    next(err);
  }
};

// @desc    Get batch / institutional academic overview (Admin & Faculty)
// @route   GET /api/analytics/overview
const getInstitutionalAnalytics = async (req, res, next) => {
  try {
    const [totalStudents, totalSubjects, totalMarks, totalAttendance] = await Promise.all([
      Student.countDocuments({ academicStatus: 'Active' }),
      Subject.countDocuments(),
      Mark.countDocuments(),
      Attendance.countDocuments()
    ]);

    // Average performance across all marks
    const marksAgg = await Mark.aggregate([
      {
        $group: {
          _id: null,
          avgPercentage: { $avg: '$percentage' },
          totalMarksCount: { $sum: 1 }
        }
      }
    ]);

    // Average attendance rate across all records
    const attAgg = await Attendance.aggregate([
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          present: {
            $sum: { $cond: [{ $eq: ['$status', 'Present'] }, 1, 0] }
          }
        }
      }
    ]);

    const averagePerformance = marksAgg.length > 0 ? parseFloat(marksAgg[0].avgPercentage.toFixed(1)) : 0;
    const overallAttendanceRate = attAgg.length > 0 && attAgg[0].total > 0
      ? parseFloat(((attAgg[0].present / attAgg[0].total) * 100).toFixed(1))
      : 0;

    res.status(200).json({
      success: true,
      stats: {
        totalStudents,
        totalSubjects,
        totalMarksRecorded: totalMarks,
        totalAttendanceSessions: totalAttendance,
        averagePerformance,
        overallAttendanceRate
      }
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getStudentAnalyticsData,
  getInstitutionalAnalytics
};
