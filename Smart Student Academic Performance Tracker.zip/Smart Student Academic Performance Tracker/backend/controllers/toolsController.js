const { simulateGrade } = require('../services/gradeSimulatorService');
const { calculateAttendanceRecovery } = require('../services/attendanceCalculatorService');
const Mark = require('../models/Mark');
const Assessment = require('../models/Assessment');
const Attendance = require('../models/Attendance');
const Student = require('../models/Student');
const Subject = require('../models/Subject');

// @desc    Simulate grade calculation via API
// @route   POST /api/tools/grade-simulator
const runGradeSimulator = async (req, res, next) => {
  try {
    const { completedAssessments, remainingAssessments, targetPercent } = req.body;
    const result = simulateGrade({ completedAssessments, remainingAssessments, targetPercent });
    res.status(200).json({ success: true, result });
  } catch (err) {
    next(err);
  }
};

// @desc    Simulate attendance recovery calculation via API
// @route   POST /api/tools/attendance-recovery
const runAttendanceRecovery = async (req, res, next) => {
  try {
    const { attended, total, targetPercent } = req.body;
    const result = calculateAttendanceRecovery({ attended, total, targetPercent });
    res.status(200).json({ success: true, result });
  } catch (err) {
    next(err);
  }
};

// @desc    Preload student data into Attendance Recovery Calculator
// @route   GET /api/tools/preload-attendance/:studentId
const preloadStudentAttendance = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const { subjectId } = req.query;

    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ success: false, message: 'Student not found' });

    const query = { studentRef: studentId };
    if (subjectId) query.subjectRef = subjectId;

    const records = await Attendance.find(query);
    const total = records.length;
    const attended = records.filter((r) => r.status === 'Present').length;
    const targetPercent = student.targetAttendance || 75;

    const recovery = calculateAttendanceRecovery({ attended, total, targetPercent });

    res.status(200).json({
      success: true,
      studentName: student.fullName,
      attended,
      total,
      targetPercent,
      recovery
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Preload student subject data into What-If Grade Simulator
// @route   GET /api/tools/preload-grade-simulator/:studentId/:subjectId
const preloadStudentSubjectGrades = async (req, res, next) => {
  try {
    const { studentId, subjectId } = req.params;

    const student = await Student.findById(studentId);
    const subject = await Subject.findById(subjectId);
    if (!student || !subject) {
      return res.status(404).json({ success: false, message: 'Student or Subject not found' });
    }

    // Get all assessments configured for this subject
    const assessments = await Assessment.find({ subjectRef: subjectId }).sort({ date: 1 });
    const marks = await Mark.find({ studentRef: studentId, subjectRef: subjectId });

    const marksMap = {};
    marks.forEach((m) => {
      marksMap[m.assessmentRef.toString()] = m;
    });

    const completed = [];
    const remaining = [];

    assessments.forEach((ass) => {
      const markEntry = marksMap[ass._id.toString()];
      if (markEntry) {
        completed.push({
          title: ass.title,
          weight: ass.weightagePercent,
          scorePercent: markEntry.percentage,
          marksObtained: markEntry.marksObtained,
          maxMarks: markEntry.maxMarks
        });
      } else {
        remaining.push({
          title: ass.title,
          weight: ass.weightagePercent,
          hypotheticalScorePercent: 75 // default hypothetical placeholder
        });
      }
    });

    const simulation = simulateGrade({
      completedAssessments: completed,
      remainingAssessments: remaining,
      targetPercent: student.targetPercentage || 75
    });

    res.status(200).json({
      success: true,
      student: { id: student._id, fullName: student.fullName, targetPercentage: student.targetPercentage },
      subject: { id: subject._id, code: subject.code, name: subject.name },
      completedAssessments: completed,
      remainingAssessments: remaining,
      simulation
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  runGradeSimulator,
  runAttendanceRecovery,
  preloadStudentAttendance,
  preloadStudentSubjectGrades
};
