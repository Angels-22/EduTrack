const Assessment = require('../models/Assessment');
const Mark = require('../models/Mark');
const { logAction } = require('../services/auditService');

// @desc    Get assessments with filters
// @route   GET /api/assessments
const getAllAssessments = async (req, res, next) => {
  try {
    const { subjectId, semester } = req.query;
    const query = {};
    if (subjectId) query.subjectRef = subjectId;
    if (semester) query.semester = parseInt(semester, 10);

    const assessments = await Assessment.find(query)
      .populate('subjectRef')
      .sort({ date: -1 });

    res.status(200).json({ success: true, count: assessments.length, assessments });
  } catch (err) {
    next(err);
  }
};

// @desc    Create new assessment
// @route   POST /api/assessments
const createAssessment = async (req, res, next) => {
  try {
    const { title, type, subjectRef, semester, maxMarks, weightagePercent, date, description } = req.body;

    if (!title || !subjectRef || !semester || !maxMarks || weightagePercent === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Please provide Title, Subject, Semester, Max Marks, and Weightage Percentage.'
      });
    }

    if (parseFloat(maxMarks) <= 0) {
      return res.status(400).json({ success: false, message: 'Max marks must be greater than 0.' });
    }

    if (parseFloat(weightagePercent) < 0 || parseFloat(weightagePercent) > 100) {
      return res.status(400).json({ success: false, message: 'Weightage percentage must be between 0 and 100.' });
    }

    const assessment = await Assessment.create({
      title: title.trim(),
      type: type || 'Internal Test',
      subjectRef,
      semester: parseInt(semester, 10),
      maxMarks: parseFloat(maxMarks),
      weightagePercent: parseFloat(weightagePercent),
      date: date ? new Date(date) : new Date(),
      description: description ? description.trim() : '',
      createdBy: req.user._id
    });

    await logAction({
      req,
      action: 'CREATE_ASSESSMENT',
      resource: 'Assessment',
      resourceId: assessment._id,
      details: { title: assessment.title, subjectRef }
    });

    res.status(201).json({ success: true, message: 'Assessment created successfully.', assessment });
  } catch (err) {
    next(err);
  }
};

// @desc    Update assessment
// @route   PUT /api/assessments/:id
const updateAssessment = async (req, res, next) => {
  try {
    const assessment = await Assessment.findById(req.params.id);
    if (!assessment) {
      return res.status(404).json({ success: false, message: 'Assessment not found.' });
    }

    const fields = ['title', 'type', 'maxMarks', 'weightagePercent', 'date', 'description', 'semester'];
    fields.forEach((f) => {
      if (req.body[f] !== undefined) assessment[f] = req.body[f];
    });

    await assessment.save();

    res.status(200).json({ success: true, message: 'Assessment updated successfully.', assessment });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete assessment
// @route   DELETE /api/assessments/:id
const deleteAssessment = async (req, res, next) => {
  try {
    const assessment = await Assessment.findById(req.params.id);
    if (!assessment) {
      return res.status(404).json({ success: false, message: 'Assessment not found.' });
    }

    await Mark.deleteMany({ assessmentRef: assessment._id });
    await assessment.deleteOne();

    await logAction({
      req,
      action: 'DELETE_ASSESSMENT',
      resource: 'Assessment',
      resourceId: req.params.id,
      details: { title: assessment.title }
    });

    res.status(200).json({ success: true, message: 'Assessment and associated student marks deleted.' });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAllAssessments,
  createAssessment,
  updateAssessment,
  deleteAssessment
};
