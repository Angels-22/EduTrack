const Mark = require('../models/Mark');
const Assessment = require('../models/Assessment');
const Student = require('../models/Student');
const { syncStudentInterventions } = require('../services/interventionWorkflowService');
const { logAction } = require('../services/auditService');

// @desc    Get marks with filters
// @route   GET /api/marks
const getMarks = async (req, res, next) => {
  try {
    const { studentId, subjectId, assessmentId } = req.query;
    const query = {};

    // Enforce student ownership: Students can ONLY query their own marks
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (studentId && studentId.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You are strictly authorized to view only your own academic records.'
        });
      }
      query.studentRef = req.user.studentRef;
    } else if (studentId) {
      query.studentRef = studentId;
    }

    if (subjectId) query.subjectRef = subjectId;
    if (assessmentId) query.assessmentRef = assessmentId;

    const marks = await Mark.find(query)
      .populate('studentRef')
      .populate('subjectRef')
      .populate('assessmentRef')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: marks.length, marks });
  } catch (err) {
    next(err);
  }
};

// @desc    Get marks for a specific student
// @route   GET /api/marks/student/:studentId
const getMarksByStudent = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const marks = await Mark.find({ studentRef: studentId })
      .populate('subjectRef')
      .populate('assessmentRef')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: marks.length, marks });
  } catch (err) {
    next(err);
  }
};

// @desc    Enter or Update mark for a student & assessment
// @route   POST /api/marks
const enterOrUpdateMark = async (req, res, next) => {
  try {
    const { studentRef, assessmentRef, subjectRef, marksObtained, feedback } = req.body;

    if (!studentRef || !assessmentRef || marksObtained === undefined || marksObtained === null || marksObtained === '') {
      return res.status(400).json({
        success: false,
        message: 'Please provide studentRef, assessmentRef, and marksObtained.'
      });
    }

    const mongoose = require('mongoose');
    if (!mongoose.Types.ObjectId.isValid(studentRef) || !mongoose.Types.ObjectId.isValid(assessmentRef)) {
      return res.status(400).json({ success: false, message: 'Invalid studentRef or assessmentRef identifier format.' });
    }

    // Verify student exists
    const student = await Student.findById(studentRef);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Referenced student record does not exist.' });
    }

    // Verify assessment exists and obtain maxMarks & subject
    const assessment = await Assessment.findById(assessmentRef);
    if (!assessment) {
      return res.status(404).json({ success: false, message: 'Referenced assessment record does not exist.' });
    }

    const maxMarks = assessment.maxMarks;
    const obtained = parseFloat(marksObtained);

    if (isNaN(obtained)) {
      return res.status(400).json({ success: false, message: 'Marks obtained must be a valid numeric value.' });
    }

    if (obtained < 0) {
      return res.status(400).json({ success: false, message: 'Marks obtained cannot be negative.' });
    }

    if (obtained > maxMarks) {
      return res.status(400).json({
        success: false,
        message: `Marks obtained (${obtained}) cannot exceed maximum marks (${maxMarks}).`
      });
    }

    const subId = subjectRef || assessment.subjectRef;

    // Check if mark already exists for student + assessment
    let mark = await Mark.findOne({ studentRef, assessmentRef });

    if (mark) {
      mark.marksObtained = obtained;
      mark.maxMarks = maxMarks;
      mark.feedback = feedback ? feedback.trim() : mark.feedback;
      mark.enteredBy = req.user._id;
      await mark.save();
    } else {
      mark = await Mark.create({
        studentRef,
        assessmentRef,
        subjectRef: subId,
        marksObtained: obtained,
        maxMarks,
        feedback: feedback ? feedback.trim() : '',
        enteredBy: req.user._id
      });
    }

    // Reassess intervention status automatically
    try {
      await syncStudentInterventions(studentRef);
    } catch (intervErr) {
      console.warn('[Intervention Reassessment Warning]', intervErr.message);
    }

    await logAction({
      req,
      action: 'ENTER_MARK',
      resource: 'Mark',
      resourceId: mark._id,
      details: { studentRef, assessmentRef, marksObtained: obtained, maxMarks }
    });

    res.status(200).json({
      success: true,
      message: 'Assessment marks saved successfully and academic analytics updated.',
      mark
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete mark
// @route   DELETE /api/marks/:id
const deleteMark = async (req, res, next) => {
  try {
    const mark = await Mark.findById(req.params.id);
    if (!mark) {
      return res.status(404).json({ success: false, message: 'Mark entry not found.' });
    }

    const studentId = mark.studentRef;
    await mark.deleteOne();

    // Reassess intervention after mark deletion
    try {
      await syncStudentInterventions(studentId);
    } catch (e) {
      console.warn('[Reassessment Warning]', e.message);
    }

    res.status(200).json({ success: true, message: 'Mark entry deleted.' });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getMarks,
  getMarksByStudent,
  enterOrUpdateMark,
  deleteMark
};
