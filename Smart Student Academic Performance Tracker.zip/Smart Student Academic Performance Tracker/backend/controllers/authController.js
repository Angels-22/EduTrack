const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Student = require('../models/Student');
const { logAction } = require('../services/auditService');
const { getJwtSecret } = require('../config/envValidator');

const generateToken = (user) => {
  const secret = getJwtSecret();
  const expiresIn = process.env.JWT_EXPIRES_IN || '7d';
  return jwt.sign(
    {
      id: user._id,
      email: user.email,
      role: user.role,
      name: user.name
    },
    secret,
    { expiresIn }
  );
};

// @desc    Register a new user
// @route   POST /api/auth/register
const register = async (req, res, next) => {
  try {
    const { name, email, password, role, department, studentId, semester } = req.body;

    // 1. Validate required fields
    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Please provide your full name.' });
    }

    if (!email || !email.trim()) {
      return res.status(400).json({ success: false, message: 'Please provide an institutional email address.' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return res.status(400).json({ success: false, message: 'Please provide a valid email address format (e.g. name@institution.edu).' });
    }

    if (!password || typeof password !== 'string') {
      return res.status(400).json({ success: false, message: 'Please provide a password.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
    }

    const normalizedEmail = email.toLowerCase().trim();

    // 2. Prevent duplicate user registrations
    const existingUser = await User.findOne({ email: normalizedEmail });
    if (existingUser) {
      return res.status(409).json({ success: false, message: 'A user account with this email address already exists. Please sign in.' });
    }

    // 3. Security Enforcement: Public self-registration is strictly restricted to student accounts only.
    if (role && role !== 'student') {
      return res.status(400).json({
        success: false,
        message: 'Public registration is restricted to student accounts only. Faculty and administrator accounts must be provisioned by an institution administrator.'
      });
    }

    const assignedRole = 'student';

    // 4. Secure Student Account-Linking Verification
    // Prevent account hijacking: Never allow a public registrant to link to an existing student record
    // merely by supplying or guessing a student ID.
    const sId = studentId ? studentId.trim().toUpperCase() : `STU${Date.now().toString().slice(-6)}`;
    let studentDoc = await Student.findOne({ studentId: sId });

    if (studentDoc) {
      // If student record exists, verify it doesn't already belong to an active user account
      if (studentDoc.userRef) {
        return res.status(409).json({
          success: false,
          message: `Student ID "${sId}" is already linked to an existing registered user account. Please sign in or contact your department.`
        });
      }

      // Cryptographic/Identity Verification: The email on the official student record MUST strictly match the registration email
      if (studentDoc.email.toLowerCase().trim() !== normalizedEmail) {
        return res.status(403).json({
          success: false,
          message: `Account linking verification failed: The email address provided does not match the official institutional record on file for Student ID "${sId}". Contact your academic advisor.`
        });
      }
    }

    // 5. Create new User account
    const newUser = new User({
      name: name.trim(),
      email: normalizedEmail,
      password,
      role: assignedRole,
      department: department || (studentDoc ? studentDoc.department : 'Computer Science and Engineering')
    });

    await newUser.save();

    // 6. Link or create the Student profile
    if (studentDoc) {
      // Securely link verified existing student record
      studentDoc.userRef = newUser._id;
      if (!studentDoc.fullName) studentDoc.fullName = newUser.name;
      await studentDoc.save();
      newUser.studentRef = studentDoc._id;
      await newUser.save();
    } else {
      // Create new student profile
      studentDoc = await Student.create({
        studentId: sId,
        userRef: newUser._id,
        fullName: newUser.name,
        email: newUser.email,
        department: newUser.department,
        semester: semester ? parseInt(semester, 10) : 5
      });
      newUser.studentRef = studentDoc._id;
      await newUser.save();
    }

    const token = generateToken(newUser);

    await logAction({
      req,
      action: 'USER_REGISTER',
      resource: 'User',
      resourceId: newUser._id,
      details: { email: newUser.email, role: newUser.role }
    });

    res.status(201).json({
      success: true,
      message: 'Account successfully registered.',
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        department: newUser.department,
        studentRef: newUser.studentRef
      }
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Login user
// @route   POST /api/auth/login
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide email and password.' });
    }

    const user = await User.findOne({ email: email.toLowerCase().trim() }).populate('studentRef');
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    user.lastLogin = new Date();
    await user.save();

    const token = generateToken(user);

    await logAction({
      req: { ...req, user },
      action: 'USER_LOGIN',
      resource: 'User',
      resourceId: user._id,
      details: { email: user.email, role: user.role }
    });

    res.status(200).json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        department: user.department,
        studentRef: user.studentRef
      }
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Demo Quick-Login for Project Examiners and Evaluation (Restricted in Production)
// @route   POST /api/auth/demo-login
const demoLogin = async (req, res, next) => {
  try {
    // Security restriction: demo-login bypasses passwords and is strictly forbidden in production
    // Even if an environment variable is set to enable it, production builds unconditionally disallow demo login.
    if (process.env.NODE_ENV === 'production') {
      return res.status(403).json({
        success: false,
        message: 'Demo login is strictly disabled in production environments. Please sign in with registered credentials.'
      });
    }

    const { role } = req.body;
    const targetRole = ['admin', 'faculty', 'student'].includes(role) ? role : 'student';

    // Find demonstration account matching role
    let user = await User.findOne({ role: targetRole }).populate('studentRef');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: `No demo account found for role '${targetRole}'. Please run 'npm run seed' first.`
      });
    }

    const token = generateToken(user);

    res.status(200).json({
      success: true,
      message: `Switched to ${targetRole} evaluation session.`,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        department: user.department,
        studentRef: user.studentRef
      }
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get currently logged in user profile
// @route   GET /api/auth/me
const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id).populate('studentRef');
    res.status(200).json({
      success: true,
      user
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Update user profile & preferences
// @route   PUT /api/auth/profile
const updateProfile = async (req, res, next) => {
  try {
    const { name, department, currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id);

    if (name) user.name = name.trim();
    if (department) user.department = department.trim();

    if (newPassword) {
      if (!currentPassword) {
        return res.status(400).json({ success: false, message: 'Current password is required to set a new password.' });
      }
      const isMatch = await user.comparePassword(currentPassword);
      if (!isMatch) {
        return res.status(400).json({ success: false, message: 'Current password incorrect.' });
      }
      if (newPassword.length < 6) {
        return res.status(400).json({ success: false, message: 'New password must be at least 6 characters.' });
      }
      user.password = newPassword;
    }

    await user.save();

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully.',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        department: user.department
      }
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  register,
  login,
  demoLogin,
  getMe,
  updateProfile
};
