const Subject = require('../models/Subject');
const Assessment = require('../models/Assessment');
const Mark = require('../models/Mark');
const Attendance = require('../models/Attendance');
const { logAction } = require('../services/auditService');

// @desc    Get all subjects with filters
// @route   GET /api/subjects
const getAllSubjects = async (req, res, next) => {
  try {
    const { semester, department, search } = req.query;
    const query = {};

    if (semester) query.semester = parseInt(semester, 10);
    if (department) query.department = department;
    if (search) {
      const regex = new RegExp(search.trim(), 'i');
      query.$or = [{ name: regex }, { code: regex }];
    }

    const subjects = await Subject.find(query).sort({ semester: 1, code: 1 });
    res.status(200).json({ success: true, count: subjects.length, subjects });
  } catch (err) {
    next(err);
  }
};

// @desc    Get single subject by ID
// @route   GET /api/subjects/:id
const getSubjectById = async (req, res, next) => {
  try {
    const subject = await Subject.findById(req.params.id);
    if (!subject) {
      return res.status(404).json({ success: false, message: 'Subject not found.' });
    }
    res.status(200).json({ success: true, subject });
  } catch (err) {
    next(err);
  }
};

// @desc    Create subject (Admin / Faculty)
// @route   POST /api/subjects
const createSubject = async (req, res, next) => {
  try {
    const { code, name, department, semester, credits, facultyName, description, maxMarks, passingMarks } = req.body;

    if (!code || !name || !semester) {
      return res.status(400).json({ success: false, message: 'Subject code, name, and semester are required.' });
    }

    const existing = await Subject.findOne({ code: code.trim().toUpperCase() });
    if (existing) {
      return res.status(409).json({ success: false, message: `Subject with code '${code}' already exists.` });
    }

    const subject = await Subject.create({
      code: code.trim().toUpperCase(),
      name: name.trim(),
      department: department || 'Computer Science and Engineering',
      semester: parseInt(semester, 10),
      credits: credits ? parseInt(credits, 10) : 3,
      facultyName: facultyName ? facultyName.trim() : '',
      description: description ? description.trim() : '',
      maxMarks: maxMarks ? parseInt(maxMarks, 10) : 100,
      passingMarks: passingMarks ? parseInt(passingMarks, 10) : 40
    });

    await logAction({
      req,
      action: 'CREATE_SUBJECT',
      resource: 'Subject',
      resourceId: subject._id,
      details: { code: subject.code, name: subject.name }
    });

    res.status(201).json({ success: true, message: 'Subject created successfully.', subject });
  } catch (err) {
    next(err);
  }
};

// @desc    Update subject
// @route   PUT /api/subjects/:id
const updateSubject = async (req, res, next) => {
  try {
    const subject = await Subject.findById(req.params.id);
    if (!subject) {
      return res.status(404).json({ success: false, message: 'Subject not found.' });
    }

    const fields = ['name', 'department', 'semester', 'credits', 'facultyName', 'description', 'maxMarks', 'passingMarks'];
    fields.forEach((f) => {
      if (req.body[f] !== undefined) {
        subject[f] = req.body[f];
      }
    });

    await subject.save();

    await logAction({
      req,
      action: 'UPDATE_SUBJECT',
      resource: 'Subject',
      resourceId: subject._id,
      details: { code: subject.code }
    });

    res.status(200).json({ success: true, message: 'Subject updated successfully.', subject });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete subject
// @route   DELETE /api/subjects/:id
const deleteSubject = async (req, res, next) => {
  try {
    const subject = await Subject.findById(req.params.id);
    if (!subject) {
      return res.status(404).json({ success: false, message: 'Subject not found.' });
    }

    await Assessment.deleteMany({ subjectRef: subject._id });
    await Mark.deleteMany({ subjectRef: subject._id });
    await Attendance.deleteMany({ subjectRef: subject._id });
    await subject.deleteOne();

    await logAction({
      req,
      action: 'DELETE_SUBJECT',
      resource: 'Subject',
      resourceId: req.params.id,
      details: { code: subject.code }
    });

    res.status(200).json({ success: true, message: 'Subject and linked records deleted.' });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAllSubjects,
  getSubjectById,
  createSubject,
  updateSubject,
  deleteSubject
};
