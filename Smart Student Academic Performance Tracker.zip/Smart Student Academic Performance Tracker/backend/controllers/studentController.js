const Student = require('../models/Student');
const Mark = require('../models/Mark');
const Attendance = require('../models/Attendance');
const StudyTask = require('../models/StudyTask');
const Goal = require('../models/Goal');
const Intervention = require('../models/Intervention');
const { logAction } = require('../services/auditService');

// @desc    Get all students with search & filter
// @route   GET /api/students
const getAllStudents = async (req, res, next) => {
  try {
    const { search, department, semester, status, page = 1, limit = 50 } = req.query;

    const query = {};
    if (search) {
      const regex = new RegExp(search.trim(), 'i');
      query.$or = [{ fullName: regex }, { studentId: regex }, { email: regex }, { rollNo: regex }];
    }
    if (department) query.department = department;
    if (semester) query.semester = parseInt(semester, 10);
    if (status) query.academicStatus = status;

    const skip = (parseInt(page, 10) - 1) * parseInt(limit, 10);
    const total = await Student.countDocuments(query);
    const students = await Student.find(query).sort({ studentId: 1 }).skip(skip).limit(parseInt(limit, 10));

    res.status(200).json({
      success: true,
      total,
      page: parseInt(page, 10),
      pages: Math.ceil(total / parseInt(limit, 10)),
      students
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get single student by ID
// @route   GET /api/students/:id
const getStudentById = async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student record not found.' });
    }
    res.status(200).json({ success: true, student });
  } catch (err) {
    next(err);
  }
};

// @desc    Create a new student
// @route   POST /api/students
const createStudent = async (req, res, next) => {
  try {
    const { studentId, fullName, email, department, course, semester, batchYear, rollNo, contactNo, targetPercentage, targetAttendance } = req.body;

    if (!studentId || !fullName || !email || !semester) {
      return res.status(400).json({ success: false, message: 'Please provide Student ID, Full Name, Email, and Semester.' });
    }

    const existing = await Student.findOne({
      $or: [{ studentId: studentId.trim().toUpperCase() }, { email: email.toLowerCase().trim() }]
    });

    if (existing) {
      return res.status(409).json({ success: false, message: 'A student with this Student ID or Email already exists.' });
    }

    const student = await Student.create({
      studentId: studentId.trim().toUpperCase(),
      fullName: fullName.trim(),
      email: email.toLowerCase().trim(),
      department: department || 'Computer Science and Engineering',
      course: course || 'B.Tech / B.E.',
      semester: parseInt(semester, 10),
      batchYear: batchYear || '2023-2027',
      rollNo: rollNo ? rollNo.trim() : '',
      contactNo: contactNo ? contactNo.trim() : '',
      targetPercentage: targetPercentage ? parseFloat(targetPercentage) : 75,
      targetAttendance: targetAttendance ? parseFloat(targetAttendance) : 80
    });

    await logAction({
      req,
      action: 'CREATE_STUDENT',
      resource: 'Student',
      resourceId: student._id,
      details: { studentId: student.studentId, fullName: student.fullName }
    });

    res.status(201).json({ success: true, message: 'Student created successfully.', student });
  } catch (err) {
    next(err);
  }
};

// @desc    Update student details
// @route   PUT /api/students/:id
const updateStudent = async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student record not found.' });
    }

    const isStudent = req.user && req.user.role === 'student';

    // Role-based field authorization: Students cannot alter institutional status or enrollment data
    if (isStudent) {
      const restrictedFields = ['academicStatus', 'department', 'course', 'semester', 'batchYear', 'fullName', 'rollNo'];
      const attemptedRestricted = restrictedFields.filter((f) => req.body[f] !== undefined);
      if (attemptedRestricted.length > 0) {
        return res.status(403).json({
          success: false,
          message: `Access Denied: Students are not authorized to modify institutional academic records (${attemptedRestricted.join(', ')}).`
        });
      }
    }

    const fields = isStudent
      ? ['contactNo', 'targetPercentage', 'targetAttendance']
      : [
          'fullName', 'department', 'course', 'semester', 'batchYear',
          'rollNo', 'contactNo', 'targetPercentage', 'targetAttendance', 'academicStatus'
        ];

    fields.forEach((f) => {
      if (req.body[f] !== undefined) {
        student[f] = req.body[f];
      }
    });

    await student.save();

    await logAction({
      req,
      action: 'UPDATE_STUDENT',
      resource: 'Student',
      resourceId: student._id,
      details: { studentId: student.studentId }
    });

    res.status(200).json({ success: true, message: 'Student updated successfully.', student });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete student (Admin only)
// @route   DELETE /api/students/:id
const deleteStudent = async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student record not found.' });
    }

    // Cascade delete related records
    await Mark.deleteMany({ studentRef: student._id });
    await Attendance.deleteMany({ studentRef: student._id });
    await StudyTask.deleteMany({ studentRef: student._id });
    await Goal.deleteMany({ studentRef: student._id });
    await Intervention.deleteMany({ studentRef: student._id });
    await student.deleteOne();

    await logAction({
      req,
      action: 'DELETE_STUDENT',
      resource: 'Student',
      resourceId: req.params.id,
      details: { studentId: student.studentId, name: student.fullName }
    });

    res.status(200).json({ success: true, message: 'Student record and associated academic data deleted.' });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent
};
