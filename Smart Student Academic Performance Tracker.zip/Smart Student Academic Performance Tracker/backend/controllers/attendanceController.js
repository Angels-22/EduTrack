const Attendance = require('../models/Attendance');
const Student = require('../models/Student');
const Subject = require('../models/Subject');
const { syncStudentInterventions } = require('../services/interventionWorkflowService');
const { logAction } = require('../services/auditService');

// @desc    Get attendance records with filtering
// @route   GET /api/attendance
const getAttendance = async (req, res, next) => {
  try {
    const { studentId, subjectId, startDate, endDate, status, session } = req.query;
    const query = {};

    // Enforce student ownership: Students can ONLY query their own attendance
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (studentId && studentId.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You are strictly authorized to view only your own academic records.'
        });
      }
      query.studentRef = req.user.studentRef;
    } else if (studentId) {
      query.studentRef = studentId;
    }
    if (subjectId) query.subjectRef = subjectId;
    if (status) query.status = status;
    if (session) query.session = session;

    if (startDate || endDate) {
      query.date = {};
      if (startDate) query.date.$gte = new Date(startDate);
      if (endDate) query.date.$lte = new Date(endDate);
    }

    const records = await Attendance.find(query)
      .populate('studentRef')
      .populate('subjectRef')
      .sort({ date: -1 });

    res.status(200).json({ success: true, count: records.length, records });
  } catch (err) {
    next(err);
  }
};

// @desc    Record or Update single attendance entry
// @route   POST /api/attendance
const recordAttendance = async (req, res, next) => {
  try {
    const { studentRef, subjectRef, date, session = 'Session 1', status = 'Present', remarks } = req.body;

    if (!studentRef || !subjectRef || !date) {
      return res.status(400).json({
        success: false,
        message: 'Please provide studentRef, subjectRef, and date.'
      });
    }

    const mongoose = require('mongoose');
    if (!mongoose.Types.ObjectId.isValid(studentRef) || !mongoose.Types.ObjectId.isValid(subjectRef)) {
      return res.status(400).json({ success: false, message: 'Invalid studentRef or subjectRef identifier format.' });
    }

    const validStatuses = ['Present', 'Absent', 'Leave', 'Late'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: `Invalid attendance status '${status}'. Permitted: ${validStatuses.join(', ')}.` });
    }

    const rawDate = new Date(date);
    if (isNaN(rawDate.getTime())) {
      return res.status(400).json({ success: false, message: 'Invalid attendance date format provided.' });
    }

    // Verify student and subject records exist
    const [studentExists, subjectExists] = await Promise.all([
      Student.findById(studentRef),
      Subject.findById(subjectRef)
    ]);

    if (!studentExists) {
      return res.status(404).json({ success: false, message: 'Referenced student record does not exist.' });
    }
    if (!subjectExists) {
      return res.status(404).json({ success: false, message: 'Referenced subject record does not exist.' });
    }

    // Normalize date to remove time component for consistent daily duplicate prevention
    const normalizedDate = new Date(Date.UTC(rawDate.getUTCFullYear(), rawDate.getUTCMonth(), rawDate.getUTCDate()));

    let attendance = await Attendance.findOne({
      studentRef,
      subjectRef,
      date: normalizedDate,
      session
    });

    if (attendance) {
      attendance.status = status;
      attendance.remarks = remarks !== undefined ? remarks.trim() : attendance.remarks;
      attendance.recordedBy = req.user._id;
      await attendance.save();
    } else {
      attendance = await Attendance.create({
        studentRef,
        subjectRef,
        date: normalizedDate,
        session,
        status,
        remarks: remarks ? remarks.trim() : '',
        recordedBy: req.user._id
      });
    }

    // Reassess intervention status after attendance update
    try {
      await syncStudentInterventions(studentRef);
    } catch (e) {
      console.warn('[Attendance Reassessment Warning]', e.message);
    }

    await logAction({
      req,
      action: 'RECORD_ATTENDANCE',
      resource: 'Attendance',
      resourceId: attendance._id,
      details: { studentRef, subjectRef, status, session }
    });

    res.status(200).json({
      success: true,
      message: 'Attendance recorded successfully.',
      attendance
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Record bulk attendance for multiple students
// @route   POST /api/attendance/bulk
const recordBulkAttendance = async (req, res, next) => {
  try {
    const { subjectRef, date, session = 'Session 1', studentStatuses } = req.body;
    // studentStatuses: [{ studentRef, status, remarks }]

    if (!subjectRef || !date || !Array.isArray(studentStatuses)) {
      return res.status(400).json({
        success: false,
        message: 'Subject, Date, and studentStatuses array are required.'
      });
    }

    const rawDate = new Date(date);
    const normalizedDate = new Date(Date.UTC(rawDate.getUTCFullYear(), rawDate.getUTCMonth(), rawDate.getUTCDate()));

    const results = [];
    const affectedStudents = new Set();

    for (const item of studentStatuses) {
      if (!item.studentRef) continue;
      affectedStudents.add(item.studentRef);

      const updated = await Attendance.findOneAndUpdate(
        { studentRef: item.studentRef, subjectRef, date: normalizedDate, session },
        {
          $set: {
            status: item.status || 'Present',
            remarks: item.remarks ? item.remarks.trim() : '',
            recordedBy: req.user._id
          }
        },
        { upsert: true, new: true, runValidators: true }
      );
      results.push(updated);
    }

    // Sync interventions for affected students
    for (const sId of affectedStudents) {
      try {
        await syncStudentInterventions(sId);
      } catch (err) {
        // Continue
      }
    }

    res.status(200).json({
      success: true,
      message: `Recorded attendance for ${results.length} student(s).`,
      count: results.length
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get attendance summary statistics for a student
// @route   GET /api/attendance/student/:studentId/summary
const getStudentAttendanceSummary = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const records = await Attendance.find({ studentRef: studentId }).populate('subjectRef');

    let totalHeld = records.length;
    let totalPresent = 0;
    let totalAbsent = 0;
    let totalLeave = 0;

    const subjectMap = {};

    records.forEach((r) => {
      if (r.status === 'Present') totalPresent += 1;
      else if (r.status === 'Absent') totalAbsent += 1;
      else if (r.status === 'Leave') totalLeave += 1;

      if (r.subjectRef) {
        const code = r.subjectRef.code;
        if (!subjectMap[code]) {
          subjectMap[code] = {
            subjectId: r.subjectRef._id,
            code,
            name: r.subjectRef.name,
            total: 0,
            present: 0,
            absent: 0,
            leave: 0
          };
        }
        subjectMap[code].total += 1;
        if (r.status === 'Present') subjectMap[code].present += 1;
        else if (r.status === 'Absent') subjectMap[code].absent += 1;
        else if (r.status === 'Leave') subjectMap[code].leave += 1;
      }
    });

    const subjectBreakdown = Object.values(subjectMap).map((s) => ({
      ...s,
      percentage: s.total > 0 ? parseFloat(((s.present / s.total) * 100).toFixed(2)) : 0
    }));

    const overallPercentage = totalHeld > 0 ? parseFloat(((totalPresent / totalHeld) * 100).toFixed(2)) : 0;

    res.status(200).json({
      success: true,
      summary: {
        totalHeld,
        totalPresent,
        totalAbsent,
        totalLeave,
        overallPercentage,
        subjectBreakdown
      }
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAttendance,
  recordAttendance,
  recordBulkAttendance,
  getStudentAttendanceSummary
};
