const Intervention = require('../models/Intervention');
const Student = require('../models/Student');
const { analyzeStudentRisk } = require('../services/riskAnalysisService');
const { generateRecommendations } = require('../services/recommendationService');
const { syncStudentInterventions, convertRecommendationToStudyTask } = require('../services/interventionWorkflowService');
const { logAction } = require('../services/auditService');

// @desc    Get complete risk analysis for a student
// @route   GET /api/interventions/risk-analysis/:studentId
const getStudentRiskAnalysis = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const analysis = await analyzeStudentRisk(studentId);
    res.status(200).json({ success: true, analysis });
  } catch (err) {
    next(err);
  }
};

// @desc    Get explainable recommendations for a student
// @route   GET /api/interventions/recommendations/:studentId
const getStudentRecommendations = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const result = await generateRecommendations(studentId);
    res.status(200).json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

// @desc    Get intervention history and reassessment log for a student
// @route   GET /api/interventions/history/:studentId
const getInterventionHistory = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const interventions = await Intervention.find({ studentRef: studentId }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: interventions.length, interventions });
  } catch (err) {
    next(err);
  }
};

// @desc    Convert recommendation into a study task
// @route   POST /api/interventions/create-study-task
const createTaskFromRecommendation = async (req, res, next) => {
  try {
    let { studentId, recommendationId } = req.body;

    // Enforce student ownership: Students can ONLY convert recommendations for themselves
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (studentId && studentId.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You cannot convert recommendations for another student.'
        });
      }
      studentId = req.user.studentRef;
    }

    if (!studentId || !recommendationId) {
      return res.status(400).json({
        success: false,
        message: 'studentId and recommendationId are required.'
      });
    }

    const task = await convertRecommendationToStudyTask({ studentId, recommendationId });

    await logAction({
      req,
      action: 'CONVERT_RECOMMENDATION_TO_TASK',
      resource: 'StudyTask',
      resourceId: task._id,
      details: { studentId, recommendationId, taskTitle: task.title }
    });

    res.status(201).json({
      success: true,
      message: `Study Task "${task.title}" created successfully in Study Planner!`,
      task
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Manually trigger reassessment
// @route   POST /api/interventions/reassess/:studentId
const triggerReassessment = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const result = await syncStudentInterventions(studentId);

    await logAction({
      req,
      action: 'MANUAL_REASSESSMENT',
      resource: 'Intervention',
      resourceId: studentId,
      details: { newStatus: result.status }
    });

    res.status(200).json({
      success: true,
      message: 'Academic health indicators and recommendations successfully reassessed.',
      result
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Institutional overview of all students by risk category (Admin/Faculty)
// @route   GET /api/interventions/overview
const getBatchInterventionOverview = async (req, res, next) => {
  try {
    const students = await Student.find({ academicStatus: 'Active' });
    const summaries = [];

    let onTrackCount = 0;
    let needsAttentionCount = 0;
    let highPriorityCount = 0;

    for (const s of students) {
      try {
        const analysis = await analyzeStudentRisk(s._id);
        if (analysis.overallRiskLevel === 'High Priority') highPriorityCount += 1;
        else if (analysis.overallRiskLevel === 'Needs Attention') needsAttentionCount += 1;
        else onTrackCount += 1;

        summaries.push({
          studentId: s.studentId,
          id: s._id,
          fullName: s.fullName,
          department: s.department,
          semester: s.semester,
          overallRiskLevel: analysis.overallRiskLevel,
          overallMarks: analysis.overallMarksPercent,
          overallAttendance: analysis.overallAttendancePercent,
          concernsCount: analysis.indicators.filter((i) => i.level !== 'On Track').length
        });
      } catch (e) {
        // Continue
      }
    }

    res.status(200).json({
      success: true,
      counts: {
        total: students.length,
        onTrack: onTrackCount,
        needsAttention: needsAttentionCount,
        highPriority: highPriorityCount
      },
      students: summaries
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getStudentRiskAnalysis,
  getStudentRecommendations,
  getInterventionHistory,
  createTaskFromRecommendation,
  triggerReassessment,
  getBatchInterventionOverview
};
