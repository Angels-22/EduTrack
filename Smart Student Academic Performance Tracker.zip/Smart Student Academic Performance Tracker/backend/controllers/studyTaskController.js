const StudyTask = require('../models/StudyTask');
const { logAction } = require('../services/auditService');

// @desc    Get study tasks
// @route   GET /api/study-tasks
const getTasks = async (req, res, next) => {
  try {
    const { studentId, status, priority, subjectId } = req.query;
    const query = {};

    // Enforce student ownership: Students can ONLY query their own tasks
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (studentId && studentId.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You are strictly authorized to view only your own academic records.'
        });
      }
      query.studentRef = req.user.studentRef;
    } else if (studentId) {
      query.studentRef = studentId;
    }

    if (status) query.status = status;
    if (priority) query.priority = priority;
    if (subjectId) query.subjectRef = subjectId;

    const tasks = await StudyTask.find(query)
      .populate('subjectRef')
      .sort({ dueDate: 1, priority: 1 });

    const total = tasks.length;
    const completed = tasks.filter((t) => t.status === 'Completed').length;
    const pending = tasks.filter((t) => t.status === 'Pending').length;
    const inProgress = tasks.filter((t) => t.status === 'In Progress').length;
    const completionPercent = total > 0 ? parseFloat(((completed / total) * 100).toFixed(1)) : 0;

    res.status(200).json({
      success: true,
      stats: { total, completed, pending, inProgress, completionPercent },
      tasks
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Create study task
// @route   POST /api/study-tasks
const createTask = async (req, res, next) => {
  try {
    let { studentRef, subjectRef, title, description, priority, dueDate, estimatedHours, source } = req.body;

    // Enforce student ownership: Students can ONLY create tasks for themselves
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (studentRef && studentRef.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You cannot create study tasks for another student.'
        });
      }
      studentRef = req.user.studentRef;
    }

    if (!studentRef || !title || !dueDate) {
      return res.status(400).json({
        success: false,
        message: 'Please provide studentRef, task title, and dueDate.'
      });
    }

    const task = await StudyTask.create({
      studentRef,
      subjectRef: subjectRef || null,
      title: title.trim(),
      description: description ? description.trim() : '',
      priority: priority || 'Medium',
      dueDate: new Date(dueDate),
      estimatedHours: estimatedHours ? parseFloat(estimatedHours) : 2,
      source: source || 'Self Created'
    });

    res.status(201).json({ success: true, message: 'Study task created.', task });
  } catch (err) {
    next(err);
  }
};

// @desc    Update study task
// @route   PUT /api/study-tasks/:id
const updateTask = async (req, res, next) => {
  try {
    const task = await StudyTask.findById(req.params.id);
    if (!task) {
      return res.status(404).json({ success: false, message: 'Study task not found.' });
    }

    // Enforce student ownership: Students can ONLY update their own tasks
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (task.studentRef.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You cannot modify another student\'s study task.'
        });
      }
    }

    const fields = ['title', 'description', 'priority', 'status', 'dueDate', 'estimatedHours', 'subjectRef'];
    fields.forEach((f) => {
      if (req.body[f] !== undefined) task[f] = req.body[f];
    });

    if (req.body.status === 'Completed' && !task.completedAt) {
      task.completedAt = new Date();
    } else if (req.body.status !== 'Completed') {
      task.completedAt = null;
    }

    await task.save();
    res.status(200).json({ success: true, message: 'Task updated.', task });
  } catch (err) {
    next(err);
  }
};

// @desc    Toggle status between Pending / In Progress / Completed
// @route   PATCH /api/study-tasks/:id/status
const toggleTaskStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const task = await StudyTask.findById(req.params.id);
    if (!task) {
      return res.status(404).json({ success: false, message: 'Study task not found.' });
    }

    // Enforce student ownership: Students can ONLY modify their own tasks
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (task.studentRef.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You cannot modify another student\'s study task.'
        });
      }
    }

    const validStatuses = ['Pending', 'In Progress', 'Completed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status value.' });
    }

    task.status = status;
    task.completedAt = status === 'Completed' ? new Date() : null;
    await task.save();

    res.status(200).json({ success: true, message: `Task marked as ${status}.`, task });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete study task
// @route   DELETE /api/study-tasks/:id
const deleteTask = async (req, res, next) => {
  try {
    const task = await StudyTask.findById(req.params.id);
    if (!task) {
      return res.status(404).json({ success: false, message: 'Study task not found.' });
    }

    // Enforce student ownership: Students can ONLY delete their own tasks
    if (req.user && req.user.role === 'student') {
      const ownStudentId = req.user.studentRef ? req.user.studentRef.toString() : '';
      if (task.studentRef.toString() !== ownStudentId) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You cannot delete another student\'s study task.'
        });
      }
    }

    await task.deleteOne();
    res.status(200).json({ success: true, message: 'Study task deleted.' });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getTasks,
  createTask,
  updateTask,
  toggleTaskStatus,
  deleteTask
};
