const AuditLog = require('../models/AuditLog');

// @desc    Get system audit logs (Admin only)
// @route   GET /api/audit-logs
const getAuditLogs = async (req, res, next) => {
  try {
    const { action, resource, limit = 100 } = req.query;
    const query = {};

    if (action) query.action = action;
    if (resource) query.resource = resource;

    const logs = await AuditLog.find(query)
      .sort({ createdAt: -1 })
      .limit(parseInt(limit, 10));

    res.status(200).json({ success: true, count: logs.length, logs });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAuditLogs
};
