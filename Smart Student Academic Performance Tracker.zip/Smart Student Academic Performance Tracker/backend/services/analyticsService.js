/**
 * Academic Analytics Service
 * Computes comparative statistics, semester trends, subject strength/weakness,
 * and batch-level insights from real MongoDB records.
 */

const Mark = require('../models/Mark');
const Attendance = require('../models/Attendance');
const Subject = require('../models/Subject');
const Assessment = require('../models/Assessment');
const Student = require('../models/Student');
const { GRADING_SCALE } = require('../config/constants');

const getStudentAnalytics = async (studentId) => {
  const student = await Student.findById(studentId);
  if (!student) throw new Error('Student not found');

  const marks = await Mark.find({ studentRef: studentId })
    .populate('assessmentRef')
    .populate('subjectRef')
    .sort({ createdAt: 1 });

  const attendance = await Attendance.find({ studentRef: studentId })
    .populate('subjectRef')
    .sort({ date: 1 });

  // 1. Subject-wise metrics
  const subjectMap = {};
  marks.forEach((m) => {
    if (!m.subjectRef) return;
    const code = m.subjectRef.code;
    if (!subjectMap[code]) {
      subjectMap[code] = {
        code,
        name: m.subjectRef.name,
        credits: m.subjectRef.credits || 3,
        totalObtained: 0,
        totalMax: 0,
        count: 0,
        history: []
      };
    }
    subjectMap[code].totalObtained += m.marksObtained;
    subjectMap[code].totalMax += m.maxMarks;
    subjectMap[code].count += 1;
    subjectMap[code].history.push({
      assessmentTitle: m.assessmentRef ? m.assessmentRef.title : 'Assessment',
      percentage: m.percentage,
      marksObtained: m.marksObtained,
      maxMarks: m.maxMarks,
      date: m.assessmentRef ? m.assessmentRef.date : m.createdAt
    });
  });

  const subjectPerformance = Object.values(subjectMap).map((sub) => {
    const avg = sub.totalMax > 0 ? parseFloat(((sub.totalObtained / sub.totalMax) * 100).toFixed(2)) : 0;
    const gradeMatch = GRADING_SCALE.find((g) => avg >= g.min && avg <= g.max) || { grade: 'RA', point: 0 };
    return {
      ...sub,
      averagePercentage: avg,
      grade: gradeMatch.grade,
      gradePoint: gradeMatch.point
    };
  });

  // Sort best and weakest subjects
  const sortedByPerf = [...subjectPerformance].sort((a, b) => b.averagePercentage - a.averagePercentage);
  const bestSubjects = sortedByPerf.slice(0, 2);
  const weakestSubjects = sortedByPerf.filter((s) => s.averagePercentage < 60);

  // 2. Attendance Summary
  const attSubjectMap = {};
  let totalAttended = 0;
  let totalHeld = 0;

  attendance.forEach((att) => {
    if (!att.subjectRef) return;
    const code = att.subjectRef.code;
    if (!attSubjectMap[code]) {
      attSubjectMap[code] = { code, name: att.subjectRef.name, attended: 0, held: 0 };
    }
    attSubjectMap[code].held += 1;
    totalHeld += 1;
    if (att.status === 'Present') {
      attSubjectMap[code].attended += 1;
      totalAttended += 1;
    }
  });

  const subjectAttendance = Object.values(attSubjectMap).map((a) => ({
    ...a,
    percentage: a.held > 0 ? parseFloat(((a.attended / a.held) * 100).toFixed(2)) : 0
  }));

  const overallAttendancePercent = totalHeld > 0
    ? parseFloat(((totalAttended / totalHeld) * 100).toFixed(2))
    : 0;

  // 3. Overall Weighted Percentage & GPA Calculation
  let totalWeightedScore = 0;
  let totalCredits = 0;

  subjectPerformance.forEach((s) => {
    totalWeightedScore += s.averagePercentage * s.credits;
    totalCredits += s.credits;
  });

  const overallPercentage = totalCredits > 0
    ? parseFloat((totalWeightedScore / totalCredits).toFixed(2))
    : 0;

  // GPA calculation on 10-point scale
  let totalGradePoints = 0;
  subjectPerformance.forEach((s) => {
    totalGradePoints += s.gradePoint * s.credits;
  });
  const gpa = totalCredits > 0 ? parseFloat((totalGradePoints / totalCredits).toFixed(2)) : 0;

  return {
    student: {
      id: student._id,
      studentId: student.studentId,
      fullName: student.fullName,
      department: student.department,
      semester: student.semester,
      targetPercentage: student.targetPercentage
    },
    overallPercentage,
    gpa,
    totalCredits,
    overallAttendancePercent,
    totalClassesHeld: totalHeld,
    totalClassesAttended: totalAttended,
    subjectPerformance,
    subjectAttendance,
    bestSubjects,
    weakestSubjects,
    totalAssessmentsRecorded: marks.length
  };
};

module.exports = {
  getStudentAnalytics
};
