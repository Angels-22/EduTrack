/**
 * Intervention Workflow & Reassessment Engine
 * Manages the lifecycle of academic interventions: creation, tracking,
 * linked task conversion, and automatic reassessment when new marks or attendance are submitted.
 */

const Intervention = require('../models/Intervention');
const StudyTask = require('../models/StudyTask');
const Student = require('../models/Student');
const { generateRecommendations } = require('./recommendationService');
const { analyzeStudentRisk } = require('./riskAnalysisService');

/**
 * Sync or create active intervention record for a student
 */
const syncStudentInterventions = async (studentId) => {
  const { student, overallRiskLevel, analysis, recommendations } = await generateRecommendations(studentId);

  // If risk level is On Track and there are no active concerns, mark any existing active interventions as resolved
  if (overallRiskLevel === 'On Track') {
    await Intervention.updateMany(
      { studentRef: studentId, status: 'Active' },
      {
        $set: {
          status: 'Resolved',
          outcomeStatus: 'Observed Improvement'
        },
        $push: {
          reassessmentHistory: {
            reassessedAt: new Date(),
            observedChange: 'All academic indicators now meet or exceed benchmark standards.',
            notes: 'Automated reassessment: marks and attendance restored to satisfactory levels.'
          }
        }
      }
    );
    return { status: 'On Track', activeIntervention: null };
  }

  // Find if an active intervention already exists
  let activeIntervention = await Intervention.findOne({
    studentRef: studentId,
    status: { $in: ['Active', 'In Progress'] }
  });

  const primaryIndicator = analysis.indicators[0] || {};
  const explanation = {
    whyItMatters: primaryIndicator.whyItMatters || 'Academic performance needs active attention.',
    evidence: primaryIndicator.supportingMeasurements || 'Current data points show room for recovery.',
    thresholdApplied: primaryIndicator.ruleApplied || 'Standard academic benchmark'
  };

  const recList = recommendations.map((r) => ({
    recommendationId: r.id,
    title: r.title,
    reason: r.reason,
    priority: r.priority,
    actionItem: r.actionItem,
    suggestedDeadline: new Date(Date.now() + (r.suggestedDeadlineDays || 7) * 24 * 60 * 60 * 1000),
    isTaskCreated: false,
    isCompleted: false
  }));

  if (!activeIntervention) {
    // Create new intervention record
    activeIntervention = new Intervention({
      studentRef: studentId,
      riskLevel: overallRiskLevel,
      detectedConcern: primaryIndicator.title || `${overallRiskLevel} Academic Alert`,
      triggerRule: primaryIndicator.ruleApplied || 'Benchmark threshold rule',
      supportingMeasurements: {
        overallMarks: analysis.overallMarksPercent,
        overallAttendance: analysis.overallAttendancePercent,
        primaryEvidence: primaryIndicator.supportingMeasurements
      },
      explanation,
      recommendations: recList,
      status: 'Active',
      outcomeStatus: 'Concern Active'
    });
    await activeIntervention.save();
  } else {
    // Update existing active intervention with fresh measurements and append to reassessment history
    const oldScore = activeIntervention.supportingMeasurements ? activeIntervention.supportingMeasurements.overallMarks : null;
    const newScore = analysis.overallMarksPercent;

    let observedChange = 'Data refreshed with latest academic entries.';
    if (typeof oldScore === 'number' && typeof newScore === 'number') {
      const diff = newScore - oldScore;
      if (diff > 0) {
        observedChange = `Observed score improvement of +${diff.toFixed(1)}% (from ${oldScore}% to ${newScore}%).`;
      } else if (diff < 0) {
        observedChange = `Score shifted downward by ${Math.abs(diff).toFixed(1)}% (from ${oldScore}% to ${newScore}%).`;
      } else {
        observedChange = `Academic standing unchanged at ${newScore}%.`;
      }
    }

    activeIntervention.riskLevel = overallRiskLevel;
    activeIntervention.detectedConcern = primaryIndicator.title || activeIntervention.detectedConcern;
    activeIntervention.triggerRule = primaryIndicator.ruleApplied || activeIntervention.triggerRule;
    activeIntervention.supportingMeasurements = {
      overallMarks: analysis.overallMarksPercent,
      overallAttendance: analysis.overallAttendancePercent,
      primaryEvidence: primaryIndicator.supportingMeasurements
    };
    activeIntervention.explanation = explanation;

    // Retain completed state on recommendations if matched by ID
    const completedIds = new Set(
      activeIntervention.recommendations.filter((r) => r.isCompleted).map((r) => r.recommendationId)
    );
    const createdTaskIds = new Set(
      activeIntervention.recommendations.filter((r) => r.isTaskCreated).map((r) => r.recommendationId)
    );

    activeIntervention.recommendations = recList.map((r) => ({
      ...r,
      isCompleted: completedIds.has(r.recommendationId),
      isTaskCreated: createdTaskIds.has(r.recommendationId)
    }));

    activeIntervention.reassessmentHistory.push({
      reassessedAt: new Date(),
      previousScore: oldScore,
      newScore,
      observedChange,
      notes: `Reassessment triggered upon new academic data.`
    });

    await activeIntervention.save();
  }

  return {
    status: overallRiskLevel,
    activeIntervention
  };
};

/**
 * Convert a specific recommendation into a persistent Study Task
 */
const convertRecommendationToStudyTask = async ({ studentId, recommendationId }) => {
  const { recommendations, student } = await generateRecommendations(studentId);
  const targetRec = recommendations.find((r) => r.id === recommendationId);

  if (!targetRec) {
    throw new Error('Recommendation item not found');
  }

  // Create study task
  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + (targetRec.suggestedDeadlineDays || 7));

  const newTask = new StudyTask({
    studentRef: studentId,
    title: targetRec.suggestedTask.title,
    description: targetRec.suggestedTask.description,
    priority: targetRec.suggestedTask.priority || 'Medium',
    status: 'Pending',
    dueDate,
    estimatedHours: targetRec.suggestedTask.estimatedHours || 2,
    source: 'Intervention Recommendation',
    recommendationId
  });

  await newTask.save();

  // Mark task as created in active intervention if exists
  await Intervention.updateOne(
    { studentRef: studentId, 'recommendations.recommendationId': recommendationId },
    { $set: { 'recommendations.$.isTaskCreated': true, status: 'In Progress' } }
  );

  return newTask;
};

module.exports = {
  syncStudentInterventions,
  convertRecommendationToStudyTask
};
