/**
 * Explainable Academic Recommendations Engine
 * Deterministic, rule-based recommendation generator converting academic analysis
 * directly into concrete, actionable steps and study tasks.
 */

const { analyzeStudentRisk } = require('./riskAnalysisService');
const Assessment = require('../models/Assessment');

const generateRecommendations = async (studentDocOrId) => {
  const analysis = await analyzeStudentRisk(studentDocOrId);
  const recommendations = [];

  const student = analysis.student;

  // Fetch upcoming assessments for this semester
  const upcomingAssessments = await Assessment.find({
    semester: student.semester,
    date: { $gte: new Date() }
  }).populate('subjectRef').sort({ date: 1 });

  // Map each risk indicator to concrete recommendations
  analysis.indicators.forEach((ind) => {
    if (ind.id.startsWith('repeated-low-')) {
      recommendations.push({
        id: `rec-${ind.id}`,
        title: `Comprehensive Revision Plan for ${ind.subject}`,
        category: 'Subject Mastery',
        priority: 'High',
        reason: `Detected multiple assessments scored below 50% (${ind.supportingMeasurements}).`,
        supportingMeasurements: ind.supportingMeasurements,
        actionItem: `Dedicate 2 hours daily to solve previous question papers and clarify core topics in ${ind.subject}.`,
        suggestedDeadlineDays: 7,
        suggestedTask: {
          title: `Intensive Concept Review: ${ind.subject}`,
          description: `Focus on fundamental problem sets and clarify doubts from recent assessment errors in ${ind.subject}.`,
          priority: 'High',
          estimatedHours: 4,
          source: 'Intervention Recommendation'
        }
      });
    }

    if (ind.id.startsWith('decline-')) {
      recommendations.push({
        id: `rec-${ind.id}`,
        title: `Remedial Session & Error Analysis for ${ind.subject}`,
        category: 'Performance Recovery',
        priority: 'Medium',
        reason: `A downward score change was detected (${ind.supportingMeasurements}).`,
        supportingMeasurements: ind.supportingMeasurements,
        actionItem: `Review your graded answer sheet for ${ind.subject} and catalog question types where points were lost.`,
        suggestedDeadlineDays: 5,
        suggestedTask: {
          title: `Analyze Lost Marks in ${ind.subject}`,
          description: `Review test paper mistakes with classmates or faculty mentor.`,
          priority: 'Medium',
          estimatedHours: 2,
          source: 'Intervention Recommendation'
        }
      });
    }

    if (ind.id.startsWith('crit-att-') || ind.id.startsWith('warning-att-')) {
      const isCritical = ind.id.startsWith('crit-att-');
      recommendations.push({
        id: `rec-${ind.id}`,
        title: `Mandatory Attendance Recovery for ${ind.subject}`,
        category: 'Attendance Compliance',
        priority: isCritical ? 'High' : 'Medium',
        reason: `Current attendance is below the institutional benchmark (${ind.supportingMeasurements}).`,
        supportingMeasurements: ind.supportingMeasurements,
        actionItem: `Run the Attendance Recovery Calculator to view the exact consecutive classes needed, and commit to 100% attendance over the next 3 weeks.`,
        suggestedDeadlineDays: 14,
        suggestedTask: {
          title: `Attend Next 10 Consecutive Classes in ${ind.subject}`,
          description: `Maintain a personal attendance log to verify recovery to above 75%.`,
          priority: isCritical ? 'High' : 'Medium',
          estimatedHours: 1,
          source: 'Intervention Recommendation'
        }
      });
    }

    if (ind.id === 'overdue-tasks') {
      recommendations.push({
        id: 'rec-study-backlog',
        title: 'Clear Overdue Study Tasks Backlog',
        category: 'Time Management',
        priority: 'Medium',
        reason: ind.supportingMeasurements,
        supportingMeasurements: ind.supportingMeasurements,
        actionItem: 'Block 90 minutes today to mark off or reschedule pending study tasks.',
        suggestedDeadlineDays: 2,
        suggestedTask: {
          title: 'Study Planner Backlog Clearance Session',
          description: 'Focus solely on completing pending overdue tasks.',
          priority: 'Medium',
          estimatedHours: 2,
          source: 'Intervention Recommendation'
        }
      });
    }
  });

  // Upcoming assessment recommendations
  if (upcomingAssessments.length > 0) {
    const nextExam = upcomingAssessments[0];
    const examDateStr = new Date(nextExam.date).toLocaleDateString();
    recommendations.push({
      id: `rec-upcoming-${nextExam._id}`,
      title: `Upcoming Assessment Preparation: ${nextExam.title}`,
      category: 'Proactive Preparation',
      priority: 'Medium',
      reason: `Scheduled on ${examDateStr} for ${nextExam.subjectRef ? nextExam.subjectRef.name : 'Subject'}.`,
      supportingMeasurements: `Weightage: ${nextExam.weightagePercent}%, Max Marks: ${nextExam.maxMarks}`,
      actionItem: `Review lecture notes, create revision flashcards, and run What-If simulations for expected scores.`,
      suggestedDeadlineDays: Math.max(1, Math.ceil((new Date(nextExam.date) - new Date()) / (1000 * 60 * 60 * 24))),
      suggestedTask: {
        title: `Prepare for ${nextExam.title}`,
        description: `Complete syllabus revision for ${nextExam.subjectRef ? nextExam.subjectRef.name : 'Subject'}.`,
        priority: 'High',
        estimatedHours: 5,
        source: 'Intervention Recommendation'
      }
    });
  }

  // Commendation if fully on track
  if (analysis.overallRiskLevel === 'On Track') {
    recommendations.push({
      id: 'rec-excellence-sustained',
      title: 'Maintain Academic Momentum & Explore Honors Topics',
      category: 'Excellence Pathway',
      priority: 'Low',
      reason: `All current scores (${analysis.overallMarksPercent}%) and attendance (${analysis.overallAttendancePercent}%) exceed standard thresholds.`,
      supportingMeasurements: `Overall: ${analysis.overallMarksPercent}%, Attendance: ${analysis.overallAttendancePercent}%`,
      actionItem: 'Consider exploring advanced problem solving, hackathons, or faculty-guided mini projects.',
      suggestedDeadlineDays: 21,
      suggestedTask: {
        title: 'Explore Advanced Domain Research or Certification',
        description: 'Take up an elective deep-dive topic to enhance resume and practical skills.',
        priority: 'Low',
        estimatedHours: 3,
        source: 'Intervention Recommendation'
      }
    });
  }

  return {
    student: analysis.student,
    overallRiskLevel: analysis.overallRiskLevel,
    analysis,
    recommendations
  };
};

module.exports = {
  generateRecommendations
};
