/**
 * What-If Grade Simulator Service
 * Mathematical simulation engine for hypothetical assessments, target score feasibility,
 * and weighted GPA/grade projection.
 */

const { GRADING_SCALE } = require('../config/constants');

const getGradeForPercentage = (percent) => {
  const p = Math.max(0, Math.min(100, percent));
  const match = GRADING_SCALE.find((g) => p >= g.min && p <= g.max);
  return match || { grade: 'RA', label: 'Re-appear', point: 0 };
};

/**
 * Simulate grade outcomes and calculate required scores for a target
 * @param {Array} completedAssessments - [{ title, weight, scorePercent }]
 * @param {Array} remainingAssessments - [{ title, weight, hypotheticalScorePercent }]
 * @param {Number} targetPercent - e.g. 75
 */
const simulateGrade = ({ completedAssessments = [], remainingAssessments = [], targetPercent = 75 }) => {
  const target = Math.max(0, Math.min(100, parseFloat(targetPercent) || 75));

  // Compute current earned weighted points
  let completedWeight = 0;
  let earnedWeightedScore = 0;

  completedAssessments.forEach((item) => {
    const weight = Math.max(0, parseFloat(item.weight) || 0);
    const score = Math.max(0, Math.min(100, parseFloat(item.scorePercent) || 0));
    completedWeight += weight;
    earnedWeightedScore += (score * weight) / 100;
  });

  // Compute remaining weight and hypothetical projection
  let remainingWeight = 0;
  let hypotheticalWeightedScore = 0;

  remainingAssessments.forEach((item) => {
    const weight = Math.max(0, parseFloat(item.weight) || 0);
    remainingWeight += weight;
    if (typeof item.hypotheticalScorePercent === 'number' && !isNaN(item.hypotheticalScorePercent)) {
      const hypScore = Math.max(0, Math.min(100, parseFloat(item.hypotheticalScorePercent)));
      hypotheticalWeightedScore += (hypScore * weight) / 100;
    }
  });

  const totalConfiguredWeight = completedWeight + remainingWeight;
  const currentAveragePercent = completedWeight > 0 ? (earnedWeightedScore / completedWeight) * 100 : 0;

  // Maximum possible score if student gets 100% on all remaining assessments
  const maxPossibleOverall = parseFloat((earnedWeightedScore + remainingWeight).toFixed(2));

  // Minimum possible score if student gets 0% on all remaining assessments
  const minPossibleOverall = parseFloat(earnedWeightedScore.toFixed(2));

  // Projected overall if hypothetical scores were entered
  const projectedOverallScore = parseFloat((earnedWeightedScore + hypotheticalWeightedScore).toFixed(2));
  const projectedGrade = getGradeForPercentage(projectedOverallScore);

  // Feasibility & Required Score in remaining assessments to reach target
  let isFeasible = true;
  let requiredAverageOnRemaining = null;
  let feasibilityMessage = '';

  if (remainingWeight <= 0) {
    isFeasible = earnedWeightedScore >= target;
    feasibilityMessage = isFeasible
      ? `All assessments completed. You have achieved ${earnedWeightedScore.toFixed(2)}%, exceeding your target of ${target}%.`
      : `All assessments are completed. The final score is ${earnedWeightedScore.toFixed(2)}%, which is below the target of ${target}%.`;
  } else {
    // Formula: (target - earnedWeightedScore) / remainingWeight * 100
    const neededWeighted = target - earnedWeightedScore;

    if (neededWeighted <= 0) {
      requiredAverageOnRemaining = 0;
      isFeasible = true;
      feasibilityMessage = `Target already secured! Even with 0% on the remaining assessments (${remainingWeight}% weight), your earned points (${earnedWeightedScore.toFixed(2)}%) already meet or exceed your target of ${target}%.`;
    } else {
      const requiredRaw = (neededWeighted / remainingWeight) * 100;
      requiredAverageOnRemaining = parseFloat(requiredRaw.toFixed(2));

      if (requiredAverageOnRemaining > 100) {
        isFeasible = false;
        feasibilityMessage = `Target Unachievable: To achieve ${target}%, you would need an average of ${requiredAverageOnRemaining}% on remaining assessments, which exceeds the maximum possible 100%. The maximum attainable score is ${maxPossibleOverall}%.`;
      } else {
        isFeasible = true;
        feasibilityMessage = `Achievable: You need an average score of ${requiredAverageOnRemaining}% across the remaining assessments (${remainingWeight}% total weight) to reach your target of ${target}%.`;
      }
    }
  }

  return {
    targetPercent: target,
    completedWeight: parseFloat(completedWeight.toFixed(2)),
    remainingWeight: parseFloat(remainingWeight.toFixed(2)),
    totalConfiguredWeight: parseFloat(totalConfiguredWeight.toFixed(2)),
    currentEarnedWeighted: parseFloat(earnedWeightedScore.toFixed(2)),
    currentAveragePercent: parseFloat(currentAveragePercent.toFixed(2)),
    maxPossibleOverall,
    minPossibleOverall,
    projectedOverallScore,
    projectedGrade,
    isFeasible,
    requiredAverageOnRemaining,
    feasibilityMessage
  };
};

module.exports = {
  simulateGrade,
  getGradeForPercentage
};
