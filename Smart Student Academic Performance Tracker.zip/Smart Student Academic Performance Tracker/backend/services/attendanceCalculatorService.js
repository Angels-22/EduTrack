/**
 * Attendance Recovery Calculator Service
 * Implements rigorous mathematical recovery formulas and edge case handling.
 */

const calculateAttendanceRecovery = ({ attended, total, targetPercent = 75 }) => {
  const A = Math.max(0, parseInt(attended, 10) || 0);
  const T = Math.max(0, parseInt(total, 10) || 0);
  const target = parseFloat(targetPercent) || 75;

  if (target <= 0 || target > 100) {
    throw new Error('Target attendance percentage must be between 1% and 100%');
  }

  if (A > T) {
    throw new Error('Classes attended cannot exceed total classes held');
  }

  const currentPercent = T === 0 ? 0 : parseFloat(((A / T) * 100).toFixed(2));
  const r = target / 100;

  // Case 1: No classes held yet
  if (T === 0) {
    return {
      attended: 0,
      total: 0,
      currentPercent: 0,
      targetPercent: target,
      status: 'No Classes Yet',
      isAchieved: false,
      isFeasible: true,
      additionalRequired: 0,
      safeMissableClasses: 0,
      explanation: 'No classes have been recorded yet for this subject.'
    };
  }

  // Case 2: Target is already achieved
  if (currentPercent >= target) {
    // Calculate how many future classes student can miss while staying at or above target
    // (A) / (T + y) >= r => T + y <= A / r => y = floor(A/r - T)
    const safeMissable = Math.max(0, Math.floor(A / r - T));
    return {
      attended: A,
      total: T,
      currentPercent,
      targetPercent: target,
      status: 'Target Met',
      isAchieved: true,
      isFeasible: true,
      additionalRequired: 0,
      safeMissableClasses: safeMissable,
      explanation: `Your current attendance (${currentPercent}%) is at or above your target of ${target}%. You can miss up to ${safeMissable} upcoming class(es) without falling below ${target}%.`
    };
  }

  // Case 3: Target is 100% but at least one class was already missed
  if (target >= 100) {
    return {
      attended: A,
      total: T,
      currentPercent,
      targetPercent: 100,
      status: 'Target Unachievable',
      isAchieved: false,
      isFeasible: false,
      additionalRequired: null,
      safeMissableClasses: 0,
      explanation: `A 100% attendance target is mathematically impossible because you have already missed ${T - A} class(es). A single absence means attendance cannot mathematically reach 100%.`
    };
  }

  // Case 4: Target < 100% and current attendance < target
  // Formula: x = max(0, ceil((r*T - A) / (1 - r)))
  const numerator = (r * T) - A;
  const denominator = 1 - r;
  const rawX = Math.ceil(numerator / denominator);
  const additionalRequired = Math.max(0, rawX);

  // Projected attendance if student attends those x additional classes
  const projectedAttended = A + additionalRequired;
  const projectedTotal = T + additionalRequired;
  const projectedPercent = parseFloat(((projectedAttended / projectedTotal) * 100).toFixed(2));

  return {
    attended: A,
    total: T,
    currentPercent,
    targetPercent: target,
    status: 'Recovery Needed',
    isAchieved: false,
    isFeasible: true,
    additionalRequired,
    safeMissableClasses: 0,
    projectedAttended,
    projectedTotal,
    projectedPercent,
    explanation: `You have attended ${A} out of ${T} classes (${currentPercent}%). You must attend the next ${additionalRequired} consecutive classes without absence to achieve your ${target}% target (projected to reach ${projectedPercent}%).`
  };
};

module.exports = {
  calculateAttendanceRecovery
};
