/**
 * Smart Academic Risk Radar Engine
 * Transparent, rule-based academic risk analysis with explainable indicators,
 * concrete measurements, threshold tracing, and non-stigmatizing guidance.
 */

const Mark = require('../models/Mark');
const Attendance = require('../models/Attendance');
const StudyTask = require('../models/StudyTask');
const Goal = require('../models/Goal');
const Student = require('../models/Student');
const Subject = require('../models/Subject');
const Assessment = require('../models/Assessment');
const { THRESHOLDS, RISK_LEVELS } = require('../config/constants');

const analyzeStudentRisk = async (studentDocOrId) => {
  const student = typeof studentDocOrId === 'string'
    ? await Student.findById(studentDocOrId)
    : studentDocOrId;

  if (!student) {
    throw new Error('Student record not found for risk analysis');
  }

  const studentId = student._id;
  const targetPercentage = student.targetPercentage || THRESHOLDS.TARGET_BENCHMARK;
  const targetAttendance = student.targetAttendance || THRESHOLDS.MIN_ATTENDANCE;

  // 1. Fetch Marks chronologically
  const marks = await Mark.find({ studentRef: studentId })
    .populate('assessmentRef')
    .populate('subjectRef')
    .sort({ createdAt: 1 });

  // 2. Fetch Attendance
  const attendanceRecords = await Attendance.find({ studentRef: studentId })
    .populate('subjectRef')
    .sort({ date: 1 });

  // 3. Fetch Tasks & Goals
  const tasks = await StudyTask.find({ studentRef: studentId });
  const goals = await Goal.find({ studentRef: studentId });

  // 4. Group marks by subject
  const subjectMarksMap = {};
  marks.forEach((m) => {
    if (!m.subjectRef) return;
    const subCode = m.subjectRef.code || m.subjectRef.name;
    if (!subjectMarksMap[subCode]) {
      subjectMarksMap[subCode] = {
        subject: m.subjectRef,
        records: []
      };
    }
    subjectMarksMap[subCode].records.push({
      assessmentTitle: m.assessmentRef ? m.assessmentRef.title : 'Assessment',
      marksObtained: m.marksObtained,
      maxMarks: m.maxMarks,
      percentage: m.percentage,
      date: m.assessmentRef && m.assessmentRef.date ? m.assessmentRef.date : m.createdAt
    });
  });

  // 5. Group attendance by subject & overall
  const subjectAttendanceMap = {};
  let totalAttended = 0;
  let totalHeld = 0;

  attendanceRecords.forEach((att) => {
    if (!att.subjectRef) return;
    const subCode = att.subjectRef.code || att.subjectRef.name;
    if (!subjectAttendanceMap[subCode]) {
      subjectAttendanceMap[subCode] = {
        subject: att.subjectRef,
        total: 0,
        attended: 0
      };
    }
    subjectAttendanceMap[subCode].total += 1;
    totalHeld += 1;
    if (att.status === 'Present') {
      subjectAttendanceMap[subCode].attended += 1;
      totalAttended += 1;
    }
  });

  const overallAttendancePercent = totalHeld > 0
    ? parseFloat(((totalAttended / totalHeld) * 100).toFixed(2))
    : 0;

  // Compute Overall Academic Percentage
  let totalMarksObtained = 0;
  let totalMaxMarks = 0;
  marks.forEach((m) => {
    totalMarksObtained += m.marksObtained;
    totalMaxMarks += m.maxMarks;
  });
  const overallMarksPercent = totalMaxMarks > 0
    ? parseFloat(((totalMarksObtained / totalMaxMarks) * 100).toFixed(2))
    : 0;

  // 6. Indicators Collection
  const indicators = [];
  const subjectSummaries = [];

  // Evaluate Subject-wise Academic Performance & Trends
  for (const subCode of Object.keys(subjectMarksMap)) {
    const { subject, records } = subjectMarksMap[subCode];
    const count = records.length;
    const subTotalObtained = records.reduce((acc, r) => acc + r.marksObtained, 0);
    const subTotalMax = records.reduce((acc, r) => acc + r.maxMarks, 0);
    const subAvgPercent = subTotalMax > 0 ? parseFloat(((subTotalObtained / subTotalMax) * 100).toFixed(2)) : 0;

    subjectSummaries.push({
      code: subject.code,
      name: subject.name,
      assessmentCount: count,
      averagePercentage: subAvgPercent,
      targetPercentage
    });

    // Rule A: Repeated low scores (>= 2 assessments below 50%)
    const lowScoreAssessments = records.filter((r) => r.percentage < THRESHOLDS.LOW_SCORE_CUTOFF);
    if (lowScoreAssessments.length >= THRESHOLDS.CONSECUTIVE_LOW_SCORES) {
      indicators.push({
        id: `repeated-low-${subject.code}`,
        subject: subject.name,
        subjectCode: subject.code,
        category: 'Academic Performance',
        level: RISK_LEVELS.HIGH_PRIORITY,
        title: `Repeated Low Assessment Scores in ${subject.name}`,
        ruleApplied: `Rule #1: ${THRESHOLDS.CONSECUTIVE_LOW_SCORES}+ assessment scores falling below ${THRESHOLDS.LOW_SCORE_CUTOFF}%`,
        supportingMeasurements: `${lowScoreAssessments.length} assessment(s) below ${THRESHOLDS.LOW_SCORE_CUTOFF}%: ` +
          lowScoreAssessments.map((a) => `${a.assessmentTitle} (${a.percentage}%)`).join(', '),
        whyItMatters: 'Persistently low foundational scores can accumulate into difficulty during end-semester examinations.',
        recommendedAction: `Schedule a structured topic-by-topic review and practice session for ${subject.name}. Create focused study tasks.`,
        dataSufficiency: 'Sufficient historical data present (multiple assessments recorded).'
      });
    }

    // Rule B: Declining trend across recent assessments
    if (count >= THRESHOLDS.MIN_ASSESSMENTS_FOR_TREND) {
      const prev = records[count - 2];
      const latest = records[count - 1];
      const decline = prev.percentage - latest.percentage;

      if (decline >= THRESHOLDS.DECLINE_THRESHOLD_PERCENT) {
        indicators.push({
          id: `decline-${subject.code}`,
          subject: subject.name,
          subjectCode: subject.code,
          category: 'Performance Trend',
          level: RISK_LEVELS.NEEDS_ATTENTION,
          title: `Performance Score Drop Detected in ${subject.name}`,
          ruleApplied: `Rule #2: Recent score drop of ≥${THRESHOLDS.DECLINE_THRESHOLD_PERCENT}% between consecutive assessments`,
          supportingMeasurements: `Dropped by ${decline.toFixed(1)}% from ${prev.assessmentTitle} (${prev.percentage}%) to ${latest.assessmentTitle} (${latest.percentage}%)`,
          whyItMatters: 'A downward shift often indicates emerging topic complexity or insufficient revision time before the latest test.',
          recommendedAction: `Review recent assessment feedback and clarify complex conceptual doubts with faculty.`,
          dataSufficiency: `Comparison verified between ${count} recorded assessments.`
        });
      }
    } else if (count === 1) {
      // Insufficient data for trend
      // We explicitly do NOT assert decline when only 1 assessment exists
    }

    // Rule C: Subject average below target
    if (count > 0 && subAvgPercent < targetPercentage) {
      indicators.push({
        id: `below-target-${subject.code}`,
        subject: subject.name,
        subjectCode: subject.code,
        category: 'Target Tracking',
        level: subAvgPercent < THRESHOLDS.PASSING_PERCENT ? RISK_LEVELS.HIGH_PRIORITY : RISK_LEVELS.NEEDS_ATTENTION,
        title: `${subject.name} Average Below Target`,
        ruleApplied: `Rule #3: Subject average (${subAvgPercent}%) is below configured target (${targetPercentage}%)`,
        supportingMeasurements: `Current Subject Average: ${subAvgPercent}% (Target: ${targetPercentage}%, Gap: ${(targetPercentage - subAvgPercent).toFixed(1)}%)`,
        whyItMatters: 'Closing the gap early preserves eligibility for top grades and scholarship benchmarks.',
        recommendedAction: `Use the What-If Grade Simulator to calculate exact marks required on remaining assessments.`,
        dataSufficiency: `Based on ${count} assessment(s) evaluated.`
      });
    }
  }

  // Rule D: Attendance Indicators (Subject-wise & Overall)
  for (const subCode of Object.keys(subjectAttendanceMap)) {
    const { subject, total, attended } = subjectAttendanceMap[subCode];
    if (total >= 4) { // only flag if at least 4 classes held
      const subAttPercent = parseFloat(((attended / total) * 100).toFixed(2));
      if (subAttPercent < THRESHOLDS.CRITICAL_ATTENDANCE) {
        indicators.push({
          id: `crit-att-${subject.code}`,
          subject: subject.name,
          subjectCode: subject.code,
          category: 'Attendance Risk',
          level: RISK_LEVELS.HIGH_PRIORITY,
          title: `Critical Attendance Deficit in ${subject.name}`,
          ruleApplied: `Rule #4A: Attendance strictly below critical threshold (${THRESHOLDS.CRITICAL_ATTENDANCE}%)`,
          supportingMeasurements: `Attended ${attended}/${total} classes (${subAttPercent}% vs required ${targetAttendance}%)`,
          whyItMatters: 'Falling below critical thresholds often triggers examination hall ticket debarment.',
          recommendedAction: `Use Attendance Recovery Calculator immediately to compute minimum consecutive classes needed.`,
          dataSufficiency: `${total} class sessions recorded.`
        });
      } else if (subAttPercent < targetAttendance) {
        indicators.push({
          id: `warning-att-${subject.code}`,
          subject: subject.name,
          subjectCode: subject.code,
          category: 'Attendance Warning',
          level: RISK_LEVELS.NEEDS_ATTENTION,
          title: `Attendance Below Target in ${subject.name}`,
          ruleApplied: `Rule #4B: Attendance below target requirement (${targetAttendance}%)`,
          supportingMeasurements: `Attended ${attended}/${total} classes (${subAttPercent}% vs target ${targetAttendance}%)`,
          whyItMatters: 'Maintaining consistent attendance improves continuous internal evaluation and class understanding.',
          recommendedAction: `Avoid unexcused leaves and attend all upcoming lecture sessions.`,
          dataSufficiency: `${total} class sessions recorded.`
        });
      }
    }
  }

  // Rule E: Overdue Study Tasks & Goal Gaps
  const overdueTasks = tasks.filter(
    (t) => t.status !== 'Completed' && new Date(t.dueDate) < new Date()
  );
  if (overdueTasks.length > 0) {
    indicators.push({
      id: 'overdue-tasks',
      subject: 'Study Planning',
      subjectCode: 'GEN',
      category: 'Task Management',
      level: RISK_LEVELS.NEEDS_ATTENTION,
      title: `${overdueTasks.length} Overdue Study Task(s)`,
      ruleApplied: `Rule #5: Study tasks past their scheduled due dates without completion`,
      supportingMeasurements: overdueTasks.map((t) => `"${t.title}" (Due: ${new Date(t.dueDate).toLocaleDateString()})`).join(', '),
      whyItMatters: 'Delayed revision tasks accumulate and increase cognitive load prior to examination periods.',
      recommendedAction: 'Re-prioritize pending tasks in the Study Planner and complete high-priority items.',
      dataSufficiency: `${tasks.length} total tasks tracked.`
    });
  }

  // 7. Overall Risk Level Assessment
  let overallRiskLevel = RISK_LEVELS.ON_TRACK;
  const hasHighPriority = indicators.some((i) => i.level === RISK_LEVELS.HIGH_PRIORITY);
  const hasNeedsAttention = indicators.some((i) => i.level === RISK_LEVELS.NEEDS_ATTENTION);

  if (hasHighPriority) {
    overallRiskLevel = RISK_LEVELS.HIGH_PRIORITY;
  } else if (hasNeedsAttention) {
    overallRiskLevel = RISK_LEVELS.NEEDS_ATTENTION;
  }

  // If no negative indicators found
  if (indicators.length === 0) {
    indicators.push({
      id: 'on-track-positive',
      subject: 'Overall Academics',
      subjectCode: 'ALL',
      category: 'Performance Commendation',
      level: RISK_LEVELS.ON_TRACK,
      title: 'Academic Standing Fully On Track',
      ruleApplied: 'Rule #0: All assessments and attendance meet or exceed benchmarks',
      supportingMeasurements: `Overall Marks: ${overallMarksPercent}% (Target: ${targetPercentage}%), Attendance: ${overallAttendancePercent}%`,
      whyItMatters: 'Consistent academic habits establish strong foundations for competitive success.',
      recommendedAction: 'Maintain current study timetable and prepare for advanced topics or project work.',
      dataSufficiency: 'Evaluated against all available academic and attendance records.'
    });
  }

  return {
    student: {
      id: student._id,
      studentId: student.studentId,
      fullName: student.fullName,
      email: student.email,
      department: student.department,
      semester: student.semester,
      targetPercentage,
      targetAttendance
    },
    overallRiskLevel,
    overallMarksPercent,
    overallAttendancePercent,
    totalAssessments: marks.length,
    totalAttendanceSessions: totalHeld,
    indicators,
    subjectSummaries
  };
};

module.exports = {
  analyzeStudentRisk
};
