const AuditLog = require('../models/AuditLog');

const logAction = async ({ req, action, resource, resourceId = '', details = {} }) => {
  try {
    const user = req && req.user ? req.user : null;
    const ip = req?.headers?.['x-forwarded-for'] || req?.socket?.remoteAddress || req?.ip || '127.0.0.1';

    // Sanitize details to guarantee no secrets are logged
    const cleanDetails = { ...details };
    delete cleanDetails.password;
    delete cleanDetails.token;
    delete cleanDetails.secret;

    await AuditLog.create({
      userRef: user ? user._id : null,
      userName: user ? user.name : 'System',
      userRole: user ? user.role : 'system',
      action,
      resource,
      resourceId: String(resourceId || ''),
      details: cleanDetails,
      ipAddress: Array.isArray(ip) ? ip[0] : ip
    });
  } catch (err) {
    console.error('[Audit Log Error]', err.message);
  }
};

module.exports = {
  logAction
};
