const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Student = require('../models/Student');
const { getJwtSecret } = require('../config/envValidator');

const authenticateToken = async (req, res, next) => {
  let token = null;

  // Strict security: Only accept tokens in standard Authorization: Bearer header.
  // Query parameter token authentication is disabled to prevent token leakage in URLs, logs, and browser history.
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required. Please provide a valid Bearer token in the Authorization header.'
    });
  }

  try {
    const secret = getJwtSecret();
    const decoded = jwt.verify(token, secret);

    const user = await User.findById(decoded.id);
    if (!user || user.status === 'inactive') {
      return res.status(401).json({
        success: false,
        message: 'User account not found or is currently inactive.'
      });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired session token. Please sign in again.'
    });
  }
};

const authorizeRoles = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: User role '${req.user ? req.user.role : 'anonymous'}' is not authorized to access this resource.`
      });
    }
    next();
  };
};

/**
 * Strict Cross-Student Access Guard
 * Enforces that student users can ONLY view or modify their own records.
 */
const enforceStudentSelfAccess = async (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }

  // Admin and faculty have legitimate institutional access
  if (req.user.role === 'admin' || req.user.role === 'faculty') {
    return next();
  }

  // User is student
  if (req.user.role === 'student') {
    const requestedStudentId =
      req.params.studentId ||
      req.params.id ||
      req.query.studentId ||
      (req.body && (req.body.studentId || req.body.studentRef));

    // If no specific student requested, resolve student doc linked to user
    let studentDoc = null;
    if (req.user.studentRef) {
      studentDoc = await Student.findById(req.user.studentRef);
    } else {
      studentDoc = await Student.findOne({ email: req.user.email });
      if (studentDoc) {
        req.user.studentRef = studentDoc._id;
        await req.user.save();
      }
    }

    if (!studentDoc) {
      return res.status(404).json({
        success: false,
        message: 'No student academic profile is linked to your user account.'
      });
    }

    // Attach student to request for controllers
    req.student = studentDoc;

    // If an explicit target ID was provided, verify it strictly matches own ID
    if (requestedStudentId) {
      const targetStr = String(requestedStudentId).trim();
      const ownIdStr = String(studentDoc._id).trim();
      const ownStudentCode = String(studentDoc.studentId).trim().toUpperCase();

      if (targetStr !== ownIdStr && targetStr.toUpperCase() !== ownStudentCode) {
        return res.status(403).json({
          success: false,
          message: 'Access Denied: You are strictly authorized to view only your own academic records.'
        });
      }
    }

    return next();
  }

  return res.status(403).json({ success: false, message: 'Access denied' });
};

module.exports = {
  authenticateToken,
  authorizeRoles,
  enforceStudentSelfAccess
};
