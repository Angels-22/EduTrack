const express = require('express');
const router = express.Router();
const {
  getStudentAnalyticsData,
  getInstitutionalAnalytics
} = require('../controllers/analyticsController');
const { authenticateToken, authorizeRoles, enforceStudentSelfAccess } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/overview', authorizeRoles('admin', 'faculty'), getInstitutionalAnalytics);
router.get('/student/:studentId', enforceStudentSelfAccess, getStudentAnalyticsData);

module.exports = router;
