const express = require('express');
const router = express.Router();
const {
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent
} = require('../controllers/studentController');
const { authenticateToken, authorizeRoles, enforceStudentSelfAccess } = require('../middleware/auth');

router.use(authenticateToken);

// Admin & Faculty can view all students
router.get('/', authorizeRoles('admin', 'faculty'), getAllStudents);

// Student can view self; Admin & Faculty can view any
router.get('/:id', enforceStudentSelfAccess, getStudentById);

// Admin & Faculty can create students
router.post('/', authorizeRoles('admin', 'faculty'), createStudent);

// Admin, Faculty, or Student updating self
router.put('/:id', enforceStudentSelfAccess, updateStudent);

// Only Admin can delete students
router.delete('/:id', authorizeRoles('admin'), deleteStudent);

module.exports = router;
