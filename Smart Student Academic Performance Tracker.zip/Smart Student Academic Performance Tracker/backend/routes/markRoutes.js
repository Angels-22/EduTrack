const express = require('express');
const router = express.Router();
const {
  getMarks,
  getMarksByStudent,
  enterOrUpdateMark,
  deleteMark
} = require('../controllers/markController');
const { authenticateToken, authorizeRoles, enforceStudentSelfAccess } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', getMarks);
router.get('/student/:studentId', enforceStudentSelfAccess, getMarksByStudent);
router.post('/', authorizeRoles('admin', 'faculty'), enterOrUpdateMark);
router.delete('/:id', authorizeRoles('admin', 'faculty'), deleteMark);

module.exports = router;
