const express = require('express');
const router = express.Router();
const {
  runGradeSimulator,
  runAttendanceRecovery,
  preloadStudentAttendance,
  preloadStudentSubjectGrades
} = require('../controllers/toolsController');
const { authenticateToken, enforceStudentSelfAccess } = require('../middleware/auth');

router.use(authenticateToken);

// Calculation APIs
router.post('/grade-simulator', runGradeSimulator);
router.post('/attendance-recovery', runAttendanceRecovery);

// Preload real DB records into calculators
router.get('/preload-attendance/:studentId', enforceStudentSelfAccess, preloadStudentAttendance);
router.get('/preload-grade-simulator/:studentId/:subjectId', enforceStudentSelfAccess, preloadStudentSubjectGrades);

module.exports = router;
