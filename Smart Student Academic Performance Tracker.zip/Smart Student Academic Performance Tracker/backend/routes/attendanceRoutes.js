const express = require('express');
const router = express.Router();
const {
  getAttendance,
  recordAttendance,
  recordBulkAttendance,
  getStudentAttendanceSummary
} = require('../controllers/attendanceController');
const { authenticateToken, authorizeRoles, enforceStudentSelfAccess } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', getAttendance);
router.get('/student/:studentId/summary', enforceStudentSelfAccess, getStudentAttendanceSummary);
router.post('/', authorizeRoles('admin', 'faculty'), recordAttendance);
router.post('/bulk', authorizeRoles('admin', 'faculty'), recordBulkAttendance);

module.exports = router;
