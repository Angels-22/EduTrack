const express = require('express');
const router = express.Router();
const {
  getTasks,
  createTask,
  updateTask,
  toggleTaskStatus,
  deleteTask
} = require('../controllers/studyTaskController');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', getTasks);
router.post('/', createTask);
router.put('/:id', updateTask);
router.patch('/:id/status', toggleTaskStatus);
router.delete('/:id', deleteTask);

module.exports = router;
