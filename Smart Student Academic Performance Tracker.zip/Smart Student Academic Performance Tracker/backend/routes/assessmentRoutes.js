const express = require('express');
const router = express.Router();
const {
  getAllAssessments,
  createAssessment,
  updateAssessment,
  deleteAssessment
} = require('../controllers/assessmentController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', getAllAssessments);
router.post('/', authorizeRoles('admin', 'faculty'), createAssessment);
router.put('/:id', authorizeRoles('admin', 'faculty'), updateAssessment);
router.delete('/:id', authorizeRoles('admin', 'faculty'), deleteAssessment);

module.exports = router;
