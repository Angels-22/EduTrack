const express = require('express');
const router = express.Router();
const {
  getAllSubjects,
  getSubjectById,
  createSubject,
  updateSubject,
  deleteSubject
} = require('../controllers/subjectController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', getAllSubjects);
router.get('/:id', getSubjectById);
router.post('/', authorizeRoles('admin', 'faculty'), createSubject);
router.put('/:id', authorizeRoles('admin', 'faculty'), updateSubject);
router.delete('/:id', authorizeRoles('admin'), deleteSubject);

module.exports = router;
