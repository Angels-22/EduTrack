const express = require('express');
const router = express.Router();
const {
  getStudentRiskAnalysis,
  getStudentRecommendations,
  getInterventionHistory,
  createTaskFromRecommendation,
  triggerReassessment,
  getBatchInterventionOverview
} = require('../controllers/interventionController');
const { authenticateToken, authorizeRoles, enforceStudentSelfAccess } = require('../middleware/auth');

router.use(authenticateToken);

// Institutional risk overview (Admin & Faculty)
router.get('/overview', authorizeRoles('admin', 'faculty'), getBatchInterventionOverview);

// Individual student risk analysis (Self or Faculty/Admin)
router.get('/risk-analysis/:studentId', enforceStudentSelfAccess, getStudentRiskAnalysis);

// Student recommendations
router.get('/recommendations/:studentId', enforceStudentSelfAccess, getStudentRecommendations);

// Intervention history & reassessment log
router.get('/history/:studentId', enforceStudentSelfAccess, getInterventionHistory);

// Convert recommendation into study planner task
router.post('/create-study-task', createTaskFromRecommendation);

// Manual trigger for reassessment
router.post('/reassess/:studentId', enforceStudentSelfAccess, triggerReassessment);

module.exports = router;
