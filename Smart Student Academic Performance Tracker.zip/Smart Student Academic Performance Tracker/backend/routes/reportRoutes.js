const express = require('express');
const router = express.Router();
const {
  getStudentReportData,
  exportMarksCsv,
  exportAttendanceCsv
} = require('../controllers/reportController');
const { authenticateToken, enforceStudentSelfAccess } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/student/:studentId', enforceStudentSelfAccess, getStudentReportData);
router.get('/export/marks-csv/:studentId', enforceStudentSelfAccess, exportMarksCsv);
router.get('/export/attendance-csv/:studentId', enforceStudentSelfAccess, exportAttendanceCsv);

module.exports = router;
