const express = require('express');
const router = express.Router();
const {
  getGoals,
  createGoal,
  updateGoal,
  deleteGoal,
  getAchievements
} = require('../controllers/goalController');
const { authenticateToken, enforceStudentSelfAccess } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', getGoals);
router.post('/', createGoal);
router.put('/:id', updateGoal);
router.delete('/:id', deleteGoal);
router.get('/achievements/:studentId', enforceStudentSelfAccess, getAchievements);

module.exports = router;
