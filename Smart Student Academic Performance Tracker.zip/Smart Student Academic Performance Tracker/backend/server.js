require('dotenv').config();
const app = require('./app');
const connectDB = require('./config/db');
const { validateProductionEnv } = require('./config/envValidator');

const PORT = process.env.PORT || 5000;

// Connect to MongoDB and listen
const startServer = async () => {
  try {
    // Validate security configuration if running in production
    validateProductionEnv();

    await connectDB();
    app.listen(PORT, () => {
      console.log('========================================================');
      console.log(`[EduTrack] Server successfully running on http://localhost:${PORT}`);
      console.log(`[EduTrack] Mode: ${process.env.NODE_ENV || 'development'}`);
      console.log(`[EduTrack] UI Dashboard: http://localhost:${PORT}/dashboard.html`);
      console.log(`[EduTrack] Central Innovation: http://localhost:${PORT}/interventions.html`);
      console.log('========================================================');
    });
  } catch (err) {
    console.error('[EduTrack Fatal Startup Error]', err.message);
    process.exit(1);
  }
};

startServer();
