/**
 * Safe Demo Data Seeding Script for Project Presentation & Viva
 * Populates realistic students, subjects, assessments, marks, attendance,
 * study tasks, and intervention histories across all three risk categories:
 * - On Track (High Performer)
 * - Needs Attention (Declining Trend)
 * - High Priority (Critical Attendance Deficit & Repeated Low Scores)
 */

require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../backend/config/db');

const User = require('../backend/models/User');
const Student = require('../backend/models/Student');
const Subject = require('../backend/models/Subject');
const Assessment = require('../backend/models/Assessment');
const Mark = require('../backend/models/Mark');
const Attendance = require('../backend/models/Attendance');
const StudyTask = require('../backend/models/StudyTask');
const Goal = require('../backend/models/Goal');
const Intervention = require('../backend/models/Intervention');
const Notification = require('../backend/models/Notification');
const { syncStudentInterventions } = require('../backend/services/interventionWorkflowService');

const seedDemoData = async () => {
  try {
    // Safety Guard 1: Never run demo seeding in production
    if (process.env.NODE_ENV === 'production') {
      console.error('\n[CRITICAL SECURITY ERROR] Demo data seeding is strictly prohibited in production environments (NODE_ENV=production).');
      console.error('This script wipes database collections and must only be used on a dedicated development or testing database.');
      process.exit(1);
    }

    // Safety Guard 2: Prevent accidental execution against production databases
    const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/edutrack';
    const isLocalOrDev = mongoUri.includes('127.0.0.1') || mongoUri.includes('localhost') || mongoUri.includes('test') || mongoUri.includes('dev');
    if (!isLocalOrDev && process.env.ALLOW_REMOTE_SEED !== 'true') {
      console.error('\n[CRITICAL SECURITY ERROR] Demo seed script detected a non-local MongoDB URI without explicit ALLOW_REMOTE_SEED=true.');
      console.error('Aborting execution to prevent accidental deletion of live institutional records.');
      console.error(`Target URI: ${mongoUri.replace(/:[^:@]+@/, ':****@')}`);
      process.exit(1);
    }

    await connectDB();
    console.log('[Seed] Connected to development database. Preparing demonstration dataset...');

    // 1. Clean existing records safely
    await Promise.all([
      User.deleteMany({}),
      Student.deleteMany({}),
      Subject.deleteMany({}),
      Assessment.deleteMany({}),
      Mark.deleteMany({}),
      Attendance.deleteMany({}),
      StudyTask.deleteMany({}),
      Goal.deleteMany({}),
      Intervention.deleteMany({}),
      Notification.deleteMany({})
    ]);

    console.log('[Seed] Cleaned existing collections.');

    // 2. Create Users
    const adminUser = await User.create({
      name: 'Dr. Sarah Mitchell (Administrator)',
      email: 'admin@edutrack.edu',
      password: 'admin123',
      role: 'admin',
      department: 'Computer Science and Engineering'
    });

    const facultyUser = await User.create({
      name: 'Prof. Ramesh Sharma (Faculty Mentor)',
      email: 'faculty@edutrack.edu',
      password: 'faculty123',
      role: 'faculty',
      department: 'Computer Science and Engineering'
    });

    const studentUser1 = await User.create({
      name: 'Arun Kumar',
      email: 'arun.kumar@edutrack.edu',
      password: 'student123',
      role: 'student',
      department: 'Computer Science and Engineering'
    });

    const studentUser2 = await User.create({
      name: 'Priya Nair',
      email: 'priya.nair@edutrack.edu',
      password: 'student123',
      role: 'student',
      department: 'Computer Science and Engineering'
    });

    const studentUser3 = await User.create({
      name: 'Rohit Verma',
      email: 'rohit.verma@edutrack.edu',
      password: 'student123',
      role: 'student',
      department: 'Computer Science and Engineering'
    });

    // 3. Create Student Profiles
    const student1 = await Student.create({
      studentId: 'STU2026001',
      userRef: studentUser1._id,
      fullName: 'Arun Kumar',
      email: 'arun.kumar@edutrack.edu',
      department: 'Computer Science and Engineering',
      course: 'B.Tech Information Technology',
      semester: 5,
      batchYear: '2023-2027',
      rollNo: '23CS101',
      contactNo: '+91 98765 43210',
      targetPercentage: 85,
      targetAttendance: 85
    });
    studentUser1.studentRef = student1._id;
    await studentUser1.save();

    const student2 = await Student.create({
      studentId: 'STU2026002',
      userRef: studentUser2._id,
      fullName: 'Priya Nair',
      email: 'priya.nair@edutrack.edu',
      department: 'Computer Science and Engineering',
      course: 'B.Tech Information Technology',
      semester: 5,
      batchYear: '2023-2027',
      rollNo: '23CS102',
      contactNo: '+91 98765 43211',
      targetPercentage: 75,
      targetAttendance: 80
    });
    studentUser2.studentRef = student2._id;
    await studentUser2.save();

    const student3 = await Student.create({
      studentId: 'STU2026003',
      userRef: studentUser3._id,
      fullName: 'Rohit Verma',
      email: 'rohit.verma@edutrack.edu',
      department: 'Computer Science and Engineering',
      course: 'B.Tech Information Technology',
      semester: 5,
      batchYear: '2023-2027',
      rollNo: '23CS103',
      contactNo: '+91 98765 43212',
      targetPercentage: 70,
      targetAttendance: 75
    });
    studentUser3.studentRef = student3._id;
    await studentUser3.save();

    console.log('[Seed] Users and Student Profiles created.');

    // 4. Create Subjects for Semester 5
    const subDAA = await Subject.create({
      code: 'CS501',
      name: 'Design and Analysis of Algorithms',
      department: 'Computer Science and Engineering',
      semester: 5,
      credits: 4,
      facultyName: 'Prof. Ramesh Sharma',
      maxMarks: 100,
      passingMarks: 40
    });

    const subDBMS = await Subject.create({
      code: 'CS502',
      name: 'Database Management Systems',
      department: 'Computer Science and Engineering',
      semester: 5,
      credits: 4,
      facultyName: 'Dr. Sarah Mitchell',
      maxMarks: 100,
      passingMarks: 40
    });

    const subCN = await Subject.create({
      code: 'CS503',
      name: 'Computer Networks',
      department: 'Computer Science and Engineering',
      semester: 5,
      credits: 3,
      facultyName: 'Prof. Anil Gupta',
      maxMarks: 100,
      passingMarks: 40
    });

    const subOS = await Subject.create({
      code: 'CS504',
      name: 'Operating Systems & Architecture',
      department: 'Computer Science and Engineering',
      semester: 5,
      credits: 3,
      facultyName: 'Dr. Neha Kulkarni',
      maxMarks: 100,
      passingMarks: 40
    });

    const subSE = await Subject.create({
      code: 'CS505',
      name: 'Software Engineering & Agile Methodologies',
      department: 'Computer Science and Engineering',
      semester: 5,
      credits: 3,
      facultyName: 'Prof. Ramesh Sharma',
      maxMarks: 100,
      passingMarks: 40
    });

    console.log('[Seed] Subjects created.');

    // 5. Create Assessments
    const assDAA_T1 = await Assessment.create({
      title: 'DAA Internal Assessment 1',
      type: 'Internal Test',
      subjectRef: subDAA._id,
      semester: 5,
      maxMarks: 50,
      weightagePercent: 20,
      date: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000)
    });

    const assDAA_T2 = await Assessment.create({
      title: 'DAA Internal Assessment 2',
      type: 'Internal Test',
      subjectRef: subDAA._id,
      semester: 5,
      maxMarks: 50,
      weightagePercent: 20,
      date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000)
    });

    const assDAA_Mid = await Assessment.create({
      title: 'DAA Midterm Examination',
      type: 'Midterm',
      subjectRef: subDAA._id,
      semester: 5,
      maxMarks: 100,
      weightagePercent: 30,
      date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000) // upcoming
    });

    const assDBMS_T1 = await Assessment.create({
      title: 'DBMS Internal Assessment 1',
      type: 'Internal Test',
      subjectRef: subDBMS._id,
      semester: 5,
      maxMarks: 50,
      weightagePercent: 20,
      date: new Date(Date.now() - 35 * 24 * 60 * 60 * 1000)
    });

    const assDBMS_T2 = await Assessment.create({
      title: 'DBMS Internal Assessment 2',
      type: 'Internal Test',
      subjectRef: subDBMS._id,
      semester: 5,
      maxMarks: 50,
      weightagePercent: 20,
      date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
    });

    const assCN_T1 = await Assessment.create({
      title: 'Networks Quiz & Lab Evaluation',
      type: 'Practical',
      subjectRef: subCN._id,
      semester: 5,
      maxMarks: 50,
      weightagePercent: 20,
      date: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000)
    });

    const assCN_T2 = await Assessment.create({
      title: 'Networks Internal Assessment 2',
      type: 'Internal Test',
      subjectRef: subCN._id,
      semester: 5,
      maxMarks: 50,
      weightagePercent: 20,
      date: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000)
    });

    console.log('[Seed] Assessments created.');

    // 6. Enter Marks
    // Student 1 (Arun - High Performer)
    await Mark.create({
      studentRef: student1._id,
      assessmentRef: assDAA_T1._id,
      subjectRef: subDAA._id,
      marksObtained: 44,
      maxMarks: 50,
      feedback: 'Excellent dynamic programming analysis.'
    });
    await Mark.create({
      studentRef: student1._id,
      assessmentRef: assDAA_T2._id,
      subjectRef: subDAA._id,
      marksObtained: 46,
      maxMarks: 50,
      feedback: 'Outstanding greedy graph traversal proof.'
    });
    await Mark.create({
      studentRef: student1._id,
      assessmentRef: assDBMS_T1._id,
      subjectRef: subDBMS._id,
      marksObtained: 42,
      maxMarks: 50,
      feedback: 'Good relational algebra queries.'
    });
    await Mark.create({
      studentRef: student1._id,
      assessmentRef: assDBMS_T2._id,
      subjectRef: subDBMS._id,
      marksObtained: 45,
      maxMarks: 50,
      feedback: 'Strong B+ tree normalization.'
    });
    await Mark.create({
      studentRef: student1._id,
      assessmentRef: assCN_T1._id,
      subjectRef: subCN._id,
      marksObtained: 43,
      maxMarks: 50,
      feedback: 'Precise packet sniffing experiment.'
    });

    // Student 2 (Priya - Declining trend in DBMS: was 74% (37/50), dropped to 52% (26/50) -> Drop of 22%!)
    await Mark.create({
      studentRef: student2._id,
      assessmentRef: assDBMS_T1._id,
      subjectRef: subDBMS._id,
      marksObtained: 37, // 74%
      maxMarks: 50,
      feedback: 'Good conceptual grasp.'
    });
    await Mark.create({
      studentRef: student2._id,
      assessmentRef: assDBMS_T2._id,
      subjectRef: subDBMS._id,
      marksObtained: 26, // 52% (drop of 22%, triggers Rule #2: Declining trend!)
      maxMarks: 50,
      feedback: 'Struggled with transaction isolation and indexing.'
    });
    await Mark.create({
      studentRef: student2._id,
      assessmentRef: assDAA_T1._id,
      subjectRef: subDAA._id,
      marksObtained: 36,
      maxMarks: 50,
      feedback: 'Satisfactory analysis.'
    });
    await Mark.create({
      studentRef: student2._id,
      assessmentRef: assCN_T1._id,
      subjectRef: subCN._id,
      marksObtained: 38,
      maxMarks: 50,
      feedback: 'Good socket programming lab.'
    });

    // Student 3 (Rohit - High Priority: Repeated low scores in DAA: 22/50 (44%), 20/50 (40%) -> Two scores <50%!)
    await Mark.create({
      studentRef: student3._id,
      assessmentRef: assDAA_T1._id,
      subjectRef: subDAA._id,
      marksObtained: 22, // 44% (<50%)
      maxMarks: 50,
      feedback: 'Fundamental recurrence relations incorrect.'
    });
    await Mark.create({
      studentRef: student3._id,
      assessmentRef: assDAA_T2._id,
      subjectRef: subDAA._id,
      marksObtained: 20, // 40% (<50%, triggers Rule #1: Repeated low scores!)
      maxMarks: 50,
      feedback: 'Struggled with graph representations.'
    });
    await Mark.create({
      studentRef: student3._id,
      assessmentRef: assDBMS_T1._id,
      subjectRef: subDBMS._id,
      marksObtained: 24, // 48% (<50%)
      maxMarks: 50,
      feedback: 'Need revision in SQL joins.'
    });

    console.log('[Seed] Marks entered.');

    // 7. Enter Attendance Records (20 sessions across subjects)
    const allSubjects = [subDAA, subDBMS, subCN, subOS, subSE];

    // Student 1 (Arun): Exemplary student - 100% attendance across all subjects (20/20 sessions Present)
    for (let i = 0; i < 20; i++) {
      const date = new Date(Date.now() - (20 - i) * 24 * 60 * 60 * 1000);
      const sub = allSubjects[i % allSubjects.length];
      await Attendance.create({
        studentRef: student1._id,
        subjectRef: sub._id,
        date,
        session: 'Session 1',
        status: 'Present',
        remarks: 'On-time attendance'
      });
    }

    // Student 2 (Priya): 80% attendance (16/20 sessions Present)
    for (let i = 0; i < 20; i++) {
      const date = new Date(Date.now() - (20 - i) * 24 * 60 * 60 * 1000);
      const sub = allSubjects[i % allSubjects.length];
      const status = [2, 7, 13, 17].includes(i) ? 'Absent' : 'Present';
      await Attendance.create({
        studentRef: student2._id,
        subjectRef: sub._id,
        date,
        session: 'Session 1',
        status
      });
    }

    // Student 3 (Rohit): 55% attendance (11 Present / 20 Held -> Critical Attendance Deficit <65%!)
    for (let i = 0; i < 20; i++) {
      const date = new Date(Date.now() - (20 - i) * 24 * 60 * 60 * 1000);
      const sub = allSubjects[i % allSubjects.length];
      const status = i % 2 === 0 ? 'Present' : 'Absent';
      await Attendance.create({
        studentRef: student3._id,
        subjectRef: sub._id,
        date,
        session: 'Session 1',
        status,
        remarks: status === 'Absent' ? 'Unexcused Absence' : ''
      });
    }

    console.log('[Seed] Attendance records generated.');

    // 8. Create Study Tasks
    await StudyTask.create({
      studentRef: student1._id,
      subjectRef: subDAA._id,
      title: 'Practice Advanced Dynamic Programming Problems',
      description: 'Solve 5 LeetCode hard problems on memoization and DAGs.',
      priority: 'Low',
      status: 'Completed',
      dueDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      estimatedHours: 4,
      completedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
    });

    await StudyTask.create({
      studentRef: student1._id,
      subjectRef: subDBMS._id,
      title: 'B+ Tree Indexing Simulation',
      description: 'Write an implementation of 2-3 trees and test splits.',
      priority: 'Medium',
      status: 'Completed',
      dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      estimatedHours: 3,
      completedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000)
    });

    await StudyTask.create({
      studentRef: student1._id,
      subjectRef: subDAA._id,
      title: 'Prepare for Midterm Examination',
      description: 'Review chapters 1-4 in CLRS textbook.',
      priority: 'High',
      status: 'In Progress',
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      estimatedHours: 6
    });

    // Student 2 Tasks
    await StudyTask.create({
      studentRef: student2._id,
      subjectRef: subDBMS._id,
      title: 'Analyze Lost Marks in DBMS Test 2',
      description: 'Review indexing and normalization mistakes with mentor.',
      priority: 'High',
      status: 'In Progress',
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      estimatedHours: 2,
      source: 'Intervention Recommendation'
    });

    // Student 3 Tasks (Has an overdue task to demonstrate Risk Radar Rule #5!)
    await StudyTask.create({
      studentRef: student3._id,
      subjectRef: subDAA._id,
      title: 'Solve Recurrence Relations Worksheet',
      description: 'Master theorem practice sheet assigned by faculty.',
      priority: 'High',
      status: 'Pending',
      dueDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000), // Overdue!
      estimatedHours: 3,
      source: 'Intervention Recommendation'
    });

    console.log('[Seed] Study tasks created.');

    // 9. Create Academic Goals
    await Goal.create({
      studentRef: student1._id,
      title: 'Achieve 85% in Semester 5 SGPA',
      category: 'Semester Percentage',
      targetValue: 85,
      currentValue: 88,
      deadline: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
      status: 'In Progress'
    });

    await Goal.create({
      studentRef: student2._id,
      title: 'Restore DBMS Score to Above 75%',
      category: 'Subject Marks',
      subjectRef: subDBMS._id,
      targetValue: 75,
      currentValue: 63,
      deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      status: 'In Progress'
    });

    await Goal.create({
      studentRef: student3._id,
      title: 'Recover Overall Attendance to 75%',
      category: 'Attendance',
      targetValue: 75,
      currentValue: 55,
      deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      status: 'In Progress'
    });

    console.log('[Seed] Goals created.');

    // 10. Automatically Trigger Initial Intervention Analysis for All Students
    console.log('[Seed] Triggering automated Smart Intervention synchronization...');
    await syncStudentInterventions(student1._id);
    await syncStudentInterventions(student2._id);
    await syncStudentInterventions(student3._id);

    // 11. Create Sample Notifications
    await Notification.create({
      userRef: studentUser2._id,
      title: 'Smart Academic Alert',
      message: 'A recent score drop was detected in Database Management Systems. Recommended action plan is ready.',
      type: 'warning',
      link: '/interventions.html'
    });

    await Notification.create({
      userRef: studentUser3._id,
      title: 'Attendance Recovery Notice',
      message: 'Your attendance has dropped below 65%. Please open the Attendance Recovery Calculator immediately.',
      type: 'alert',
      link: '/attendance-calculator.html'
    });

    await Notification.create({
      userRef: facultyUser._id,
      title: 'Batch Risk Summary',
      message: '1 student flagged with High Priority risk and 1 student needing attention in Semester 5.',
      type: 'info',
      link: '/interventions.html'
    });

    console.log('========================================================');
    console.log('[Seed Complete] Demonstration dataset successfully loaded!');
    console.log('Demo Credentials for Viva / Evaluation:');
    console.log('  1. Administrator: admin@edutrack.edu / admin123');
    console.log('  2. Faculty:       faculty@edutrack.edu / faculty123');
    console.log('  3. Student 1:     arun.kumar@edutrack.edu / student123  (On Track / High Performer)');
    console.log('  4. Student 2:     priya.nair@edutrack.edu / student123  (Needs Attention / DBMS Score Drop)');
    console.log('  5. Student 3:     rohit.verma@edutrack.edu / student123 (High Priority / Low Attendance & DAA Low Scores)');
    console.log('========================================================');

    process.exit(0);
  } catch (err) {
    console.error('[Seed Fatal Error]', err);
    process.exit(1);
  }
};

seedDemoData();
