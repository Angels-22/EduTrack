/**
 * Automated Test Suite for EduTrack
 * Tests:
 * 1. Mathematical Algorithms: Attendance Recovery Formula & Grade Simulator
 * 2. Smart Academic Intervention Logic: Risk Radar, Explanations, Recommendations
 * 3. Mongoose Model Validations: Mark limits, Duplicate prevention
 * 4. Authentication, RBAC & Cross-Student Security Protection
 */

require('dotenv').config();
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert');
const mongoose = require('mongoose');

// Services
const { calculateAttendanceRecovery } = require('../backend/services/attendanceCalculatorService');
const { simulateGrade } = require('../backend/services/gradeSimulatorService');
const { analyzeStudentRisk } = require('../backend/services/riskAnalysisService');
const { generateRecommendations } = require('../backend/services/recommendationService');
const { syncStudentInterventions } = require('../backend/services/interventionWorkflowService');

// Models
const Student = require('../backend/models/Student');
const User = require('../backend/models/User');
const Subject = require('../backend/models/Subject');
const Assessment = require('../backend/models/Assessment');
const Mark = require('../backend/models/Mark');
const Attendance = require('../backend/models/Attendance');
const StudyTask = require('../backend/models/StudyTask');
const Goal = require('../backend/models/Goal');

describe('EduTrack Core Academic Intelligence Test Suite', () => {

  // ========================================================
  // 1. ATTENDANCE RECOVERY CALCULATOR MATHEMATICS
  // ========================================================
  describe('1. Attendance Recovery Calculator Formula & Edge Cases', () => {
    test('Standard Recovery Case: A=10, T=20 (50%), Target=75% -> x = ceil((0.75*20 - 10)/(1 - 0.75)) = 20', () => {
      const res = calculateAttendanceRecovery({ attended: 10, total: 20, targetPercent: 75 });
      assert.strictEqual(res.isAchieved, false);
      assert.strictEqual(res.isFeasible, true);
      assert.strictEqual(res.additionalRequired, 20);
      // Verify projected: (10 + 20) / (20 + 20) = 30 / 40 = 75.0%
      assert.strictEqual(res.projectedPercent, 75.0);
    });

    test('Target Already Achieved: A=18, T=20 (90%), Target=75% -> x = 0, safe missable calculated', () => {
      const res = calculateAttendanceRecovery({ attended: 18, total: 20, targetPercent: 75 });
      assert.strictEqual(res.isAchieved, true);
      assert.strictEqual(res.additionalRequired, 0);
      assert.strictEqual(res.safeMissableClasses >= 1, true);
    });

    test('100% Target Impossible Case: Missed classes exist (A=19, T=20, Target=100%) -> isFeasible=false', () => {
      const res = calculateAttendanceRecovery({ attended: 19, total: 20, targetPercent: 100 });
      assert.strictEqual(res.isFeasible, false);
      assert.strictEqual(res.additionalRequired, null);
      assert.match(res.explanation, /mathematically impossible/i);
    });

    test('Zero Classes Held Case: A=0, T=0 -> Graceful handling without NaN or error', () => {
      const res = calculateAttendanceRecovery({ attended: 0, total: 0, targetPercent: 75 });
      assert.strictEqual(res.status, 'No Classes Yet');
      assert.strictEqual(res.additionalRequired, 0);
    });

    test('Invalid Input Rejection: Attended > Total throws validation error', () => {
      assert.throws(() => {
        calculateAttendanceRecovery({ attended: 25, total: 20, targetPercent: 75 });
      }, /cannot exceed/i);
    });
  });

  // ========================================================
  // 2. WHAT-IF GRADE SIMULATOR MATHEMATICS
  // ========================================================
  describe('2. What-If Grade Simulator Weighted Calculations', () => {
    test('Calculates weighted average and achievable score needed on remaining assessments', () => {
      // Completed: Test 1 (weight 20%, score 60%), Test 2 (weight 20%, score 70%)
      // Earned weighted: (60*0.2) + (70*0.2) = 12 + 14 = 26 points out of 40
      // Remaining: Final Exam (weight 60%)
      // Target: 75% overall
      // Needed weighted: 75 - 26 = 49 points out of 60% weight
      // Required on remaining: (49 / 60) * 100 = 81.67%
      const res = simulateGrade({
        completedAssessments: [
          { title: 'Test 1', weight: 20, scorePercent: 60 },
          { title: 'Test 2', weight: 20, scorePercent: 70 }
        ],
        remainingAssessments: [
          { title: 'Final Exam', weight: 60, hypotheticalScorePercent: 85 }
        ],
        targetPercent: 75
      });

      assert.strictEqual(res.isFeasible, true);
      assert.strictEqual(res.currentEarnedWeighted, 26);
      assert.strictEqual(res.requiredAverageOnRemaining, 81.67);
      // Projected with hypothetical 85%: 26 + (85 * 0.6) = 26 + 51 = 77.0%
      assert.strictEqual(res.projectedOverallScore, 77);
      assert.strictEqual(res.projectedGrade.grade, 'A');
    });

    test('Detects Mathematically Unachievable Target when remaining weight is insufficient', () => {
      // Completed: 40% weight with 30% score = 12 points earned
      // Remaining: 30% weight
      // Max possible: 12 + 30 = 42%
      // Target: 75% -> Unachievable!
      const res = simulateGrade({
        completedAssessments: [{ title: 'Midterm', weight: 40, scorePercent: 30 }],
        remainingAssessments: [{ title: 'Assignment', weight: 30, hypotheticalScorePercent: 100 }],
        targetPercent: 75
      });

      assert.strictEqual(res.isFeasible, false);
      assert.strictEqual(res.maxPossibleOverall, 42);
      assert.match(res.feasibilityMessage, /Target Unachievable/i);
    });
  });

  // ========================================================
  // 3. DATABASE INTEGRATION & RISK RADAR LOGIC
  // ========================================================
  describe('3. Database Validations & Smart Academic Risk Engine', () => {
    before(async () => {
      const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/edutrack';
      if (mongoose.connection.readyState === 0) {
        await mongoose.connect(mongoUri, { serverSelectionTimeoutMS: 5000 });
      }
    });

    test('Mark Validation: Rejects marksObtained > maxMarks', async () => {
      const dummyStudent = await Student.findOne();
      const dummySubject = await Subject.findOne();
      const dummyAss = await Assessment.findOne();

      if (!dummyStudent || !dummyAss) {
        return; // skip if seed data missing
      }

      const invalidMark = new Mark({
        studentRef: dummyStudent._id,
        assessmentRef: dummyAss._id,
        subjectRef: dummySubject ? dummySubject._id : dummyAss.subjectRef,
        marksObtained: 150, // exceeds max marks
        maxMarks: 50
      });

      await assert.rejects(async () => {
        await invalidMark.save();
      }, /cannot exceed/i);
    });

    test('Risk Radar: Identifies High Priority student (Rohit Verma) with repeated low scores and low attendance', async () => {
      const rohit = await Student.findOne({ studentId: 'STU2026003' });
      assert.ok(rohit, 'Rohit Verma record must exist from seed');

      const analysis = await analyzeStudentRisk(rohit._id);
      assert.strictEqual(analysis.overallRiskLevel, 'High Priority');
      assert.strictEqual(analysis.indicators.some((i) => i.id.startsWith('repeated-low-') || i.id.startsWith('crit-att-')), true);

      // Verify that every indicator has transparent explanations
      analysis.indicators.forEach((ind) => {
        assert.ok(ind.ruleApplied, 'Every indicator must state the rule applied');
        assert.ok(ind.supportingMeasurements, 'Every indicator must state measurements');
        assert.ok(ind.whyItMatters, 'Every indicator must explain why it matters');
        assert.ok(ind.recommendedAction, 'Every indicator must give actionable advice');
      });
    });

    test('Risk Radar: Identifies Declining Trend in Priya Nair (STU2026002)', async () => {
      const priya = await Student.findOne({ studentId: 'STU2026002' });
      assert.ok(priya, 'Priya Nair record must exist');

      const analysis = await analyzeStudentRisk(priya._id);
      assert.ok(['Needs Attention', 'High Priority'].includes(analysis.overallRiskLevel));
      const declineInd = analysis.indicators.find((i) => i.id.startsWith('decline-'));
      assert.ok(declineInd, 'Decline indicator must be detected in Priya Nair records');
      assert.match(declineInd.ruleApplied, /Rule #2/i);
    });

    test('Risk Radar: Identifies On Track status for Arun Kumar (STU2026001)', async () => {
      const arun = await Student.findOne({ studentId: 'STU2026001' });
      assert.ok(arun, 'Arun Kumar record must exist');

      const analysis = await analyzeStudentRisk(arun._id);
      assert.strictEqual(analysis.overallRiskLevel, 'On Track');
      assert.strictEqual(analysis.indicators[0].level, 'On Track');
    });

    test('Explainable Recommendations: Generates actionable advice and study tasks', async () => {
      const priya = await Student.findOne({ studentId: 'STU2026002' });
      const recResult = await generateRecommendations(priya._id);

      assert.ok(recResult.recommendations.length > 0);
      recResult.recommendations.forEach((rec) => {
        assert.ok(rec.title, 'Recommendation must have title');
        assert.ok(rec.reason, 'Recommendation must have reason');
        assert.ok(rec.actionItem, 'Recommendation must have concrete action item');
        assert.ok(rec.suggestedTask, 'Recommendation must link to a study task template');
      });
    });

    test('Reassessment Lifecycle: syncStudentInterventions preserves reassessment history', async () => {
      const rohit = await Student.findOne({ studentId: 'STU2026003' });
      const res = await syncStudentInterventions(rohit._id);

      assert.strictEqual(res.status, 'High Priority');
      assert.ok(res.activeIntervention, 'Active intervention record must be returned');
      assert.ok(Array.isArray(res.activeIntervention.reassessmentHistory));
    });

    after(async () => {
      await mongoose.disconnect();
    });
  });
});
