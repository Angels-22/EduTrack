/**
 * Automated Security & Role-Based Authorization Test Suite
 *
 * Verifies that:
 * 1. Public self-registration cannot create privileged faculty or administrator accounts.
 * 2. Demo quick-login is strictly blocked in production environments.
 * 3. Session tokens passed via URL query parameters are rejected (Bearer header only).
 * 4. Production configuration fails safely when required secrets are missing or weak.
 * 5. Cross-student data tampering is blocked across marks, attendance, tasks, goals, reports, and interventions.
 * 6. Students cannot alter protected institutional academic records (e.g. academicStatus, semester).
 */

require('dotenv').config();
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');

const app = require('../backend/app');
const User = require('../backend/models/User');
const Student = require('../backend/models/Student');
const Subject = require('../backend/models/Subject');
const Assessment = require('../backend/models/Assessment');
const Mark = require('../backend/models/Mark');
const Attendance = require('../backend/models/Attendance');
const StudyTask = require('../backend/models/StudyTask');
const Goal = require('../backend/models/Goal');
const { getJwtSecret } = require('../backend/config/envValidator');

describe('EduTrack Security & RBAC Authorization Test Suite', () => {
  let server;
  let baseUrl;
  let tokenStudentA;
  let tokenStudentB;
  let studentADoc;
  let studentBDoc;
  let userADoc;
  let userBDoc;
  let taskBDoc;
  let goalBDoc;
  let subjectDoc;

  before(async () => {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/edutrack';
    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(mongoUri, { serverSelectionTimeoutMS: 5000 });
    }

    // Start server on an ephemeral port
    await new Promise((resolve) => {
      server = app.listen(0, () => {
        const port = server.address().port;
        baseUrl = `http://127.0.0.1:${port}/api`;
        resolve();
      });
    });

    const secret = getJwtSecret();

    // Setup or retrieve Student A
    let studentA = await Student.findOne({ studentId: 'SEC_STU_A' });
    if (!studentA) {
      studentA = await Student.create({
        studentId: 'SEC_STU_A',
        fullName: 'Security Student Alpha',
        email: 'student.alpha.sec@edutrack.edu',
        department: 'Computer Science and Engineering',
        semester: 5
      });
    }
    studentADoc = studentA;

    let userA = await User.findOne({ email: 'student.alpha.sec@edutrack.edu' });
    if (!userA) {
      userA = await User.create({
        name: 'Security Student Alpha',
        email: 'student.alpha.sec@edutrack.edu',
        password: 'password123',
        role: 'student',
        studentRef: studentA._id
      });
    } else {
      userA.studentRef = studentA._id;
      await userA.save();
    }
    userADoc = userA;
    tokenStudentA = jwt.sign({ id: userA._id, email: userA.email, role: 'student', name: userA.name }, secret, { expiresIn: '1h' });

    // Setup or retrieve Student B
    let studentB = await Student.findOne({ studentId: 'SEC_STU_B' });
    if (!studentB) {
      studentB = await Student.create({
        studentId: 'SEC_STU_B',
        fullName: 'Security Student Beta',
        email: 'student.beta.sec@edutrack.edu',
        department: 'Computer Science and Engineering',
        semester: 5
      });
    }
    studentBDoc = studentB;

    let userB = await User.findOne({ email: 'student.beta.sec@edutrack.edu' });
    if (!userB) {
      userB = await User.create({
        name: 'Security Student Beta',
        email: 'student.beta.sec@edutrack.edu',
        password: 'password123',
        role: 'student',
        studentRef: studentB._id
      });
    } else {
      userB.studentRef = studentB._id;
      await userB.save();
    }
    userBDoc = userB;
    tokenStudentB = jwt.sign({ id: userB._id, email: userB.email, role: 'student', name: userB.name }, secret, { expiresIn: '1h' });

    // Setup test subject
    let subject = await Subject.findOne({ code: 'SEC101' });
    if (!subject) {
      subject = await Subject.create({
        code: 'SEC101',
        name: 'Network Security Principles',
        department: 'Computer Science and Engineering',
        semester: 5,
        credits: 3
      });
    }
    subjectDoc = subject;

    // Create a Task owned by Student B
    taskBDoc = await StudyTask.create({
      studentRef: studentBDoc._id,
      subjectRef: subjectDoc._id,
      title: 'Confidential Task for Student B',
      dueDate: new Date(Date.now() + 86400000),
      priority: 'High'
    });

    // Create a Goal owned by Student B
    goalBDoc = await Goal.create({
      studentRef: studentBDoc._id,
      subjectRef: subjectDoc._id,
      title: 'Private GPA Target for Student B',
      targetValue: 85,
      deadline: new Date(Date.now() + 86400000 * 30)
    });
  });

  after(async () => {
    // Clean up created security test fixtures
    if (taskBDoc) await StudyTask.deleteOne({ _id: taskBDoc._id }).catch(() => {});
    if (goalBDoc) await Goal.deleteOne({ _id: goalBDoc._id }).catch(() => {});
    if (userADoc) await User.deleteOne({ _id: userADoc._id }).catch(() => {});
    if (userBDoc) await User.deleteOne({ _id: userBDoc._id }).catch(() => {});
    if (studentADoc) await Student.deleteOne({ _id: studentADoc._id }).catch(() => {});
    if (studentBDoc) await Student.deleteOne({ _id: studentBDoc._id }).catch(() => {});

    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }

    if (mongoose.connection.readyState !== 0) {
      await mongoose.disconnect();
    }
  });

  // ========================================================
  // 1. PUBLIC REGISTRATION & ACCOUNT PRIVILEGE ESCALATION
  // ========================================================
  describe('1. Public Registration Security & Role Escalation Prevention', () => {
    test('Rejects public registration attempts requesting role=admin', async () => {
      const res = await fetch(`${baseUrl}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Attacker Admin Attempt',
          email: 'attacker.admin@example.edu',
          password: 'password123',
          role: 'admin'
        })
      });
      assert.strictEqual(res.status, 400);
      const data = await res.json();
      assert.strictEqual(data.success, false);
      assert.match(data.message, /restricted to student accounts only/i);
    });

    test('Rejects public registration attempts requesting role=faculty', async () => {
      const res = await fetch(`${baseUrl}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Attacker Faculty Attempt',
          email: 'attacker.faculty@example.edu',
          password: 'password123',
          role: 'faculty'
        })
      });
      assert.strictEqual(res.status, 400);
      const data = await res.json();
      assert.strictEqual(data.success, false);
      assert.match(data.message, /restricted to student accounts only/i);
    });

    test('Rejects account-linking hijacking when public registrant supplies an existing student ID with mismatched email', async () => {
      // studentBDoc has email 'student.beta.sec@edutrack.edu'
      const impostorEmail = `impostor.${Date.now()}@fraudulent.edu`;
      const res = await fetch(`${baseUrl}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Impostor Registrant',
          email: impostorEmail,
          password: 'password123',
          studentId: studentBDoc.studentId, // attempting to claim Student B's profile
          role: 'student'
        })
      });

      // Must be rejected with 403 or 409 (mismatched institutional email or already linked)
      assert.ok([403, 409].includes(res.status), `Expected 403 or 409 but got ${res.status}`);
      const data = await res.json();
      assert.strictEqual(data.success, false);
      assert.match(data.message, /linking|already linked|verification failed/i);

      // Verify no user was created with impostorEmail
      const impostorUser = await User.findOne({ email: impostorEmail });
      assert.strictEqual(impostorUser, null, 'Impostor user account must not be created');
    });

    test('Normal registration succeeds and strictly assigns student role', async () => {
      const randomEmail = `legit.student.${Date.now()}@example.edu`;
      const res = await fetch(`${baseUrl}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'Legitimate Student',
          email: randomEmail,
          password: 'password123',
          role: 'student'
        })
      });
      assert.strictEqual(res.status, 201);
      const data = await res.json();
      assert.strictEqual(data.success, true);
      assert.strictEqual(data.user.role, 'student');

      // Cleanup
      await User.deleteOne({ email: randomEmail });
    });
  });

  // ========================================================
  // 2. PRODUCTION DEMO LOGIN & JWT SECRETS
  // ========================================================
  describe('2. Demo Login Restrictions & Production Configuration Safety', () => {
    test('Blocks /api/auth/demo-login in production environments', async () => {
      const oldEnv = process.env.NODE_ENV;
      const oldAllow = process.env.ALLOW_DEMO_LOGIN;
      process.env.NODE_ENV = 'production';
      delete process.env.ALLOW_DEMO_LOGIN;

      try {
        const res = await fetch(`${baseUrl}/auth/demo-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ role: 'admin' })
        });
        assert.strictEqual(res.status, 403);
        const data = await res.json();
        assert.strictEqual(data.success, false);
        assert.match(data.message, /disabled in production/i);
      } finally {
        process.env.NODE_ENV = oldEnv;
        if (oldAllow) process.env.ALLOW_DEMO_LOGIN = oldAllow;
      }
    });

    test('Blocks /api/auth/demo-login in production even if ALLOW_DEMO_LOGIN=true is set', async () => {
      const oldEnv = process.env.NODE_ENV;
      const oldAllow = process.env.ALLOW_DEMO_LOGIN;
      process.env.NODE_ENV = 'production';
      process.env.ALLOW_DEMO_LOGIN = 'true';

      try {
        const res = await fetch(`${baseUrl}/auth/demo-login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ role: 'admin' })
        });
        assert.strictEqual(res.status, 403);
        const data = await res.json();
        assert.strictEqual(data.success, false);
        assert.match(data.message, /disabled in production/i);
      } finally {
        process.env.NODE_ENV = oldEnv;
        process.env.ALLOW_DEMO_LOGIN = oldAllow;
      }
    });

    test('Rejects tokens passed via URL query parameter (?token=...) without Authorization header', async () => {
      const res = await fetch(`${baseUrl}/auth/me?token=${tokenStudentA}`, {
        method: 'GET'
      });
      assert.strictEqual(res.status, 401);
      const data = await res.json();
      assert.strictEqual(data.success, false);
      assert.match(data.message, /Bearer token in the Authorization header/i);
    });

    test('getJwtSecret() throws fatal error in production when secret is weak or missing', () => {
      const oldEnv = process.env.NODE_ENV;
      const oldSecret = process.env.JWT_SECRET;
      process.env.NODE_ENV = 'production';
      process.env.JWT_SECRET = 'short';

      try {
        assert.throws(() => {
          getJwtSecret();
        }, /FATAL SECURITY CONFIGURATION ERROR/i);
      } finally {
        process.env.NODE_ENV = oldEnv;
        process.env.JWT_SECRET = oldSecret;
      }
    });

    test('getJwtSecret() rejects placeholder secrets in production deployments', () => {
      const oldEnv = process.env.NODE_ENV;
      const oldSecret = process.env.JWT_SECRET;
      process.env.NODE_ENV = 'production';
      process.env.JWT_SECRET = 'your_32_character_minimum_random_secret_string_here_2026';

      try {
        assert.throws(() => {
          getJwtSecret();
        }, /FATAL SECURITY CONFIGURATION ERROR/i);
      } finally {
        process.env.NODE_ENV = oldEnv;
        process.env.JWT_SECRET = oldSecret;
      }
    });
  });

  // ========================================================
  // 3. CROSS-STUDENT ACCESS ISOLATION (STUDENT A -> STUDENT B)
  // ========================================================
  describe('3. Cross-Student Data Isolation & Ownership Protection', () => {
    // Marks
    test('Student A cannot query Student B marks via query parameter (?studentId=B)', async () => {
      const res = await fetch(`${baseUrl}/marks?studentId=${studentBDoc._id}`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
      const data = await res.json();
      assert.strictEqual(data.success, false);
      assert.match(data.message, /Access Denied/i);
    });

    test('Student A cannot access Student B marks route (/marks/student/:id)', async () => {
      const res = await fetch(`${baseUrl}/marks/student/${studentBDoc._id}`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot enter or modify marks via POST /api/marks', async () => {
      const res = await fetch(`${baseUrl}/marks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({
          studentRef: studentADoc._id,
          assessmentRef: new mongoose.Types.ObjectId(),
          marksObtained: 99
        })
      });
      assert.strictEqual(res.status, 403);
    });

    // Attendance
    test('Student A cannot query Student B attendance via query parameter (?studentId=B)', async () => {
      const res = await fetch(`${baseUrl}/attendance?studentId=${studentBDoc._id}`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot access Student B attendance summary (/attendance/student/:id/summary)', async () => {
      const res = await fetch(`${baseUrl}/attendance/student/${studentBDoc._id}/summary`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot record attendance via POST /api/attendance', async () => {
      const res = await fetch(`${baseUrl}/attendance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({
          studentRef: studentADoc._id,
          subjectRef: subjectDoc._id,
          date: new Date()
        })
      });
      assert.strictEqual(res.status, 403);
    });

    // Study Tasks
    test('Student A cannot query Student B study tasks via ?studentId=B', async () => {
      const res = await fetch(`${baseUrl}/study-tasks?studentId=${studentBDoc._id}`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot create a task for Student B via POST /api/study-tasks', async () => {
      const res = await fetch(`${baseUrl}/study-tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({
          studentRef: studentBDoc._id,
          title: 'Illicit Task Injected by Student A',
          dueDate: new Date(Date.now() + 86400000)
        })
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot modify Student B study task via PUT /api/study-tasks/:id', async () => {
      const res = await fetch(`${baseUrl}/study-tasks/${taskBDoc._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({ title: 'Tampered Title by Student A' })
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot delete Student B study task via DELETE /api/study-tasks/:id', async () => {
      const res = await fetch(`${baseUrl}/study-tasks/${taskBDoc._id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    // Goals
    test('Student A cannot query Student B goals via ?studentId=B', async () => {
      const res = await fetch(`${baseUrl}/goals?studentId=${studentBDoc._id}`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot create a goal for Student B via POST /api/goals', async () => {
      const res = await fetch(`${baseUrl}/goals`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({
          studentRef: studentBDoc._id,
          title: 'Illicit Goal by Student A',
          targetValue: 90,
          deadline: new Date(Date.now() + 86400000)
        })
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot modify Student B goal via PUT /api/goals/:id', async () => {
      const res = await fetch(`${baseUrl}/goals/${goalBDoc._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({ title: 'Tampered Goal Title' })
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot delete Student B goal via DELETE /api/goals/:id', async () => {
      const res = await fetch(`${baseUrl}/goals/${goalBDoc._id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    // Reports & CSV Exports
    test('Student A cannot access Student B report transcript (/reports/student/:id)', async () => {
      const res = await fetch(`${baseUrl}/reports/student/${studentBDoc._id}`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot export Student B marks CSV (/reports/export/marks-csv/:id)', async () => {
      const res = await fetch(`${baseUrl}/reports/export/marks-csv/${studentBDoc._id}`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    test('Student A cannot export Student B attendance CSV (/reports/export/attendance-csv/:id)', async () => {
      const res = await fetch(`${baseUrl}/reports/export/attendance-csv/${studentBDoc._id}`, {
        headers: { 'Authorization': `Bearer ${tokenStudentA}` }
      });
      assert.strictEqual(res.status, 403);
    });

    // Interventions
    test('Student A cannot convert Student B recommendations via POST /api/interventions/create-study-task', async () => {
      const res = await fetch(`${baseUrl}/interventions/create-study-task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({
          studentId: studentBDoc._id,
          recommendationId: 'rec-test-1'
        })
      });
      assert.strictEqual(res.status, 403);
    });

    // Profile & Student Enrollment Tampering
    test('Student A cannot modify institutional fields (semester, academicStatus) via PUT /api/students/:id', async () => {
      const res = await fetch(`${baseUrl}/students/${studentADoc._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({
          semester: 8,
          academicStatus: 'Graduated With Honors'
        })
      });
      assert.strictEqual(res.status, 403);
      const data = await res.json();
      assert.strictEqual(data.success, false);
      assert.match(data.message, /not authorized to modify institutional/i);
    });

    test('Student A can update own personal target preferences (targetPercentage, targetAttendance)', async () => {
      const res = await fetch(`${baseUrl}/students/${studentADoc._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenStudentA}`
        },
        body: JSON.stringify({
          targetPercentage: 82.5,
          targetAttendance: 85.0
        })
      });
      assert.strictEqual(res.status, 200);
      const data = await res.json();
      assert.strictEqual(data.success, true);
      assert.strictEqual(data.student.targetPercentage, 82.5);
    });
  });
});
