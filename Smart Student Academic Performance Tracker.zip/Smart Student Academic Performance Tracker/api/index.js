require('dotenv').config();
const app = require('../backend/app');
const connectDB = require('../backend/config/db');

// Vercel Serverless Function Handler
module.exports = async (req, res) => {
  try {
    await connectDB();
    return app(req, res);
  } catch (err) {
    console.error('[Vercel Serverless Function DB Error]', err.message);
    res.status(500).json({
      success: false,
      message: 'Database connection failed in serverless function.',
      error: err.message
    });
  }
};
