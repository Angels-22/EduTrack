# EduTrack — Smart Academic Intelligence & Student Performance Tracker

[![Node.js](https://img.shields.io/badge/Node.js-v24.12.0-green.svg)](https://nodejs.org/)
[![Express](https://img.shields.io/badge/Express-4.21.2-lightgrey.svg)](https://expressjs.com/)
[![MongoDB](https://img.shields.io/badge/Database-MongoDB%20Atlas-brightgreen.svg)](https://www.mongodb.com/)
[![Bootstrap](https://img.shields.io/badge/UI-Bootstrap%205.3-purple.svg)](https://getbootstrap.com/)
[![Tests](https://img.shields.io/badge/Tests-39%2F39%20Passed-brightgreen.svg)](tests/)
[![Security](https://img.shields.io/badge/Security-RBAC%20%2B%20Data%20Isolation-blue.svg)](tests/security-authorization.test.js)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

> **Web Technology Capstone Project**  
> A full-stack academic intelligence SaaS platform featuring an **Explainable Rule-Based Academic Risk Radar**, closed-loop study action planning, **What-If Grade Simulation**, and mathematical **Attendance Recovery Modeling**.

---

## 🌟 The Central Innovation: Smart Academic Intervention System

Traditional college portals are passive record books: students only check their marks after end-semester grades are published, when it is already too late to avoid failure or attendance debarments.

**EduTrack transforms student records into an active academic improvement loop:**

$$\text{Data Ingestion} \longrightarrow \text{Rule Risk Radar} \longrightarrow \text{Transparent Explanation} \longrightarrow \text{1-Click Study Action Planner} \longrightarrow \text{Automated Reassessment}$$

### The 5 Explainability Principles
Unlike black-box machine learning models that generate unverified probabilistic claims, EduTrack's rule engine evaluates real MongoDB records with **100% transparency**:

1. **Concern Detected:** Exactly what issue was identified (e.g., *Performance Score Drop in DBMS*).
2. **Rule / Threshold Applied:** Centrally configured benchmark (e.g., *Rule #2: Score drop $\ge 10\%$ between consecutive assessments*).
3. **Concrete Evidence:** Traced to specific database entries (e.g., *Dropped by 22.0% from Test 1 (74%) to Test 2 (52%)*).
4. **Why It Matters:** Educational consequence explained in non-stigmatizing language.
5. **Next Action Step:** Direct actionable advice with a **1-Click button to generate a tracked Study Task** in the student's personal study planner.

---

## 🚀 Key Feature Modules

| Module | Description |
| :--- | :--- |
| **Smart Academic Intervention Center** | Central hub showing overall health status, Risk Radar badges, explainability traces, and historical reassessment logs. |
| **What-If Grade Simulator** | Real-time weighted assessment simulation calculating the exact average score needed on remaining tests to reach a target grade. |
| **Attendance Recovery Calculator** | Exact mathematical implementation of $x = \max(0, \lceil (rT - A)/(1 - r) \rceil)$, computing consecutive sessions needed to avoid debarment. |
| **Personalized Study Planner** | Interactive task management linked directly to intervention recommendations and academic goals. |
| **Goals & Verified Milestones** | Target setting and verified achievements (e.g. *Task Crusher*, *Attendance Guardian*, *Consistent Learner*). |
| **Continuous Assessment & Marks** | Internal tests, midterms, quizzes, and practicals with validation ensuring $0 \le \text{marksObtained} \le \text{maxMarks}$. |
| **Attendance Management Roster** | Session-level tracking (Present/Absent/Leave) with compound unique indexes preventing duplicate session logging. |
| **Transcripts & CSV Exports** | Formatted institutional semester progress transcripts with printable stylesheet (`window.print()`) and marks/attendance CSV downloads. |
| **Role-Based Access Control (RBAC)** | Strict authorization: Students can **only** access their own academic records; cross-user ID tampering returns HTTP 403 Forbidden. |
| **Dark & Light SaaS Themes** | High-contrast, responsive interface built with Bootstrap 5 and custom CSS custom properties. |

---

## 🛠 Technology Stack

- **Frontend:** HTML5, CSS3 (Custom Design System with Light/Dark Theme), Bootstrap 5.3, Vanilla JavaScript (ES6+), Chart.js 4.4
- **Backend:** Node.js (v24.x), Express.js (v4.21.x), RESTful APIs
- **Database:** MongoDB & Mongoose 8.9 (with schemas, compound indexes, and validation)
- **Security:** bcryptjs password hashing, JSON Web Tokens (JWT), express-rate-limit, strict cross-student access guards
- **Testing:** Node.js Native Test Runner (`node:test`, `node:assert`)
- **Deployment:** Vercel Serverless Function (`vercel.json`) & MongoDB Atlas

---

## 📂 Project Directory Structure

```text
edutrack/
├── api/
│   └── index.js                   # Vercel serverless function entrypoint
├── backend/
│   ├── config/
│   │   ├── constants.js           # Centrally configured thresholds & grading scales
│   │   └── db.js                  # Robust MongoDB connection handler
│   ├── controllers/               # REST API controllers for all modules
│   ├── middleware/                # JWT auth, RBAC, cross-student security, and error handler
│   ├── models/                    # Mongoose schemas with compound indexes & validations
│   ├── routes/                    # Express REST route handlers
│   ├── services/                  # Risk Radar, Recommendations, Grade Simulator, Attendance Engine
│   ├── app.js                     # Express application configuration
│   └── server.js                  # Local development server listener
├── docs/
│   ├── architecture.md            # System architecture and data flow diagrams
│   ├── api-documentation.md       # Complete REST API specification
│   ├── database-design.md         # Schema relationships, indexes, and validation rules
│   ├── test-cases.md              # Test matrix and execution verification
│   ├── project-report.md          # 27-section comprehensive academic project report
│   └── viva-preparation.md        # 2-minute elevator pitch, 5-minute script, and viva Q&A
├── public/
│   ├── css/styles.css             # Design system with light/dark variables and print styles
│   ├── js/app.js                  # Shared API client, theme toggle, and toast alert engine
│   ├── js/sidebar.js              # Dynamic navigation with demo role switcher
│   ├── index.html                 # Landing page & presentation launcher
│   ├── login.html                 # Sign In with 1-click evaluation accounts
│   ├── register.html              # Student registration with validation
│   ├── dashboard.html             # Academic Dashboard with KPI cards & Chart.js
│   ├── interventions.html         # CENTRAL INNOVATION: Smart Academic Intervention Center
│   ├── study-planner.html         # Personalized Study Planner
│   ├── grade-simulator.html       # What-If Grade Simulator
│   ├── attendance-calculator.html # Attendance Recovery Calculator
│   ├── goals.html                 # Goals and Verified Achievements
│   ├── students.html              # Student Directory Management (Admin/Faculty)
│   ├── subjects.html              # Curriculum & Course Management
│   ├── assessments.html           # Marks Entry & Assessment Management
│   ├── attendance.html            # Attendance Roster Management
│   ├── analytics.html             # Comparative Analytics & Charts
│   ├── reports.html               # Official Transcripts & CSV Exports
│   ├── settings.html              # Profile & Security Settings
│   └── help.html                  # Methodology, Architecture & Viva Guide
├── scripts/
│   └── seed-demo-data.js          # Demonstration dataset populating all 3 risk categories
├── tests/
│   └── unit-and-integration.test.js # Automated test suite (13/13 passing)
├── .env.example                   # Environment configuration template
├── package.json                   # Project scripts and dependencies
├── vercel.json                    # Vercel deployment configuration
└── README.md                      # Master project documentation
```

---

## ⚡ Quick Start & Local Setup

### 1. Prerequisites
- [Node.js](https://nodejs.org/) (v18 or higher; v24 recommended)
- [MongoDB](https://www.mongodb.com/) (Local instance running on `localhost:27017` or a MongoDB Atlas URI)

### 2. Installation
```bash
git clone https://github.com/your-username/edutrack-smart-academic-tracker.git
cd edutrack-smart-academic-tracker
npm install
```

### 3. Environment Configuration
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Ensure your MongoDB URI is set:
```ini
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/edutrack
JWT_SECRET=your_super_secret_jwt_key_2026
```

### 4. Seed Demonstration Data
Populate realistic students across all risk levels, curriculum subjects, marks, and attendance:
```bash
npm run seed
```

### 5. Start Application
```bash
npm start
```
Open **[http://localhost:5000](http://localhost:5000)** in your browser.

---

## 🔑 Demonstration Accounts for Viva & Evaluation

The project features a **1-Click Demo Role Switcher** on the top navigation bar of every page, as well as on the Login page:

| Role | Email | Password | Academic Profile / Scenario |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@edutrack.edu` | `admin123` | Institutional governance, curriculum, student management |
| **Faculty Mentor** | `faculty@edutrack.edu` | `faculty123` | Continuous mark entry, attendance roster, risk overview |
| **Student: Arun** | `arun.kumar@edutrack.edu` | `student123` | **On Track** (High Performer, 88.0% Marks, 92% Attendance) |
| **Student: Priya** | `priya.nair@edutrack.edu` | `student123` | **Needs Attention** (Declining trend: DBMS dropped by 22%) |
| **Student: Rohit** | `rohit.verma@edutrack.edu` | `student123` | **High Priority** (Critical Attendance 55%, 2 scores &lt;50%) |

---

## 🧪 Automated Testing & Security Verification

The project includes an automated test suite verifying mathematical algorithms, risk radar rules, database validations, and role-based data isolation:

```bash
# Run entire test suite (Unit + Integration + Security: 39 tests)
npm test

# Run mathematical & intervention integration tests (13 tests)
npm run test:unit

# Run RBAC, privilege escalation & data isolation security tests (26 tests)
npm run test:security
```

### Verified Test Results Matrix (39/39 Passing — 0 Failures):

#### 1. Mathematical Algorithms & Edge Cases (5/5 Passing)
- ✔ **Standard Attendance Recovery:** $A=10, T=20, r=0.75 \implies x = \lceil \frac{0.75 \times 20 - 10}{1 - 0.75} \rceil = 20$ consecutive classes.
- ✔ **Target Already Achieved:** $A=18, T=20 \implies x = 0$, safe missable allowance computed.
- ✔ **100% Target Boundary Check:** Identifies impossible 100% targets when missed classes exist.
- ✔ **Zero Classes Held Case:** $A=0, T=0$ handled gracefully without NaN or division-by-zero.
- ✔ **Input Validation:** Rejects attended > total classes.

#### 2. What-If Grade Simulator Mathematics (2/2 Passing)
- ✔ **Weighted Projections:** Calculates weighted scores earned and required averages across remaining tests.
- ✔ **Target Feasibility:** Detects mathematically unachievable targets when remaining weight is insufficient.

#### 3. Database Validations & Smart Academic Risk Engine (6/6 Passing)
- ✔ **Mark Validation:** Rejects $\text{marksObtained} > \text{maxMarks}$ with Mongoose schema validation.
- ✔ **Risk Radar (High Priority):** Identifies Rohit Verma with repeated low scores ($<50\%$) and critical attendance ($55\%$).
- ✔ **Risk Radar (Needs Attention):** Identifies Priya Nair's score drop ($\ge 10\%$) via Rule #2.
- ✔ **Risk Radar (On Track):** Identifies Arun Kumar's on-track standing via Rule #0.
- ✔ **Explainable Recommendations:** Generates concrete reasons, measurements, and 1-click study tasks.
- ✔ **Reassessment Lifecycle:** Preserves audit history and updates observed score improvements.

#### 4. Security & Role-Based Authorization Suite (26/26 Passing)
- ✔ **Public Registration:** Rejects attempts to self-register as `admin` (HTTP 400).
- ✔ **Public Registration:** Rejects attempts to self-register as `faculty` (HTTP 400).
- ✔ **Role Enforcement:** Guarantees public self-registration strictly assigns `role=student`.
- ✔ **Demo Login Safeguard:** Blocks `/api/auth/demo-login` in production (HTTP 403).
- ✔ **Query Token Rejection:** Rejects authentication tokens passed in URL query strings (HTTP 401).
- ✔ **Production Secret Guard:** Throws fatal error on startup if `JWT_SECRET` is missing, default, or $<32$ characters.
- ✔ **Cross-Student Marks (Filter):** Student A cannot query Student B's marks via `?studentId=B` (HTTP 403).
- ✔ **Cross-Student Marks (Route):** Student A cannot query `/api/marks/student/:bId` (HTTP 403).
- ✔ **Marks Modification:** Student A cannot enter or modify marks via `POST /api/marks` (HTTP 403).
- ✔ **Cross-Student Attendance (Filter):** Student A cannot query Student B's attendance via `?studentId=B` (HTTP 403).
- ✔ **Cross-Student Attendance (Route):** Student A cannot view `/api/attendance/student/:bId/summary` (HTTP 403).
- ✔ **Attendance Modification:** Student A cannot record attendance via `POST /api/attendance` (HTTP 403).
- ✔ **Cross-Student Tasks (Filter):** Student A cannot list Student B's tasks via `?studentId=B` (HTTP 403).
- ✔ **Task Tampering (Create):** Student A cannot inject tasks for Student B (HTTP 403).
- ✔ **Task Tampering (Update):** Student A cannot modify Student B's study task (HTTP 403).
- ✔ **Task Tampering (Delete):** Student A cannot delete Student B's study task (HTTP 403).
- ✔ **Cross-Student Goals (Filter):** Student A cannot list Student B's goals via `?studentId=B` (HTTP 403).
- ✔ **Goal Tampering (Create):** Student A cannot inject goals for Student B (HTTP 403).
- ✔ **Goal Tampering (Update):** Student A cannot modify Student B's goal (HTTP 403).
- ✔ **Goal Tampering (Delete):** Student A cannot delete Student B's goal (HTTP 403).
- ✔ **Cross-Student Transcripts:** Student A cannot view Student B's report transcript (HTTP 403).
- ✔ **Marks CSV Export:** Student A cannot export Student B's marks CSV (HTTP 403).
- ✔ **Attendance CSV Export:** Student A cannot export Student B's attendance CSV (HTTP 403).
- ✔ **Intervention Task Conversion:** Student A cannot convert Student B's recommendations (HTTP 403).
- ✔ **Enrollment Tampering:** Student A cannot alter institutional status or semester (HTTP 403).
- ✔ **Personal Target Updates:** Student A can update own target percentages and contact details (HTTP 200).

---

## 🌐 Deployment to Vercel & MongoDB Atlas

1. **MongoDB Atlas:**
   - Create a free cluster on [MongoDB Atlas](https://www.mongodb.com/atlas).
   - Create a database user and whitelist IP `0.0.0.0/0`.
   - Copy connection string: `mongodb+srv://<user>:<password>@cluster0.mongodb.net/edutrack?retryWrites=true&w=majority`.

2. **Vercel Deployment:**
   - Install Vercel CLI: `npm i -g vercel` or connect your GitHub repository directly in the Vercel dashboard.
   - Configure Environment Variables in Vercel Project Settings:
     - `MONGODB_URI`: Your MongoDB Atlas URI
     - `JWT_SECRET`: A secure random secret string
     - `NODE_ENV`: `production`
   - Deploy:
     ```bash
     vercel --prod
     ```

---

## 📄 License & Academic Integrity

This project is developed for academic evaluation under the **MIT License**. It demonstrates full-stack software engineering, input validation, role-based authorization, mathematical algorithm design, and explainable educational technology.
