# ACADEMIC PROJECT REPORT
## SMART STUDENT ACADEMIC PERFORMANCE TRACKER
### Web Technology Laboratory Capstone Project

**Project Title:** EduTrack — Smart Academic Intelligence & Student Performance Tracker  
**Domain:** Web Technology / Educational Technology SaaS  
**Author / Candidate:** Manisha Rajalingam  
**Date of Submission:** October 2026  
**Evaluation Criteria:** Design & UI/UX, Input Validation, Integration, Presentation Readiness, GitHub Governance  

---

## TABLE OF CONTENTS
1. Title Page & Metadata
2. Abstract
3. Introduction
4. Problem Statement
5. Objectives
6. Existing System and Limitations
7. Proposed System
8. System Requirements
9. Technology Stack & Justification
10. System Architecture
11. Database Design & Schema Relationships
12. Detailed Module Descriptions
13. User Interface Design & Navigation
14. RESTful API Design
15. Input Validation & Security Implementation
16. Central Innovation: Smart Academic Intervention System
17. Academic Risk Radar Methodology & Rules
18. What-If Grade Simulator Methodology
19. Attendance Recovery Mathematical Methodology
20. Implementation Details
21. Test Cases & Verified Results
22. Application Screen Captures & Visual Verification
23. Deployment (Vercel & MongoDB Atlas) & GitHub Governance
24. Limitations
25. Future Enhancements
26. Conclusion
27. References

---

### 1. Title Page & Metadata
- **Project Name:** EduTrack — Smart Academic Intelligence & Student Performance Tracker
- **Academic Stream:** Bachelor of Technology / Computer Science & Engineering
- **Course Title:** Web Technology Laboratory & Full-Stack Development

---

### 2. Abstract
Academic success in higher education relies heavily on early detection of performance degradation and proactive intervention. Existing institutional portals function as static record-keeping repositories that fail to offer real-time diagnostic insights or actionable recovery pathways. 

**EduTrack** introduces a full-stack, responsive academic SaaS platform built using Node.js, Express, MongoDB Atlas, and Bootstrap 5. Its central innovation is an explainable **Smart Academic Intervention System** incorporating a transparent, rule-based Academic Risk Radar. The engine evaluates continuous internal marks, attendance patterns, and score decline trends, providing students with explicit threshold justifications, concrete measurements, and a 1-click bridge to a personalized study planner. Coupled with a mathematically rigorous Attendance Recovery Calculator and What-If Grade Simulator, EduTrack equips students and faculty with the predictive intelligence required to remediate academic risks before final summative evaluations.

---

### 3. Introduction
In contemporary collegiate education, students balance multiple semester courses, lab practicals, continuous assessments, and mandatory attendance regulations. Conventional Learning Management Systems (LMS) and Enterprise Resource Planning (ERP) software act as passive databases; grades are logged, but students are left without guidance on how individual assessment scores impact their overall standing or how to recover from poor midterms.

EduTrack transforms this paradigm by converting academic data into continuous, explainable guidance. The system integrates automated rule engines with intuitive UI/UX design, dark/light themes, role-based authorization, and exportable official transcripts.

---

### 4. Problem Statement
1. **Late Discovery of Academic Risk:** Students typically discover low semester averages or attendance deficits after final exam schedules are published, leaving zero time for remediation.
2. **Black-Box Confusion:** When automated alerts exist in modern software, they are often opaque probabilistic predictions that cause anxiety without actionable guidance.
3. **Lack of Actionable Study Linkage:** Students lack tools that connect warning notices directly to structured, prioritized study tasks.
4. **Ad-Hoc Attendance Calculation:** Students manually guess how many consecutive lectures they must attend to overcome attendance debarment thresholds.

---

### 5. Objectives
1. Design and develop a responsive, full-stack Academic Performance Tracker adhering to commercial SaaS standards.
2. Build an explainable **Smart Academic Risk Radar** applying centralized, auditable pedagogical thresholds.
3. Formulate and implement closed-form mathematical engines for What-If Grade Simulation and Attendance Recovery.
4. Enforce strict server-side Role-Based Access Control (RBAC) ensuring student data privacy.
5. Provide comprehensive automated testing, detailed API documentation, and viva defense resources.

---

### 6. Existing System and Limitations
| Existing System Characteristic | Consequence / Limitation |
| :--- | :--- |
| **Passive Data Silos** | Only displays numbers; no trend detection or warning thresholds. |
| **End-of-Term Visibility** | Results are analyzed only when failures have already occurred. |
| **No Cross-Calculation** | No tools to project how future test scores will affect final GPA. |
| **Security Gaps** | Frequently susceptible to parameter tampering where changing an ID exposes another student's record. |

---

### 7. Proposed System
EduTrack provides an end-to-end active intelligence ecosystem:
- **Rule-Based Risk Radar:** Continuously evaluates scores for repeated failures ($<50\%$), sharp drops ($\ge 10\%$), and attendance deficits ($<75\%$).
- **Closed-Loop Action Planning:** Enables 1-click conversion of diagnostic recommendations into scheduled study tasks.
- **Interactive Calculators:** Delivers instant What-If simulations and discrete attendance recovery projections.
- **Strict Data Security:** Validates all bodies and guards student routes with JWT and ID self-access middleware.

---

### 8. System Requirements
- **Hardware Requirements:**
  - Processor: Dual-core 2.0 GHz or higher (Intel Core i3/i5/i7, AMD Ryzen, Apple Silicon).
  - RAM: 4 GB minimum (8 GB recommended).
  - Storage: 500 MB free disk space.
- **Software Requirements:**
  - Operating System: Windows 10/11, macOS, or Linux.
  - Runtime Environment: Node.js v18.0.0 or higher (v24 LTS tested).
  - Database: MongoDB 6.0+ (Local Community Edition or MongoDB Atlas Cloud).
  - Browser: Modern Web Browser (Chrome, Edge, Firefox, Safari).

---

### 9. Technology Stack & Justification
- **Frontend (HTML5, CSS3, Bootstrap 5.3, Vanilla JS):** Ensures native browser performance without heavy framework bundles or compile-time dependencies.
- **Backend (Node.js & Express.js):** Provides an event-driven, non-blocking asynchronous REST API architecture ideal for I/O-intensive educational workloads.
- **Database (MongoDB & Mongoose):** Document-oriented database facilitating dynamic assessment arrays, populated references, and compound unique indexing.
- **Security (bcryptjs & JWT):** Industry standard one-way password hashing and stateless token authentication.
- **Analytics (Chart.js):** Canvas-rendered charts for comparative performance and attendance trends.

---

### 10. System Architecture
EduTrack follows a classical 3-tier architecture:
1. **Presentation Tier:** HTML5 pages with dynamic client logic (`app.js`, `sidebar.js`).
2. **Application Tier:** Express.js REST API with rate-limiting, authentication middleware, and rule engines.
3. **Database Tier:** MongoDB instance storing users, students, subjects, assessments, marks, attendance, and audit logs.

*(Refer to `docs/architecture.md` for full sequence and component diagrams).*

---

### 11. Database Design & Schema Relationships
EduTrack models relational integrity in MongoDB using Mongoose reference pointers (`ref: 'Model'`) and compound unique indexes:
- `users`: Authentication credentials and role definitions.
- `students`: Profile information and target percentages.
- `subjects`: Curriculum definitions, credit hours, and passing marks.
- `assessments`: Scheduled tests with weightages and maximum marks.
- `marks`: Student scores with compound index `{ studentRef: 1, assessmentRef: 1 }` preventing duplicate entries.
- `attendance`: Daily logs with compound index `{ studentRef: 1, subjectRef: 1, date: 1, session: 1 }`.
- `studyTasks`: Actionable tasks linked to recommendations.
- `goals`: Targets and milestone achievements.
- `interventions`: Active risk records and reassessment histories.
- `auditLogs`: Administrative operation logs.

---

### 12. Detailed Module Descriptions
1. **Authentication & Profile Management:** Registration, secure password hashing, JWT generation, and profile updating.
2. **Student Directory Management:** Searchable, paginated student catalog with role-restricted CRUD operations.
3. **Curriculum & Semester Management:** Course catalog with credits, semester assignment, and faculty linkages.
4. **Continuous Assessment & Marks:** Assessment creation, score input with strict validation ($0 \le \text{marksObtained} \le \text{maxMarks}$), and auto-grading.
5. **Attendance Management:** Date-wise session recording with status tracking and duplicate prevention.
6. **Academic Dashboard:** Real-time summary displaying percentage, GPA, attendance rate, Chart.js trends, and urgent tasks.
7. **Academic Analytics:** Deep-dive comparative metrics, strength/weakness identification, and credit point registers.
8. **Smart Academic Intervention Center:** Central innovation displaying health state, transparent risk indicators, explainable recommendations, and historical reassessments.
9. **Personalized Study Planner:** Priority-based task boards with due dates and completion tracking.
10. **What-If Grade Simulator:** Weighted grade calculator with feasibility checking and required score estimation.
11. **Attendance Recovery Calculator:** Discrete mathematical engine solving for required consecutive classes.
12. **Goals & Achievements:** Milestone tracker recognizing effort, consistency, and target achievement.
13. **Official Reports & Transcripts:** Print-formatted semester transcripts with CSV export handlers.
14. **Audit Logs:** System activity monitor recording timestamps, actor identities, and modified resources.
15. **User Settings & Diagnostics:** Account preferences, password modification, and system health status.
16. **Viva & Methodology Guide:** In-app academic documentation, presentation scripts, and viva Q&A.

---

### 13. User Interface Design & Navigation
- **Theme Support:** Custom CSS variables enabling seamless switching between clean Light mode and sleek Dark mode.
- **Dynamic Navigation:** `sidebar.js` dynamically renders navigation links appropriate to the logged-in user's role while preserving active state highlighting.
- **Micro-Interactions:** Subtle card hover lifts, toast alerts with auto-dismissal, and modal confirmation dialogs.
- **Responsive Layout:** Off-canvas collapse navigation for mobile and tablet screens.

---

### 14. RESTful API Design
All endpoints follow REST principles with standard JSON structures:
`GET /api/interventions/risk-analysis/:id`, `POST /api/marks`, `POST /api/tools/grade-simulator`, `POST /api/tools/attendance-recovery`, etc. Complete request and response payloads are documented in `docs/api-documentation.md`.

---

### 15. Input Validation & Security Implementation
- **Client & Server-Side Validation:** All fields validated twice; server rejects numeric values exceeding maximums, negative hours, or invalid dates.
- **Password Protection:** Hashed via `bcryptjs` with 10 salt rounds; plain-text passwords never stored or logged.
- **Strict Self-Access Guard (`enforceStudentSelfAccess`):** Students can never view or modify another student's academic records; URL tampering triggers HTTP 403 Forbidden.
- **Rate Limiting:** Express-rate-limit applied to login and registration routes to prevent brute-force attacks.
- **Audit Logging:** Administrative operations tracked in `auditLogs` with secrets scrubbed.

---

### 16. Central Innovation: Smart Academic Intervention System
The heart of EduTrack is its closed-loop academic improvement workflow:
1. **Continuous Data Ingestion:** Evaluates real MongoDB marks and attendance logs.
2. **Transparent Risk Radar:** Identifies repeated low marks, consecutive drops, or attendance debarment risks.
3. **5-Point Explainability Trace:** Provides rule name, concrete evidence, educational reasoning, and recommended action.
4. **1-Click Study Planner Link:** Converts recommendations directly into persistent StudyTask documents.
5. **Automated Reassessment:** Recalculates indicators and logs observed score changes whenever faculty enter new marks.

---

### 17. Academic Risk Radar Methodology & Rules
- **Rule #0 (On Track):** Scores $\ge 60\%$ and attendance $\ge 75\%$.
- **Rule #1 (Repeated Low Scores):** $\ge 2$ assessment marks falling below $50\%$ in a subject $\implies$ High Priority.
- **Rule #2 (Declining Trend):** Score drop of $\ge 10\%$ between consecutive assessments $\implies$ Needs Attention.
- **Rule #3 (Below Target):** Subject average strictly below student's target percentage $\implies$ Needs Attention / High Priority.
- **Rule #4A (Critical Attendance Deficit):** Attendance strictly $<65\%$ $\implies$ High Priority.
- **Rule #4B (Attendance Warning):** Attendance between $65\%$ and $75\%$ $\implies$ Needs Attention.
- **Rule #5 (Overdue Study Tasks):** Study tasks past due date $\implies$ Needs Attention.

---

### 18. What-If Grade Simulator Methodology
Let completed assessments have total weight $W_{\text{comp}}$ and earned score $S_{\text{comp}} = \sum (w_i \times s_i / 100)$.
Remaining weight $W_{\text{rem}} = 100 - W_{\text{comp}}$.
For desired target $T_{\text{target}}$:
$$\text{Required Average on Remaining} = \frac{T_{\text{target}} - S_{\text{comp}}}{W_{\text{rem}}} \times 100$$
If $\text{Required Average} > 100\%$, the target is mathematically unachievable, and the interface clearly explains that the maximum attainable overall score is $S_{\text{comp}} + W_{\text{rem}}$.

---

### 19. Attendance Recovery Mathematical Methodology
For $A$ classes attended, $T$ classes held, and target fraction $r < 1$:
$$\frac{A + x}{T + x} \ge r \implies A + x \ge rT + rx \implies x(1 - r) \ge rT - A$$
$$x = \max\left(0, \left\lceil \frac{rT - A}{1 - r} \right\rceil\right)$$
If $r = 1.0$ and $A < T$, reaching 100% is mathematically impossible. The system also calculates safe skip allowance: $y = \lfloor (A - rT)/r \rfloor$.

---

### 20. Implementation Details
The backend is structured into modular directories (`config/`, `controllers/`, `middleware/`, `models/`, `routes/`, `services/`). Business calculations reside exclusively in backend services, guaranteeing consistency between the dashboard, calculators, and official transcripts.

---

### 21. Test Cases & Verified Results
An automated test suite (`tests/unit-and-integration.test.js`) executes 13 comprehensive unit and integration tests against local MongoDB.
- All 13 tests passed (100% success rate in 940 ms).
- Validated mathematical formulas, boundary conditions, Mongoose validation rejections, and Risk Radar detections across all three student risk categories.

---

### 22. Application Screen Captures & Visual Verification
*(Refer to browser subagent recording artifact: `edutrack_app_demo.webp` and captured PNG assets in the brain artifact repository).*
The interface exhibits clean typography (Plus Jakarta Sans), consistent card elevation, accessible contrast ratios, and responsive sidebar navigation across desktop and mobile viewports.

---

### 23. Deployment (Vercel & MongoDB Atlas) & GitHub Governance
- **Vercel Serverless Function:** Configured via `vercel.json` and `api/index.js` exporting the Express application with cached MongoDB connection reuse.
- **MongoDB Atlas:** Supports hosted production connection strings via `MONGODB_URI`.
- **Git & GitHub:** Git repository initialized with `.gitignore` strictly excluding `.env`, `node_modules`, and temporary logs.

---

### 24. Limitations
1. Does not currently support biometric fingerprint hardware integration directly (attendance is recorded digitally via faculty portal).
2. Semester credit weighting assumes standard 10-point UGC grade scale (can be reconfigured in `constants.js`).

---

### 25. Future Enhancements
1. WhatsApp / SMS push notifications for critical attendance alerts.
2. Machine learning regression models as an optional advisory layer alongside the deterministic rule engine.
3. Integration with university RFID smart-card turnstiles for automated attendance logging.

---

### 26. Conclusion
EduTrack successfully delivers an advanced, production-ready, full-stack Academic Performance Tracker that satisfies all evaluation criteria. Its transparent **Smart Academic Intervention System**, coupled with closed-form simulation tools and role-based data governance, elevates student performance tracking from passive record storage to proactive educational intelligence.

---

### 27. References
1. Node.js Official Documentation: [https://nodejs.org/docs](https://nodejs.org/docs)
2. Express.js API Reference: [https://expressjs.com/en/4x/api.html](https://expressjs.com/en/4x/api.html)
3. MongoDB & Mongoose ODM Manual: [https://mongoosejs.com/docs](https://mongoosejs.com/docs)
4. Bootstrap 5.3 Documentation: [https://getbootstrap.com/docs/5.3/](https://getbootstrap.com/docs/5.3/)
5. UGC Guidelines on Choice Based Credit System (CBCS): University Grants Commission, New Delhi.
