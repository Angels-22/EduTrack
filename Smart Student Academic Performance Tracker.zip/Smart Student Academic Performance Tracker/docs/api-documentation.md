# EduTrack — RESTful API Specification

Base URL: `http://localhost:5000/api` (Local) or `https://<deployed-domain>/api` (Production)

All protected endpoints require the HTTP Header:
```http
Authorization: Bearer <jwt-token>
```

---

## 1. Authentication Endpoints (`/api/auth`)

### `POST /api/auth/register`
Registers a new student user account.
- **Access:** Public
- **Request Body:**
  ```json
  {
    "name": "Maya Krishnan",
    "email": "maya@edutrack.edu",
    "password": "password123",
    "studentId": "STU2026045",
    "semester": 5,
    "department": "Computer Science and Engineering"
  }
  ```
- **Response (201 Created):**
  ```json
  { "success": true, "token": "jwt...", "user": { "id": "...", "name": "Maya Krishnan", "role": "student" } }
  ```

### `POST /api/auth/login`
Authenticates user and returns JWT token.
- **Access:** Public
- **Request Body:**
  ```json
  { "email": "faculty@edutrack.edu", "password": "faculty123" }
  ```
- **Response (200 OK):**
  ```json
  { "success": true, "token": "jwt...", "user": { "id": "...", "role": "faculty", "name": "Prof. Ramesh Sharma" } }
  ```

### `POST /api/auth/demo-login`
Quick-switcher for evaluation demo accounts.
- **Access:** Public
- **Request Body:** `{ "role": "admin" | "faculty" | "student" }`

---

## 2. Central Innovation: Intervention Endpoints (`/api/interventions`)

### `GET /api/interventions/risk-analysis/:studentId`
Executes transparent rule-based risk analysis for a student.
- **Access:** Protected (Self or Faculty/Admin)
- **Response (200 OK):**
  ```json
  {
    "success": true,
    "analysis": {
      "overallRiskLevel": "Needs Attention",
      "overallMarksPercent": 69.8,
      "overallAttendancePercent": 80.0,
      "indicators": [
        {
          "id": "decline-CS502",
          "subject": "Database Management Systems",
          "level": "Needs Attention",
          "title": "Performance Score Drop Detected in Database Management Systems",
          "ruleApplied": "Rule #2: Recent score drop of ≥10% between consecutive assessments",
          "supportingMeasurements": "Dropped by 22.0% from DBMS Test 1 (74%) to DBMS Test 2 (52%)",
          "whyItMatters": "A downward shift often indicates emerging topic complexity.",
          "recommendedAction": "Review recent assessment feedback and clarify complex conceptual doubts."
        }
      ]
    }
  }
  ```

### `GET /api/interventions/recommendations/:studentId`
Returns deterministic explainable recommendations linked to study tasks.
- **Access:** Protected (Self or Faculty/Admin)

### `POST /api/interventions/create-study-task`
Converts an explainable recommendation directly into a persistent Study Task document in MongoDB.
- **Access:** Protected
- **Request Body:**
  ```json
  { "studentId": "...", "recommendationId": "rec-decline-CS502" }
  ```

### `POST /api/interventions/reassess/:studentId`
Manually triggers complete re-evaluation of all academic records and persists observed changes into `reassessmentHistory`.
- **Access:** Protected (Self or Faculty/Admin)

---

## 3. Academic Tools & Simulation Endpoints (`/api/tools`)

### `POST /api/tools/grade-simulator`
Executes What-If weighted grade projection.
- **Request Body:**
  ```json
  {
    "completedAssessments": [{ "title": "Test 1", "weight": 20, "scorePercent": 60 }],
    "remainingAssessments": [{ "title": "Final", "weight": 60, "hypotheticalScorePercent": 85 }],
    "targetPercent": 75
  }
  ```
- **Response (200 OK):**
  ```json
  {
    "success": true,
    "result": {
      "currentEarnedWeighted": 12,
      "projectedOverallScore": 63,
      "projectedGrade": { "grade": "B+", "label": "Good" },
      "isFeasible": true,
      "requiredAverageOnRemaining": 78.75
    }
  }
  ```

### `POST /api/tools/attendance-recovery`
Executes closed-form attendance recovery calculation: $x = \max(0, \lceil (rT - A)/(1 - r) \rceil)$.
- **Request Body:** `{ "attended": 10, "total": 20, "targetPercent": 75 }`
- **Response (200 OK):**
  ```json
  {
    "success": true,
    "result": {
      "currentPercent": 50.0,
      "targetPercent": 75,
      "additionalRequired": 20,
      "isAchieved": false,
      "isFeasible": true,
      "safeMissableClasses": 0,
      "explanation": "You have attended 10 out of 20 classes (50.0%). You must attend the next 20 consecutive classes..."
    }
  }
  ```

---

## 4. Academic Records Endpoints

### `POST /api/marks`
Enters or updates assessment marks and automatically synchronizes the Risk Radar.
- **Access:** Admin / Faculty only
- **Request Body:**
  ```json
  {
    "studentRef": "...",
    "assessmentRef": "...",
    "marksObtained": 44,
    "feedback": "Strong algorithmic proofs."
  }
  ```

### `POST /api/attendance`
Records a single session attendance entry.
- **Access:** Admin / Faculty only
- **Request Body:**
  ```json
  {
    "studentRef": "...",
    "subjectRef": "...",
    "date": "2026-10-22",
    "session": "Session 1",
    "status": "Present"
  }
  ```

---

## 5. Reports & CSV Export Endpoints

- `GET /api/reports/student/:studentId` — Structured transcript JSON object
- `GET /api/reports/export/marks-csv/:studentId` — Tabular marks CSV download
- `GET /api/reports/export/attendance-csv/:studentId` — Tabular attendance CSV download
