# EduTrack — System Architecture Document

## 1. System Architectural Overview

EduTrack employs a modular, decoupled **Client-Server 3-Tier SaaS Architecture** engineered for high scalability, strict security, and maintainability:

```mermaid
graph TD
    Client["Client Layer (HTML5, Bootstrap 5, Chart.js, Vanilla JS)"]
    API["API Gateway / Controller Layer (Express.js Routing, Rate Limiting)"]
    Auth["Security & RBAC Middleware (JWT Bearer Token, Cross-Student Access Guard)"]
    Engine["Business Logic & Innovation Engines (Risk Radar, Grade Simulator, Recovery Calc)"]
    Data["Data Access Layer (Mongoose ODM, Schema Validation, Compound Indexes)"]
    DB[("Persistence Layer (MongoDB Atlas / Local MongoDB)")]

    Client -->|HTTPS REST Calls| API
    API --> Auth
    Auth --> Engine
    Engine --> Data
    Data --> DB
```

---

## 2. Layered Component Responsibilities

### A. Presentation Tier (Frontend)
- **Structure:** Semantic HTML5 pages.
- **Styling:** Bootstrap 5.3 augmented with custom CSS variables for instant Light/Dark mode toggling.
- **Client Logic:** Vanilla ES6+ JavaScript (`app.js`, `sidebar.js`) handling token management, toast feedback, asynchronous `fetch()` API calls, and Chart.js graphics.
- **Access Control:** Client-side route guarding and dynamic sidebar rendering based on logged-in user role (`admin`, `faculty`, `student`).

### B. Application & Business Logic Tier (Backend)
- **Runtime:** Node.js (v24.x LTS).
- **Web Framework:** Express.js providing RESTful route endpoints, centralized error handling, and rate limiting.
- **Authentication & Security:** 
  - `bcryptjs` for one-way password hashing (salt rounds: 10).
  - `jsonwebtoken` (JWT) with 7-day expiration and Bearer token headers.
  - `enforceStudentSelfAccess` middleware preventing ID-swapping privilege escalation.
- **Core Innovation Engine:**
  - `riskAnalysisService`: Evaluates historical records against centralized thresholds (`constants.js`).
  - `recommendationService`: Generates deterministic, explainable next-action recommendations.
  - `interventionWorkflowService`: Bridges recommendations to persistent `StudyTask` documents.
  - `gradeSimulatorService`: Evaluates weighted projections and target feasibility.
  - `attendanceCalculatorService`: Implements closed-form discrete recovery formulas.

### C. Persistence Tier (Database)
- **Database Engine:** MongoDB (Document Store) supporting flexible schema models and high-performance querying.
- **Object Data Modeling (ODM):** Mongoose 8.9 enforcing strict type casting, pre-validation hooks, and compound unique indexes.

---

## 3. Data Flow Diagram: The Central Innovation Loop

```mermaid
sequenceDiagram
    autonumber
    actor Faculty
    participant API as Express API
    participant DB as MongoDB
    participant Radar as Risk Radar Engine
    actor Student
    participant Planner as Study Planner

    Faculty->>API: POST /api/marks (Enter Test Mark)
    API->>DB: Save Mark Document
    API->>Radar: Trigger Automated Reassessment (syncStudentInterventions)
    Radar->>DB: Fetch Marks, Attendance, Tasks
    Radar->>Radar: Evaluate Rule #1, #2, #3, #4A/B, #5
    Radar->>DB: Upsert Intervention Record & Reassessment History
    
    Student->>API: GET /api/interventions/risk-analysis/:id
    API-->>Student: Return Health Level, Indicators, & Concrete Evidence
    
    Student->>API: POST /api/interventions/create-study-task
    API->>Planner: Create Persistent StudyTask in MongoDB
    Planner-->>Student: Task Added to Action Board
```

---

## 4. Key Design Decisions & Trade-offs

1. **Rule-Based Engine vs. Machine Learning:**
   - *Decision:* We opted for a deterministic rule-based engine instead of a deep neural network or LLM API.
   - *Justification:* In educational environments, decisions must be **100% explainable, deterministic, and auditable**. Students must know the exact rule and evidence behind a warning.
2. **Vanilla JavaScript vs. Single-Page Application (SPA) Frameworks:**
   - *Decision:* We used HTML5, Vanilla JavaScript, and Bootstrap 5 without heavy frontend build steps.
   - *Justification:* Zero-overhead deployment on Vercel, maximum performance, straightforward multi-page navigation for viva evaluation, and adherence to project requirements.
