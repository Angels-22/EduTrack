# EduTrack — Test Cases & Automated Test Execution Matrix

This document provides the complete test specification, input-output matrices, and execution verification logs for the automated test suite (`tests/unit-and-integration.test.js`).

---

## 1. Test Execution Summary

- **Test Framework:** Node.js Native Test Runner (`node:test`, `node:assert`)
- **Total Test Suites:** 4
- **Total Executed Tests:** 13
- **Passed:** 13
- **Failed:** 0
- **Duration:** 940 ms
- **Exit Code:** 0

---

## 2. Test Cases Matrix

| Test ID | Module / Component | Test Objective | Inputs | Expected Output | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-ATT-01** | Attendance Calculator | Standard recovery calculation | $A=10, T=20, r=0.75$ | $x=20$, `isAchieved=false`, `projected=75.0%` | **PASS** |
| **TC-ATT-02** | Attendance Calculator | Target already achieved | $A=18, T=20, r=0.75$ | $x=0$, `isAchieved=true`, `safeMissable >= 1` | **PASS** |
| **TC-ATT-03** | Attendance Calculator | Boundary: 100% target with missed class | $A=19, T=20, r=1.00$ | `isFeasible=false`, `additionalRequired=null` | **PASS** |
| **TC-ATT-04** | Attendance Calculator | Zero classes conducted | $A=0, T=0, r=0.75$ | `status="No Classes Yet"`, `additional=0` | **PASS** |
| **TC-ATT-05** | Attendance Calculator | Validation: Attended > Total | $A=25, T=20$ | Throws Error (`cannot exceed`) | **PASS** |
| **TC-SIM-01** | What-If Grade Simulator | Weighted score projection | Completed: $20\% @ 60, 20\% @ 70$<br>Rem: $60\% @ 85$, Target: $75\%$ | `currentEarned=26`, `projectedScore=77%`, `needed=81.67%` | **PASS** |
| **TC-SIM-02** | What-If Grade Simulator | Unachievable target detection | Completed: $40\% @ 30$, Rem: $30\%$, Target: $75\%$ | `isFeasible=false`, `maxPossible=42%` | **PASS** |
| **TC-MOD-01** | Mark Mongoose Model | Validation: Marks obtained > Max marks | `marksObtained: 150`, `maxMarks: 50` | Mongoose ValidationError rejected | **PASS** |
| **TC-RAD-01** | Risk Radar Engine | Detect repeated low scores & critical attendance | Student `STU2026003` (Rohit Verma) | `High Priority`, Rule #1 & #4A flagged | **PASS** |
| **TC-RAD-02** | Risk Radar Engine | Detect consecutive score decline | Student `STU2026002` (Priya Nair) | `decline-CS502` flagged (22% drop, Rule #2) | **PASS** |
| **TC-RAD-03** | Risk Radar Engine | Detect On Track benchmark compliance | Student `STU2026001` (Arun Kumar) | `overallRiskLevel="On Track"`, Rule #0 | **PASS** |
| **TC-REC-01** | Recommendation Engine | Generate explainable study actions | Student `STU2026002` (Priya Nair) | Title, Reason, Action Item, and Task Template | **PASS** |
| **TC-INT-01** | Intervention Workflow | Reassessment audit log persistence | Student `STU2026003` (Rohit Verma) | Intervention upserted with `reassessmentHistory` | **PASS** |

---

## 3. Terminal Execution Log

```text
> edutrack-smart-academic-tracker@1.0.0 test
> node --test tests/unit-and-integration.test.js

▶ EduTrack Core Academic Intelligence Test Suite
  ▶ 1. Attendance Recovery Calculator Formula & Edge Cases
    ✔ Standard Recovery Case: A=10, T=20 (50%), Target=75% -> x = ceil((0.75*20 - 10)/(1 - 0.75)) = 20 (1.1682ms)
    ✔ Target Already Achieved: A=18, T=20 (90%), Target=75% -> x = 0, safe missable calculated (0.2866ms)
    ✔ 100% Target Impossible Case: Missed classes exist (A=19, T=20, Target=100%) -> isFeasible=false (0.44ms)
    ✔ Zero Classes Held Case: A=0, T=0 -> Graceful handling without NaN or error (0.1983ms)
    ✔ Invalid Input Rejection: Attended > Total throws validation error (0.6087ms)
  ✔ 1. Attendance Recovery Calculator Formula & Edge Cases (3.8008ms)
  ▶ 2. What-If Grade Simulator Weighted Calculations
    ✔ Calculates weighted average and achievable score needed on remaining assessments (0.6103ms)
    ✔ Detects Mathematically Unachievable Target when remaining weight is insufficient (0.332ms)
  ✔ 2. What-If Grade Simulator Weighted Calculations (1.1801ms)
  ▶ 3. Database Validations & Smart Academic Risk Engine
    ✔ Mark Validation: Rejects marksObtained > maxMarks (72.4208ms)
    ✔ Risk Radar: Identifies High Priority student (Rohit Verma) with repeated low scores and low attendance (60.8858ms)
    ✔ Risk Radar: Identifies Declining Trend in Priya Nair (STU2026002) (24.0339ms)
    ✔ Risk Radar: Identifies On Track status for Arun Kumar (STU2026001) (16.5849ms)
    ✔ Explainable Recommendations: Generates actionable advice and study tasks (19.4068ms)
    ✔ Reassessment Lifecycle: syncStudentInterventions preserves reassessment history (42.4412ms)
  ✔ 3. Database Validations & Smart Academic Risk Engine (302.5147ms)
✔ EduTrack Core Academic Intelligence Test Suite (308.4079ms)
ℹ tests 13
ℹ suites 4
ℹ pass 13
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 940.7139
```
