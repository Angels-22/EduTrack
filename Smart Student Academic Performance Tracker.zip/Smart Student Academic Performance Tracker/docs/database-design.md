# EduTrack — Database Design & Schema Architecture

## 1. Entity-Relationship Overview

EduTrack uses MongoDB with Mongoose ODM. Schemas are linked via Mongoose `ObjectId` references (`ref`) to enforce relational integrity while retaining document-level query speeds:

```mermaid
erDiagram
    User ||--o| Student : "links to"
    Student ||--o{ Mark : "receives"
    Student ||--o{ Attendance : "records"
    Student ||--o{ StudyTask : "maintains"
    Student ||--o{ Goal : "sets"
    Student ||--o{ Intervention : "tracked in"
    Subject ||--o{ Assessment : "contains"
    Subject ||--o{ Mark : "evaluates"
    Subject ||--o{ Attendance : "rosters"
    Assessment ||--o{ Mark : "grades"
```

---

## 2. Collections Specification

### 1. `users`
Stores system accounts for Administrators, Faculty Mentors, and Students.
- `_id`: ObjectId (Primary Key)
- `name`: String, required, trim
- `email`: String, required, unique, lowercase
- `password`: String, required (bcrypt hash)
- `role`: String, enum: `['admin', 'faculty', 'student']`
- `department`: String
- `studentRef`: ObjectId ref `'Student'`, default null
- `status`: String, enum: `['active', 'inactive']`
- `lastLogin`: Date

### 2. `students`
Stores institutional enrollment details and personal targets.
- `_id`: ObjectId (Primary Key)
- `studentId`: String, required, unique, uppercase (Indexed)
- `userRef`: ObjectId ref `'User'`
- `fullName`: String, required
- `email`: String, required, unique, lowercase
- `department`: String, required
- `course`: String (e.g. `'B.Tech IT'`)
- `semester`: Number, required (1 to 8)
- `batchYear`: String (e.g. `'2023-2027'`)
- `rollNo`: String
- `contactNo`: String
- `targetPercentage`: Number, default 75 (0 to 100)
- `targetAttendance`: Number, default 80 (0 to 100)
- `academicStatus`: String, enum: `['Active', 'Probation', 'Graduated', 'Withdrawn']`

### 3. `subjects`
Stores course curriculum, credits, and faculty assignments.
- `_id`: ObjectId (Primary Key)
- `code`: String, required, unique, uppercase (e.g. `'CS501'`)
- `name`: String, required
- `department`: String, required
- `semester`: Number, required (1 to 8)
- `credits`: Number, required, min 1, max 10
- `facultyName`: String
- `maxMarks`: Number, default 100
- `passingMarks`: Number, default 40

### 4. `assessments`
Defines continuous internal tests, assignments, and practicals.
- `_id`: ObjectId (Primary Key)
- `title`: String, required
- `type`: String, enum: `['Internal Test', 'Assignment', 'Practical', 'Midterm', 'Semester End Exam', 'Quiz']`
- `subjectRef`: ObjectId ref `'Subject'`, required
- `semester`: Number, required
- `maxMarks`: Number, required, min 1
- `weightagePercent`: Number, required, 0 to 100
- `date`: Date, default `Date.now`

### 5. `marks`
Stores score entries per student and assessment.
- `_id`: ObjectId (Primary Key)
- `studentRef`: ObjectId ref `'Student'`, required
- `assessmentRef`: ObjectId ref `'Assessment'`, required
- `subjectRef`: ObjectId ref `'Subject'`, required
- `marksObtained`: Number, required, min 0
- `maxMarks`: Number, required
- `percentage`: Number (Computed automatically)
- `grade`: String (Computed automatically via grading scale)
- `feedback`: String
- **Compound Unique Index:** `{ studentRef: 1, assessmentRef: 1 }` (Prevents duplicate marks)
- **Validation Hook:** Rejects if `marksObtained > maxMarks`.

### 6. `attendance`
Stores session-level attendance logs.
- `_id`: ObjectId (Primary Key)
- `studentRef`: ObjectId ref `'Student'`, required
- `subjectRef`: ObjectId ref `'Subject'`, required
- `date`: Date, required
- `session`: String, enum: `['Session 1', 'Session 2', 'Full Day']`
- `status`: String, enum: `['Present', 'Absent', 'Leave']`
- `remarks`: String
- **Compound Unique Index:** `{ studentRef: 1, subjectRef: 1, date: 1, session: 1 }` (Prevents duplicate attendance entries).

### 7. `studyTasks`
Stores personalized study tasks created manually or from recommendations.
- `_id`: ObjectId (Primary Key)
- `studentRef`: ObjectId ref `'Student'`, required
- `subjectRef`: ObjectId ref `'Subject'`
- `title`: String, required
- `priority`: String, enum: `['High', 'Medium', 'Low']`
- `status`: String, enum: `['Pending', 'In Progress', 'Completed']`
- `dueDate`: Date, required
- `estimatedHours`: Number, default 2
- `source`: String, enum: `['Intervention Recommendation', 'Self Created', 'Faculty Suggested', 'Goal Action']`
- `completedAt`: Date

### 8. `goals`
Tracks student academic milestones and semester targets.
- `_id`: ObjectId (Primary Key)
- `studentRef`: ObjectId ref `'Student'`, required
- `title`: String, required
- `category`: String, enum: `['Subject Marks', 'Semester Percentage', 'Attendance', 'Task Completion']`
- `targetValue`: Number, required
- `currentValue`: Number, default 0
- `deadline`: Date, required
- `status`: String, enum: `['In Progress', 'Achieved', 'Missed']`

### 9. `interventions`
Stores active risk radar standing and complete historical reassessment audit entries.
- `_id`: ObjectId (Primary Key)
- `studentRef`: ObjectId ref `'Student'`, required
- `riskLevel`: String, enum: `['On Track', 'Needs Attention', 'High Priority']`
- `detectedConcern`: String, required
- `triggerRule`: String, required
- `supportingMeasurements`: Mixed (Holds overallMarks, overallAttendance, concrete evidence)
- `explanation`: Object (holds `whyItMatters`, `evidence`, `thresholdApplied`)
- `recommendations`: Array of recommendation action objects
- `status`: String, enum: `['Active', 'In Progress', 'Resolved', 'Reassessed']`
- `reassessmentHistory`: Array of `{ reassessedAt, previousScore, newScore, observedChange, notes }`

### 10. `auditLogs`
Tracks administrative and sensitive operations.
- `userRef`: ObjectId ref `'User'`
- `userName`: String
- `userRole`: String
- `action`: String (e.g. `'CREATE_STUDENT'`, `'ENTER_MARK'`, `'RECORD_ATTENDANCE'`)
- `resource`: String
- `resourceId`: String
- `details`: Mixed (Sanitized against passwords and tokens)
- `ipAddress`: String
- `createdAt`: Date
