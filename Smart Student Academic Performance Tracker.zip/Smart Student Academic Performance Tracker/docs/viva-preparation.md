# EduTrack — Comprehensive Viva & Presentation Guide

This preparation guide prepares students for oral presentations, examiner questions, and technical viva defense for university Web Technology project evaluations.

---

## 1. Two-Minute Elevator Pitch

> *"Respected examiners, my project is **EduTrack — Smart Academic Intelligence & Student Performance Tracker**.
> 
> Most institutional college portals today are strictly passive historical records: students log in only after semester results are finalized, at which point failing grades or attendance debarments can no longer be rectified.
> 
> EduTrack transforms academic records into an **active improvement system** powered by our **Central Innovation: The Smart Academic Intervention System**.
> 
> Instead of unexplainable black-box AI, EduTrack uses a transparent, rule-based Academic Risk Radar that continuously detects score drops (&ge;10%), repeated low marks (&lt;50%), and critical attendance deficits (&lt;75%). Every flagged indicator explains the exact rule applied, quotes concrete evidence from database records, and provides a **1-Click link to generate actionable study tasks** in the student's study planner.
> 
> Built on Node.js, Express, MongoDB, and Bootstrap 5 with strict Role-Based Access Control and mathematical simulation engines, EduTrack delivers an innovative, full-stack solution ready for real-world academic deployment."*

---

## 2. Five-Minute Formal Presentation Script

- **Minute 1: Problem Statement & Existing System Limitations**
  - Discuss how existing university portals (like ERPs or LMSs) are data silos without early-warning capabilities.
  - Highlight that students often realize they are short of attendance only when hall tickets are blocked.

- **Minute 2: Proposed Solution & System Architecture**
  - Present the 3-Tier Client-Server Architecture: Frontend (Bootstrap 5, Chart.js), Backend (Express REST APIs, JWT, RBAC), and Persistence (MongoDB Atlas).
  - Emphasize security: Password hashing via `bcryptjs`, JWT Bearer tokens, and strict middleware preventing students from accessing another student's records by tampering with IDs.

- **Minute 3: The Central Innovation — Smart Academic Intervention System**
  - Walk through the 5 explainability points: (1) Concern, (2) Rule Applied, (3) Concrete Measurements, (4) Why It Matters, and (5) Next Action.
  - Explain why rule-based engines are superior to black-box ML in educational governance: **auditability, transparency, and deterministic testing**.

- **Minute 4: Interactive Simulation Engines**
  - Demonstrate the **What-If Grade Simulator**: Show how students input weights and hypothetical future scores to see if a desired GPA is achievable.
  - Demonstrate the **Attendance Recovery Calculator**: Explain the exact formula:
    $$x = \max\left(0, \left\lceil \frac{rT - A}{1 - r} \right\rceil\right)$$
    and show how it preloads live student attendance from MongoDB.

- **Minute 5: Demonstration & Conclusion**
  - Execute the live demo: Faculty records a score &rarr; Student dashboard updates &rarr; Risk radar flags concern &rarr; 1-Click task created &rarr; Reassessment triggered.
  - Conclude with project readiness for GitHub and Vercel cloud deployment.

---

## 3. Comprehensive Viva Q&A Guide

### Web Technology & Architecture

#### Q1: What is REST and how are RESTful principles implemented in EduTrack?
**Answer:** REST (Representational State Transfer) is an architectural style for networked systems. In EduTrack:
- Standard HTTP methods are used semantically: `GET` for reading records, `POST` for creation, `PUT`/`PATCH` for updates, and `DELETE` for removal.
- Stateless communication: Each request contains all information needed (via JWT in the `Authorization: Bearer` header); no session state is maintained on the server.
- Consistent JSON responses: Every endpoint returns `{ success: true, data: ... }` or `{ success: false, message: ... }` with appropriate HTTP status codes (200, 201, 400, 401, 403, 404, 409, 500).

#### Q2: How does Node.js handle concurrent requests?
**Answer:** Node.js runs on a single-threaded event loop utilizing libuv for non-blocking asynchronous I/O. When database queries or file operations occur, they are delegated to worker threads or OS kernel routines. The main thread continues processing incoming HTTP requests, firing callbacks or resolving Promises when I/O completes.

#### Q3: What is Mongoose and why use it over raw MongoDB driver?
**Answer:** Mongoose is an Object Data Modeling (ODM) library for MongoDB. It provides:
1. Strict schema definitions with data types and validation rules.
2. Pre-save middleware hooks (used in EduTrack to auto-calculate percentage and assign letter grades before saving marks).
3. Population of references (`populate`), creating virtual joins between collections.
4. Compound unique indexes (preventing duplicate marks or attendance entries).

---

### Security & Authorization

#### Q4: How is password security implemented?
**Answer:** Plain-text passwords are never stored. In `User.js`, a Mongoose `pre('save')` hook hashes the password using `bcryptjs` with 10 salt rounds. During login, `bcrypt.compare()` verifies the entered password against the stored hash in constant time to prevent timing attacks. Additionally, the `toJSON()` method deletes the password field from any user object before serializing it to the client.

#### Q5: How is Role-Based Access Control (RBAC) enforced?
**Answer:** In `backend/middleware/auth.js`:
- `authenticateToken` verifies the JWT signature and extracts user claims.
- `authorizeRoles('admin', 'faculty')` verifies that the user's role is in the allowed set; otherwise, it returns HTTP 403 Forbidden.
- `enforceStudentSelfAccess` guarantees that student users can **only** query or manipulate their own student record. Changing a student ID in the URL parameter causes the middleware to return `403 Forbidden: Access Denied`.

---

### Central Innovation & Mathematical Modeling

#### Q6: Explain the mathematical derivation of the Attendance Recovery formula.
**Answer:** Let $A$ be classes attended, $T$ be total classes held, and $r$ be target percentage as fraction ($0 < r < 1$).
We want to find the minimum non-negative integer of upcoming consecutive classes $x$ such that:
$$\frac{A + x}{T + x} \ge r$$
Multiplying both sides by $(T + x)$ (since $T + x > 0$):
$$A + x \ge rT + rx$$
$$x - rx \ge rT - A$$
$$x(1 - r) \ge rT - A$$
Since $r < 1$, $(1 - r) > 0$, we divide without flipping the inequality:
$$x \ge \frac{rT - A}{1 - r}$$
Because $x$ must be a discrete integer of classes and non-negative:
$$x = \max\left(0, \left\lceil \frac{rT - A}{1 - r} \right\rceil\right)$$
*Edge case:* If $r = 1.0$ (100% target) and at least one class was missed ($A < T$), $(A+x)/(T+x) < 1$ for all finite $x$, making 100% mathematically impossible.

#### Q7: How does the What-If Grade Simulator determine target feasibility?
**Answer:** Let completed assessments have total weight $W_{\text{comp}}$ and earned weighted score $S_{\text{comp}} = \sum (w_i \times s_i / 100)$.
Remaining assessments have total weight $W_{\text{rem}} = 100 - W_{\text{comp}}$.
To reach target score $T_{\text{target}}$:
$$\text{Needed Score on Remaining} = \frac{T_{\text{target}} - S_{\text{comp}}}{W_{\text{rem}}} \times 100$$
If this needed average score exceeds $100\%$, the target is mathematically impossible because even scoring 100% on every remaining test would only yield $S_{\text{comp}} + W_{\text{rem}} < T_{\text{target}}$.
