/**
 * EduTrack — Core Client Framework (app.js)
 * Shared utilities for API calls, authentication state, dark/light theme,
 * toast alerts, and session management.
 */

const API_BASE = '/api';

// ==========================================================================
// Theme Management (Light / Dark)
// ==========================================================================
function initTheme() {
  const savedTheme = localStorage.getItem('edutrack_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  updateThemeIcons(savedTheme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  const newTheme = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('edutrack_theme', newTheme);
  updateThemeIcons(newTheme);
}

function updateThemeIcons(theme) {
  document.querySelectorAll('.btn-theme-toggle i').forEach((icon) => {
    icon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
  });
}

// ==========================================================================
// Authentication & Session
// ==========================================================================
function getToken() {
  return localStorage.getItem('edutrack_token');
}

function getCurrentUser() {
  try {
    const userStr = localStorage.getItem('edutrack_user');
    return userStr ? JSON.parse(userStr) : null;
  } catch (e) {
    return null;
  }
}

function setSession(token, user) {
  localStorage.setItem('edutrack_token', token);
  localStorage.setItem('edutrack_user', JSON.stringify(user));
}

function logout() {
  localStorage.removeItem('edutrack_token');
  localStorage.removeItem('edutrack_user');
  window.location.href = '/login.html';
}

function requireAuth(allowedRoles = []) {
  const token = getToken();
  const user = getCurrentUser();

  if (!token || !user) {
    window.location.href = `/login.html?redirect=${encodeURIComponent(window.location.pathname)}`;
    return null;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    showToast(`Access Restricted: Page requires ${allowedRoles.join(' or ')} privileges.`, 'error', 'Permission Denied');
    setTimeout(() => {
      window.location.href = '/dashboard.html';
    }, 1200);
    return null;
  }

  return user;
}

// Quick Demo Login Switcher (for presentation & viva)
async function quickDemoLogin(role) {
  try {
    showToast(`Switching to demo ${role} session...`, 'info', 'Demo Switcher');
    const res = await fetch(`${API_BASE}/auth/demo-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role })
    });
    const data = await res.json();
    if (!data.success) {
      showToast(data.message || 'Demo login failed', 'error');
      return;
    }
    setSession(data.token, data.user);
    showToast(`Logged in as ${data.user.name} (${data.user.role.toUpperCase()})`, 'success');
    setTimeout(() => {
      window.location.href = '/dashboard.html';
    }, 500);
  } catch (err) {
    showToast('Failed to switch demo account: ' + err.message, 'error');
  }
}

// ==========================================================================
// Robust API Client (Fetch Wrapper)
// ==========================================================================
async function apiFetch(endpoint, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {})
  };

  const url = endpoint.startsWith('http') ? endpoint : `${API_BASE}${endpoint}`;

  try {
    const response = await fetch(url, { ...options, headers });

    // Handle token expiration
    if (response.status === 401 && !url.includes('/auth/login') && !url.includes('/auth/register')) {
      showToast('Session expired. Please log in again.', 'warning');
      logout();
      return { success: false, message: 'Session expired' };
    }

    // Check if response is JSON or Blob/CSV
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('text/csv')) {
      const text = await response.text();
      return { success: true, csvText: text };
    }

    const data = await response.json();
    return data;
  } catch (err) {
    console.error(`[API Fetch Error] ${endpoint}:`, err);
    return {
      success: false,
      message: err.message || 'Network communication error.'
    };
  }
}

// ==========================================================================
// Toast Notification Engine
// ==========================================================================
function showToast(message, type = 'info', title = '') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `custom-toast ${type}`;

  const iconMap = {
    success: 'bi-check-circle-fill text-success',
    error: 'bi-exclamation-octagon-fill text-danger',
    warning: 'bi-exclamation-triangle-fill text-warning',
    info: 'bi-info-circle-fill text-primary'
  };

  const iconClass = iconMap[type] || iconMap.info;
  const heading = title || (type === 'error' ? 'Error' : type === 'success' ? 'Success' : 'Notice');

  toast.innerHTML = `
    <i class="bi ${iconClass} fs-4"></i>
    <div style="flex-grow: 1;">
      <div style="font-weight: 700; font-size: 0.85rem;">${heading}</div>
      <div style="font-size: 0.825rem; color: var(--text-secondary); margin-top: 2px;">${message}</div>
    </div>
    <button type="button" class="btn-close" style="font-size: 0.75rem;" aria-label="Close"></button>
  `;

  const closeBtn = toast.querySelector('.btn-close');
  closeBtn.addEventListener('click', () => toast.remove());

  container.appendChild(toast);

  // Auto-remove after 4 seconds
  setTimeout(() => {
    if (toast.parentElement) {
      toast.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(50px)';
      setTimeout(() => toast.remove(), 300);
    }
  }, 4000);
}

// ==========================================================================
// Formatters & UI Utilities
// ==========================================================================
function formatPercent(val) {
  if (typeof val !== 'number' || isNaN(val)) return '0.0%';
  return `${val.toFixed(1)}%`;
}

function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  const d = new Date(dateStr);
  return isNaN(d) ? 'N/A' : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function getRiskBadgeHtml(level) {
  const norm = (level || '').toLowerCase().trim();
  if (norm === 'on track') {
    return `<span class="badge-risk on-track"><i class="bi bi-shield-check"></i> On Track</span>`;
  }
  if (norm === 'needs attention') {
    return `<span class="badge-risk needs-attention"><i class="bi bi-exclamation-triangle-fill"></i> Needs Attention</span>`;
  }
  if (norm === 'high priority') {
    return `<span class="badge-risk high-priority"><i class="bi bi-exclamation-octagon-fill"></i> High Priority</span>`;
  }
  return `<span class="badge bg-secondary">${level || 'Unknown'}</span>`;
}

// Execute on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
});
