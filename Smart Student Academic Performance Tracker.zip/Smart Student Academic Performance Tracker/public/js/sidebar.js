/**
 * EduTrack — Shared Dynamic Sidebar & Topbar Component (sidebar.js)
 * Ensures 100% navigation consistency, role-based visibility, active link state,
 * notification polling, and evaluation demo switching across all application pages.
 */

function renderAppShell(activePage = '') {
  const user = getCurrentUser() || { name: 'Guest User', role: 'student', email: '' };
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  const role = user.role || 'student';

  // Navigation Links configuration
  const navSections = [
    {
      title: 'Academic Intelligence',
      links: [
        { href: '/dashboard.html', icon: 'bi-grid-1x2-fill', label: 'Dashboard', roles: ['admin', 'faculty', 'student'] },
        {
          href: '/interventions.html',
          icon: 'bi-radar',
          label: 'Intervention Center',
          roles: ['admin', 'faculty', 'student'],
          badge: 'Central Innovation'
        },
        { href: '/analytics.html', icon: 'bi-bar-chart-line-fill', label: 'Academic Analytics', roles: ['admin', 'faculty', 'student'] }
      ]
    },
    {
      title: 'Action & Simulation Tools',
      links: [
        { href: '/study-planner.html', icon: 'bi-check2-square', label: 'Study Planner', roles: ['admin', 'faculty', 'student'] },
        { href: '/grade-simulator.html', icon: 'bi-calculator-fill', label: 'What-If Grade Simulator', roles: ['admin', 'faculty', 'student'] },
        { href: '/attendance-calculator.html', icon: 'bi-calendar-check-fill', label: 'Attendance Recovery', roles: ['admin', 'faculty', 'student'] },
        { href: '/goals.html', icon: 'bi-trophy-fill', label: 'Goals & Achievements', roles: ['admin', 'faculty', 'student'] }
      ]
    },
    {
      title: 'Management & Records',
      links: [
        { href: '/students.html', icon: 'bi-people-fill', label: 'Student Directory', roles: ['admin', 'faculty'] },
        { href: '/subjects.html', icon: 'bi-journal-bookmark-fill', label: 'Subject Curriculum', roles: ['admin', 'faculty'] },
        { href: '/assessments.html', icon: 'bi-clipboard-data-fill', label: 'Marks & Assessments', roles: ['admin', 'faculty'] },
        { href: '/attendance.html', icon: 'bi-calendar3', label: 'Attendance Records', roles: ['admin', 'faculty'] }
      ]
    },
    {
      title: 'Reports & Governance',
      links: [
        { href: '/reports.html', icon: 'bi-file-earmark-pdf-fill', label: 'Reports & Transcripts', roles: ['admin', 'faculty', 'student'] },
        { href: '/settings.html', icon: 'bi-sliders', label: 'Profile & Settings', roles: ['admin', 'faculty', 'student'] },
        { href: '/help.html', icon: 'bi-question-circle-fill', label: 'Methodology & Viva Guide', roles: ['admin', 'faculty', 'student'] }
      ]
    }
  ];

  // Build Sidebar HTML
  let navHtml = '';
  navSections.forEach((sec) => {
    const visibleLinks = sec.links.filter((l) => l.roles.includes(role));
    if (visibleLinks.length === 0) return;

    navHtml += `<div class="nav-section-title">${sec.title}</div>`;
    visibleLinks.forEach((item) => {
      const isItemActive = currentPath === item.href.replace('/', '') || activePage === item.label;
      const activeClass = isItemActive ? 'active' : '';
      const badgeHtml = item.badge ? `<span class="nav-badge-innovation">${item.badge}</span>` : '';
      navHtml += `
        <a href="${item.href}" class="nav-link-item ${activeClass}">
          <i class="bi ${item.icon}"></i>
          <span>${item.label}</span>
          ${badgeHtml}
        </a>
      `;
    });
  });

  const sidebarContainer = document.getElementById('sidebar-container');
  if (sidebarContainer) {
    sidebarContainer.innerHTML = `
      <aside class="sidebar" id="appSidebar">
        <div class="sidebar-brand">
          <div class="brand-icon"><i class="bi bi-mortarboard-fill"></i></div>
          <div>EduTrack <span style="font-size: 0.65rem; color: #818cf8; display: block; font-weight: 600; text-transform: uppercase;">Smart Intelligence</span></div>
        </div>
        <nav class="sidebar-nav">
          ${navHtml}
        </nav>
        <div style="padding: 1rem 1.25rem; border-top: 1px solid rgba(255,255,255,0.08); background: rgba(0,0,0,0.2);">
          <div style="font-size: 0.75rem; color: #94a3b8; display: flex; justify-content: space-between; align-items: center;">
            <span>Role: <strong style="color: #fff; text-transform: capitalize;">${role}</strong></span>
            <span class="badge bg-primary" style="font-size: 0.65rem;">v1.0</span>
          </div>
        </div>
      </aside>
    `;
  }

  // Build Topbar HTML
  const topbarContainer = document.getElementById('topbar-container');
  if (topbarContainer) {
    topbarContainer.innerHTML = `
      <header class="topbar">
        <div class="topbar-left">
          <button class="btn-sidebar-toggle" id="btnToggleSidebar" aria-label="Toggle Navigation">
            <i class="bi bi-list"></i>
          </button>
          <div class="d-none d-md-flex align-items-center gap-2">
            <span class="badge bg-indigo-subtle text-primary border border-primary-subtle py-1 px-2.5 rounded-pill" style="font-size: 0.75rem;">
              <i class="bi bi-shield-lock-fill me-1"></i> ${role.toUpperCase()} MODE
            </span>
            <a href="/interventions.html?viva=true" class="badge bg-danger-subtle text-danger border border-danger-subtle py-1 px-2.5 rounded-pill text-decoration-none fw-bold" style="font-size: 0.75rem;">
              <i class="bi bi-play-circle-fill me-1"></i> Viva Innovation Tour
            </a>
          </div>
        </div>
        <div class="topbar-right">
          <!-- Presentation / Evaluation Demo Switcher Button -->
          <div class="dropdown">
            <button class="btn btn-sm btn-outline-primary dropdown-toggle d-flex align-items-center gap-1.5" type="button" data-bs-toggle="dropdown">
              <i class="bi bi-person-badge"></i>
              <span class="d-none d-sm-inline">Switch Demo Role</span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
              <li><h6 class="dropdown-header">Evaluation Demo Switcher</h6></li>
              <li><a class="dropdown-item" href="javascript:void(0)" onclick="quickDemoLogin('admin')"><i class="bi bi-person-gear text-danger me-2"></i> Administrator (Dr. Sarah)</a></li>
              <li><a class="dropdown-item" href="javascript:void(0)" onclick="quickDemoLogin('faculty')"><i class="bi bi-mortarboard text-warning me-2"></i> Faculty (Prof. Sharma)</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="javascript:void(0)" onclick="quickDemoLogin('student')"><i class="bi bi-person-check text-success me-2"></i> Student: Arun (On Track)</a></li>
              <li><a class="dropdown-item" href="javascript:void(0)" onclick="loginAsSpecificDemo('priya.nair@edutrack.edu')"><i class="bi bi-person-exclamation text-warning me-2"></i> Student: Priya (Declining Trend)</a></li>
              <li><a class="dropdown-item" href="javascript:void(0)" onclick="loginAsSpecificDemo('rohit.verma@edutrack.edu')"><i class="bi bi-person-x text-danger me-2"></i> Student: Rohit (High Priority)</a></li>
            </ul>
          </div>

          <!-- Theme Toggle -->
          <button class="btn-theme-toggle" id="themeToggleBtn" onclick="toggleTheme()" aria-label="Toggle Dark Theme">
            <i class="bi bi-moon-stars-fill"></i>
          </button>

          <!-- Notification Dropdown -->
          <div class="dropdown">
            <button class="btn-theme-toggle position-relative" data-bs-toggle="dropdown" aria-expanded="false" id="notifDropdownBtn">
              <i class="bi bi-bell-fill"></i>
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="notifBadge" style="display: none; font-size: 0.6rem;">0</span>
            </button>
            <div class="dropdown-menu dropdown-menu-end shadow-lg p-0" style="width: 320px; max-height: 400px; overflow-y: auto;" id="notifMenu">
              <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
                <h6 class="m-0 fw-bold">Notifications</h6>
                <a href="javascript:void(0)" onclick="markAllNotificationsRead()" class="small text-primary">Mark all read</a>
              </div>
              <div id="notifList" class="p-2">
                <div class="text-center py-3 text-muted small">Loading notifications...</div>
              </div>
            </div>
          </div>

          <!-- User Profile Dropdown -->
          <div class="dropdown">
            <div class="user-profile-badge" data-bs-toggle="dropdown" aria-expanded="false">
              <div class="user-avatar">${(user.name || 'U').charAt(0).toUpperCase()}</div>
              <div class="d-none d-lg-block text-start">
                <div style="font-size: 0.825rem; font-weight: 700; line-height: 1.1;">${user.name}</div>
                <div style="font-size: 0.7rem; color: var(--text-muted); text-transform: capitalize;">${role}</div>
              </div>
              <i class="bi bi-chevron-down ms-1" style="font-size: 0.75rem;"></i>
            </div>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
              <li><a class="dropdown-item" href="/settings.html"><i class="bi bi-person me-2"></i> My Profile</a></li>
              <li><a class="dropdown-item" href="/help.html"><i class="bi bi-question-circle me-2"></i> Viva & Project Help</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item text-danger" href="javascript:void(0)" onclick="logout()"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
            </ul>
          </div>
        </div>
      </header>
    `;

    // Sidebar Mobile Toggle
    const toggleBtn = document.getElementById('btnToggleSidebar');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        const sidebar = document.getElementById('appSidebar');
        if (sidebar) sidebar.classList.toggle('show');
      });
    }

    // Load Notifications
    loadHeaderNotifications();
  }
}

async function loadHeaderNotifications() {
  const notifList = document.getElementById('notifList');
  const notifBadge = document.getElementById('notifBadge');
  if (!notifList) return;

  const data = await apiFetch('/notifications');
  if (data.success && data.notifications) {
    if (data.unreadCount > 0) {
      notifBadge.innerText = data.unreadCount;
      notifBadge.style.display = 'inline-block';
    } else {
      notifBadge.style.display = 'none';
    }

    if (data.notifications.length === 0) {
      notifList.innerHTML = `<div class="text-center py-3 text-muted small"><i class="bi bi-bell-slash d-block fs-4 mb-1"></i> No recent notifications.</div>`;
      return;
    }

    notifList.innerHTML = data.notifications.slice(0, 5).map((n) => `
      <div class="p-2.5 mb-1 rounded ${n.isRead ? '' : 'bg-light'} border-bottom" style="font-size: 0.8rem;">
        <div class="d-flex justify-content-between align-items-center">
          <strong class="${n.type === 'alert' ? 'text-danger' : n.type === 'warning' ? 'text-warning' : 'text-primary'}">${n.title}</strong>
          <span style="font-size: 0.65rem; color: var(--text-muted);">${formatDate(n.createdAt)}</span>
        </div>
        <div class="text-secondary mt-1">${n.message}</div>
      </div>
    `).join('');
  }
}

async function markAllNotificationsRead() {
  await apiFetch('/notifications/mark-all-read', { method: 'POST' });
  loadHeaderNotifications();
}

async function loginAsSpecificDemo(email) {
  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: 'student123' })
    });
    const data = await res.json();
    if (data.success) {
      setSession(data.token, data.user);
      showToast(`Switched session to ${data.user.name}`, 'success');
      setTimeout(() => {
        window.location.reload();
      }, 500);
    }
  } catch (e) {
    showToast('Failed to switch student: ' + e.message, 'error');
  }
}

/**
 * Universal Student Selector for Faculty / Admin
 * Automatically injects a clean student dropdown into pages where faculty needs to switch context
 */
async function renderStudentSelector(containerId, currentStudentId, onSelectCallback) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const res = await apiFetch('/students');
  if (res.success && res.students && res.students.length > 0) {
    const optionsHtml = res.students.map(s => {
      const isSelected = (s._id === currentStudentId) ? 'selected' : '';
      return `<option value="${s._id}" ${isSelected}>${s.fullName} (${s.studentId}) &bull; Sem ${s.semester} &bull; Target: ${s.targetPercentage}%</option>`;
    }).join('');

    container.innerHTML = `
      <div class="student-selector-toolbar shadow-sm">
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-person-bounding-box text-primary fs-5"></i>
          <div>
            <div class="small fw-bold text-primary">Student Context Selector</div>
            <div class="text-muted" style="font-size: 0.72rem;">Reviewing individual academic standing &amp; intervention metrics</div>
          </div>
        </div>
        <div class="d-flex align-items-center gap-2">
          <label class="small text-muted fw-semibold mb-0 d-none d-sm-inline">Select Student:</label>
          <select class="form-select form-select-sm" id="activeStudentContextSelect" style="min-width: 260px;">
            ${optionsHtml}
          </select>
        </div>
      </div>
    `;

    const selectEl = document.getElementById('activeStudentContextSelect');
    if (selectEl) {
      selectEl.addEventListener('change', (e) => {
        const newId = e.target.value;
        localStorage.setItem('edutrack_active_student', newId);
        if (typeof onSelectCallback === 'function') {
          onSelectCallback(newId);
        }
      });
    }
  }
}

/**
 * Helper to get the actively targeted student ID for any page
 */
function resolveCurrentStudentId(user) {
  const params = new URLSearchParams(window.location.search);
  const paramId = params.get('studentId');
  if (paramId) return paramId;

  if (user && user.studentRef) {
    return user.studentRef._id || user.studentRef;
  }

  const stored = localStorage.getItem('edutrack_active_student');
  if (stored) return stored;

  return null;
}

